import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/connection_state.dart';
import '../../models/proxy_config.dart';
import '../../providers/providers.dart';
import '../add_actions.dart';
import '../theme.dart';
import '../widgets/anim.dart';
import '../widgets/config_tile.dart';
import '../widgets/connect_button.dart';
import '../widgets/glass.dart';
import '../widgets/groups_list.dart';
import 'settings_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  Future<void> _toggle(BuildContext context, WidgetRef ref) async {
    try {
      await ref.read(connectionControllerProvider).toggle();
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final zen = ref.watch(settingsProvider.select((s) => s.zenMode));
    final status = ref.watch(vpnStatusProvider).valueOrNull ?? VpnStatus.disconnected;
    final groups = ref.watch(configGroupsProvider);
    final active = ref.watch(activeConfigProvider);
    final tv = ref.watch(isTvProvider);

    return SafeArea(
      bottom: false,
      child: Column(
        children: [
          _Header(
            onSettings: () => openSettings(context),
            onAdd: () => AddActions.showMenu(context, ref, tv),
          ),
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 450),
              switchInCurve: Curves.easeOutCubic,
              child: zen
                  ? KeyedSubtree(
                      key: const ValueKey('zen'),
                      child: _Zen(status: status, active: active, onToggle: () => _toggle(context, ref)),
                    )
                  : KeyedSubtree(
                      key: const ValueKey('full'),
                      child: ListView(
                        padding: const EdgeInsets.only(top: 14, bottom: 30),
                        children: [
                          FadeSlideIn(
                            child: _ConnectCard(
                              status: status,
                              active: active,
                              groups: groups,
                              onToggle: () => _toggle(context, ref),
                            ),
                          ),
                          const SizedBox(height: 22),
                          FadeSlideIn(
                            index: 1,
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(22, 0, 16, 10),
                              child: Row(
                                children: [
                                  Text('GROUPS',
                                      style: TextStyle(
                                          fontSize: 12,
                                          letterSpacing: 3,
                                          color: Theme.of(context).colorScheme.onSurfaceVariant)),
                                  const Spacer(),
                                  if (groups.isNotEmpty)
                                    GlassPill(
                                      icon: Icons.speed_rounded,
                                      label: 'Ping all',
                                      busyLabel: 'Testing…',
                                      onPressed: () => ref.read(configsProvider.notifier).pingAll(),
                                    ),
                                ],
                              ),
                            ),
                          ),
                          if (groups.isEmpty)
                            const _Empty()
                          else
                            GroupsList(groups: groups),
                        ],
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Header: a quiet name plate (almost the same tone as the background), and
// below it, separate, the settings and add buttons.

class _Header extends StatelessWidget {
  final VoidCallback onSettings;
  final VoidCallback onAdd;
  const _Header({required this.onSettings, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Column(
        children: [
          const _Brand(),
          const SizedBox(height: 12),
          Row(
            children: [
              Pressable(circle: true, onTap: onSettings, child: const GlassIcon(Icons.settings_outlined, size: 42)),
              const Spacer(),
              Pressable(circle: true, onTap: onAdd, child: const GlassIcon(Icons.add_rounded, size: 42, iconSize: 24)),
            ],
          ),
        ],
      ),
    );
  }
}

/// Name plate: tone-on-tone wordmark in a barely visible frame.
class _Brand extends StatelessWidget {
  const _Brand();

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = cs.brightness == Brightness.dark;
    final base = dark ? Colors.white : Colors.black;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        color: base.withValues(alpha: 0.02),
        border: Border.all(color: base.withValues(alpha: 0.05)),
      ),
      child: Column(
        children: [
          Text('Iris',
              style: TextStyle(
                fontSize: 44,
                fontWeight: FontWeight.w500,
                letterSpacing: 8,
                height: 1.0,
                color: cs.onSurface.withValues(alpha: dark ? 0.78 : 0.72),
              )),
          const SizedBox(height: 6),
          Text('V 2 R A Y',
              style: TextStyle(fontSize: 9.5, letterSpacing: 6, color: cs.onSurface.withValues(alpha: 0.32))),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Connect card: the round button is always docked to the left edge of a glass frame.

class _ConnectCard extends ConsumerWidget {
  final VpnStatus status;
  final ProxyConfig? active;
  final List<ConfigGroup> groups;
  final VoidCallback onToggle;
  const _ConnectCard({required this.status, required this.active, required this.groups, required this.onToggle});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cs = Theme.of(context).colorScheme;
    final on = status == VpnStatus.connected;
    final busy = status == VpnStatus.connecting || status == VpnStatus.disconnecting;
    final stateColor = on ? AppTheme.okOf(cs) : (busy ? AppTheme.busyOf(cs) : cs.onSurfaceVariant);
    final accent = on ? AppTheme.connected : (busy ? AppTheme.connecting : cs.onSurface);
    final label = switch (status) {
      VpnStatus.connected => 'CONNECTED',
      VpnStatus.connecting => 'CONNECTING',
      VpnStatus.disconnecting => 'DISCONNECTING',
      _ => 'NOT CONNECTED',
    };
    final a = active;
    final group = a == null ? null : groups.where((g) => g.configs.any((c) => c.id == a.id)).firstOrNull;
    final sub = group?.sub;
    final ping = a?.pingMs;
    final pingLabel = ping == null ? 'Test ping' : (ping < 0 ? 'timeout' : '$ping ms');
    final w = MediaQuery.of(context).size.width;
    final btn = (w * 0.46).clamp(130.0, 200.0);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeInOut,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(32),
          boxShadow: [BoxShadow(color: accent.withValues(alpha: on ? 0.16 : 0.0), blurRadius: 40)],
        ),
        child: Glass(
          radius: 32,
          blur: 16,
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ConnectButton(status: status, size: btn, onTap: onToggle),
                  const SizedBox(width: 18),
                  Expanded(
                    child: SizedBox(
                      height: btn,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            children: [
                              AnimatedContainer(
                                duration: const Duration(milliseconds: 500),
                                width: 7,
                                height: 7,
                                decoration: BoxDecoration(shape: BoxShape.circle, color: stateColor),
                              ),
                              const SizedBox(width: 6),
                              Flexible(
                                child: Text(label,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(color: stateColor, fontSize: 10.5, letterSpacing: 1.6)),
                              ),
                            ],
                          ),
                          if (on) ...[const SizedBox(height: 4), const _Elapsed()],
                          const SizedBox(height: 10),
                          if (a == null) ...[
                            Text('No config selected',
                                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: cs.onSurface)),
                            const SizedBox(height: 4),
                            Text('Tap + to add one', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
                          ] else ...[
                            Text(a.name,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, height: 1.15, color: cs.onSurface)),
                            const SizedBox(height: 5),
                            Text('${a.flag}  ${a.protocol.label}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
                            Text('${a.address}:${a.port}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                textDirection: TextDirection.ltr,
                                style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant.withValues(alpha: 0.7))),
                          ],
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              if (a != null) ...[
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: GlassPill(
                        icon: Icons.speed_rounded,
                        label: pingLabel,
                        busyLabel: 'Testing…',
                        color: ping == null ? null : pingColor(ping),
                        onPressed: () => ref.read(configsProvider.notifier).pingOne(a.id),
                      ),
                    ),
                    if (sub != null) ...[
                      const SizedBox(width: 10),
                      Expanded(
                        child: GlassPill(
                          icon: Icons.sync_rounded,
                          label: 'Update',
                          busyLabel: 'Updating…',
                          onPressed: () async {
                            final messenger = ScaffoldMessenger.of(context);
                            try {
                              final c = await ref.read(subscriptionsProvider.notifier).refreshOne(sub.id);
                              messenger.showSnackBar(SnackBar(content: Text('Updated: $c configs')));
                            } catch (e) {
                              messenger.showSnackBar(SnackBar(content: Text('$e')));
                            }
                          },
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

/// Elapsed time since connecting.
class _Elapsed extends ConsumerStatefulWidget {
  const _Elapsed();
  @override
  ConsumerState<_Elapsed> createState() => _ElapsedState();
}

class _ElapsedState extends ConsumerState<_Elapsed> {
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final since = ref.watch(connectedSinceProvider);
    if (since == null) return const SizedBox.shrink();
    final d = DateTime.now().difference(since);
    String two(int v) => v.toString().padLeft(2, '0');
    final txt = '${two(d.inHours)}:${two(d.inMinutes % 60)}:${two(d.inSeconds % 60)}';
    return Text(txt,
        style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: Theme.of(context).colorScheme.onSurfaceVariant));
  }
}

// ---------------------------------------------------------------------------

class _Empty extends StatelessWidget {
  const _Empty();
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
      child: Glass(
        radius: 26,
        padding: const EdgeInsets.all(22),
        child: Column(
          children: [
            const GlassIcon(Icons.add_rounded, size: 54, iconSize: 30),
            const SizedBox(height: 12),
            Text('No configs yet', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: cs.onSurface)),
            const SizedBox(height: 4),
            Text('Tap + at the top to add a config or a subscription.',
                textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)),
          ],
        ),
      ),
    );
  }
}

/// Zen mode: just a big round button in the lower third, plus a tiny ping button.
class _Zen extends ConsumerWidget {
  final VpnStatus status;
  final ProxyConfig? active;
  final VoidCallback onToggle;
  const _Zen({required this.status, required this.active, required this.onToggle});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final a = active;
    final ping = a?.pingMs;
    final label = ping == null ? 'Test ping' : (ping < 0 ? 'timeout' : '$ping ms');
    return Stack(
      children: [
        Align(
          alignment: const Alignment(0, 0.3),
          child: ConnectButton(status: status, size: 210, onTap: onToggle),
        ),
        if (a != null)
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 18),
              child: GlassPill(
                icon: Icons.speed_rounded,
                label: label,
                busyLabel: 'Testing…',
                color: ping == null ? null : pingColor(ping),
                onPressed: () => ref.read(configsProvider.notifier).pingOne(a.id),
              ),
            ),
          ),
      ],
    );
  }
}
