import 'dart:ui';

import 'package:flutter/material.dart';

import '../theme.dart';
import 'anim.dart';

/// Frosted-glass surface (glassmorphism).
class Glass extends StatelessWidget {
  final Widget child;
  final double radius;
  final double blur;
  final EdgeInsetsGeometry padding;
  const Glass({
    super.key,
    required this.child,
    this.radius = 28,
    this.blur = 20,
    this.padding = EdgeInsets.zero,
  });

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final r = BorderRadius.circular(radius);
    return ClipRRect(
      borderRadius: r,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blur * 0.6, sigmaY: blur * 0.6),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: r,
            color: (dark ? Colors.white : Colors.black).withValues(alpha: dark ? 0.04 : 0.035),
            border: Border.all(color: (dark ? Colors.white : Colors.black).withValues(alpha: dark ? 0.09 : 0.08), width: 1),
          ),
          child: child,
        ),
      ),
    );
  }
}

/// Minimal round icon: hairline ring, faint fill, thin icon.
class GlassIcon extends StatelessWidget {
  final IconData icon;
  final double size;
  final double? iconSize;
  final Color? color;
  const GlassIcon(this.icon, {super.key, this.size = 38, this.iconSize, this.color});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = cs.brightness == Brightness.dark;
    final base = dark ? Colors.white : Colors.black;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: base.withValues(alpha: dark ? 0.05 : 0.04),
        border: Border.all(color: base.withValues(alpha: dark ? 0.14 : 0.12), width: 1),
      ),
      child: Icon(icon, size: iconSize ?? size * 0.46, color: color ?? AppTheme.iconOf(cs)),
    );
  }
}

/// Glass icon button that shows a spinner while its async action runs.
class AsyncGlassButton extends StatefulWidget {
  final IconData icon;
  final Future<void> Function() onPressed;
  final double size;
  const AsyncGlassButton({super.key, required this.icon, required this.onPressed, this.size = 36});

  @override
  State<AsyncGlassButton> createState() => _AsyncGlassButtonState();
}

class _AsyncGlassButtonState extends State<AsyncGlassButton> {
  bool _busy = false;

  Future<void> _run() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await widget.onPressed();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Pressable(
      circle: true,
      onTap: _busy ? null : _run,
      child: _busy
          ? SizedBox(
              width: widget.size,
              height: widget.size,
              child: Center(
                child: SizedBox(
                  width: widget.size * 0.45,
                  height: widget.size * 0.45,
                  child: CircularProgressIndicator(strokeWidth: 2.2, color: cs.primary),
                ),
              ),
            )
          : GlassIcon(widget.icon, size: widget.size),
    );
  }
}

/// Glass pill with an icon and a label; shows a spinner and [busyLabel] while running.
class GlassPill extends StatefulWidget {
  final IconData icon;
  final String label;
  final String busyLabel;
  final Color? color;
  final Future<void> Function() onPressed;
  const GlassPill({
    super.key,
    required this.icon,
    required this.label,
    required this.onPressed,
    this.busyLabel = 'Working…',
    this.color,
  });

  @override
  State<GlassPill> createState() => _GlassPillState();
}

class _GlassPillState extends State<GlassPill> {
  bool _busy = false;

  Future<void> _run() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await widget.onPressed();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = cs.brightness == Brightness.dark;
    final fg = widget.color ?? cs.onSurface;
    return Pressable(
      focusRadius: 30,
      onTap: _busy ? null : _run,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: (dark ? Colors.white : Colors.black).withValues(alpha: dark ? 0.05 : 0.04),
          border: Border.all(color: (dark ? Colors.white : Colors.black).withValues(alpha: dark ? 0.16 : 0.14), width: 1),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_busy)
              SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: cs.primary))
            else
              Icon(widget.icon, size: 15, color: AppTheme.iconOf(cs)),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                _busy ? widget.busyLabel : widget.label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: fg),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Soft colour orbs behind the UI so the glass surfaces have something to refract.
class AuroraBackground extends StatelessWidget {
  final Widget child;
  const AuroraBackground({super.key, required this.child});

  Widget _orb({double? top, double? bottom, double? left, double? right, required double size, required Color color}) {
    return Positioned(
      top: top,
      bottom: bottom,
      left: left,
      right: right,
      child: IgnorePointer(
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: [color, color.withValues(alpha: 0)]),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = cs.brightness == Brightness.dark;
    return Stack(
      children: [
        Positioned.fill(child: ColoredBox(color: cs.surface)),
        _orb(top: -160, left: -60, size: 480, color: AppTheme.lime.withValues(alpha: dark ? 0.07 : 0.35)),
        Positioned.fill(child: child),
      ],
    );
  }
}
