import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../models/app_settings.dart';
import '../models/connection_state.dart';
import '../models/proxy_config.dart';
import '../models/subscription.dart';
import '../services/config_parser.dart';
import '../services/storage_service.dart';
import '../services/subscription_manager.dart';
import '../services/xray_service.dart';

final xrayServiceProvider = Provider<XrayService>((ref) {
  final s = FlutterVlessXrayService();
  ref.onDispose(s.dispose);
  return s;
});

final subscriptionManagerProvider = Provider((_) => SubscriptionManager());

// ---------------- Settings ----------------
class SettingsNotifier extends Notifier<AppSettings> {
  @override
  AppSettings build() => ref.read(storageServiceProvider).loadSettings();

  void update(AppSettings Function(AppSettings) f) {
    state = f(state);
    ref.read(storageServiceProvider).saveSettings(state);
  }
}

final settingsProvider = NotifierProvider<SettingsNotifier, AppSettings>(SettingsNotifier.new);

// ---------------- Configs ----------------
class ConfigsNotifier extends Notifier<List<ProxyConfig>> {
  StorageService get _store => ref.read(storageServiceProvider);

  @override
  List<ProxyConfig> build() {
    final list = _store.loadConfigs();
    if (list.isNotEmpty) return list;
    return const [];
  }

  /// Returns number added; throws [ConfigParseException] if nothing valid.
  int addFromText(String text) {
    final r = ConfigParser.parseMany(text);
    if (r.configs.isEmpty) {
      throw ConfigParseException(r.errors.isEmpty ? 'لینک معتبری یافت نشد' : r.errors.first);
    }
    state = [...state, ...r.configs];
    _store.saveConfigs(r.configs);
    ref.read(logsProvider.notifier).add('Info', 'added ${r.configs.length} config(s)');
    return r.configs.length;
  }

  void upsert(ProxyConfig c) {
    final i = state.indexWhere((e) => e.id == c.id);
    state = i < 0 ? [...state, c] : ([...state]..[i] = c);
    _store.saveConfig(c);
  }

  void remove(String id) {
    state = state.where((e) => e.id != id).toList();
    _store.deleteConfig(id);
    if (ref.read(activeConfigIdProvider) == id) {
      ref.read(activeConfigIdProvider.notifier).set(null);
    }
  }

  void replaceSubscription(String subId, List<ProxyConfig> fresh) {
    final old = state.where((c) => c.subscriptionId == subId).map((c) => c.id).toList();
    state = [...state.where((c) => c.subscriptionId != subId), ...fresh];
    _store.deleteConfigs(old);
    _store.saveConfigs(fresh);
  }

  Future<void> pingOne(String id) async {
    final c = state.where((e) => e.id == id).firstOrNull;
    if (c == null) return;
    upsert(c.copyWith(clearPing: true));
    final ms = await ref.read(xrayServiceProvider).ping(c);
    ref.read(logsProvider.notifier).add(ms < 0 ? 'Warn' : 'Info', 'ping ${c.name}: ${ms < 0 ? 'timeout' : '$ms ms'}');
    final cur = state.where((e) => e.id == id).firstOrNull;
    if (cur != null) upsert(cur.copyWith(pingMs: ms));
  }

  Future<void> pingAll() async {
    final xray = ref.read(xrayServiceProvider);
    state = [for (final c in state) c.copyWith(clearPing: true)];
    await Future.wait(state.map((c) async {
      final ms = await xray.ping(c);
      ref.read(logsProvider.notifier).add(ms < 0 ? 'Warn' : 'Info', 'ping ${c.name}: ${ms < 0 ? 'timeout' : '$ms ms'}');
      final cur = state.where((e) => e.id == c.id).firstOrNull;
      if (cur != null) upsert(cur.copyWith(pingMs: ms));
    }));
  }
}

final configsProvider = NotifierProvider<ConfigsNotifier, List<ProxyConfig>>(ConfigsNotifier.new);

class ActiveConfigNotifier extends Notifier<String?> {
  @override
  String? build() => ref.read(storageServiceProvider).activeConfigId;
  void set(String? id) {
    state = id;
    ref.read(storageServiceProvider).setActiveConfigId(id);
  }
}

final activeConfigIdProvider = NotifierProvider<ActiveConfigNotifier, String?>(ActiveConfigNotifier.new);

final activeConfigProvider = Provider<ProxyConfig?>((ref) {
  final id = ref.watch(activeConfigIdProvider);
  final list = ref.watch(configsProvider);
  return list.where((c) => c.id == id).firstOrNull ?? list.firstOrNull;
});

// ---------------- Subscriptions ----------------
class SubscriptionsNotifier extends Notifier<List<Subscription>> {
  @override
  List<Subscription> build() => ref.read(storageServiceProvider).loadSubscriptions();

  Future<int> add(String url, {String? name}) async {
    final sub = Subscription(id: const Uuid().v4(), name: name ?? Uri.parse(url).host, url: url);
    state = [...state, sub];
    try {
      return await _refresh(sub);
    } catch (e) {
      state = state.where((s) => s.id != sub.id).toList();
      rethrow;
    }
  }

  Future<int> refreshOne(String id) async {
    final sub = state.firstWhere((s) => s.id == id);
    return _refresh(sub);
  }

  Future<void> remove(String id) async {
    ref.read(configsProvider.notifier).replaceSubscription(id, const []);
    await ref.read(storageServiceProvider).deleteSubscription(id);
    state = state.where((s) => s.id != id).toList();
  }

  Future<int> _refresh(Subscription sub) async {
    final r = await ref.read(subscriptionManagerProvider).fetch(sub.url, subscriptionId: sub.id);
    ref.read(configsProvider.notifier).replaceSubscription(sub.id, r.configs);
    ref.read(logsProvider.notifier).add('Info', 'subscription "${sub.name}": ${r.configs.length} config(s)');
    final updated = sub.copyWith(name: r.title, lastUpdated: DateTime.now());
    await ref.read(storageServiceProvider).saveSubscription(updated);
    state = [for (final s in state) s.id == sub.id ? updated : s];
    return r.configs.length;
  }

  /// Updates all; returns list of error messages (empty = success).
  Future<List<String>> refreshAll() async {
    final errors = <String>[];
    for (final s in state) {
      try {
        await _refresh(s);
      } catch (e) {
        errors.add('${s.name}: $e');
      }
    }
    return errors;
  }
}

final subscriptionsProvider =
    NotifierProvider<SubscriptionsNotifier, List<Subscription>>(SubscriptionsNotifier.new);

// ---------------- Connection ----------------
final vpnStatusProvider = StreamProvider<VpnStatus>((ref) async* {
  final x = ref.watch(xrayServiceProvider);
  yield x.status;
  yield* x.statusStream;
});

final trafficProvider = StreamProvider<TrafficStats>((ref) async* {
  yield TrafficStats.zero;
  yield* ref.watch(xrayServiceProvider).trafficStream;
});

/// Which groups are expanded (kept across tab switches).
final expandedGroupsProvider = StateProvider<Set<String>>((_) => <String>{});
final homeListOpenProvider = StateProvider<bool>((_) => false);

final connectedSinceProvider = StateProvider<DateTime?>((_) => null);

class LogsNotifier extends Notifier<List<String>> {
  static const _max = 1000;
  @override
  List<String> build() {
    final sub = ref.watch(xrayServiceProvider).logStream.listen((l) {
      final next = [...state, l];
      state = next.length > _max ? next.sublist(next.length - _max) : next;
    });
    ref.onDispose(sub.cancel);
    return [_line('Info', 'Irisv2ray started')];
  }

  static String _line(String level, String msg) {
    final t = DateTime.now().toIso8601String().substring(11, 19);
    return '$t [$level] $msg';
  }

  /// App-level log entry (pings, subscriptions, …).
  void add(String level, String msg) {
    final next = [...state, _line(level, msg)];
    state = next.length > _max ? next.sublist(next.length - _max) : next;
  }

  void clear() => state = const [];
}

final logsProvider = NotifierProvider<LogsNotifier, List<String>>(LogsNotifier.new);

class ConnectionController {
  final Ref ref;
  Timer? _watch;
  StreamSubscription<VpnStatus>? _sub;
  bool _wantConnected = false;
  bool _reconnecting = false;
  int _fails = 0;
  final List<DateTime> _attempts = [];

  ConnectionController(this.ref) {
    _sub = ref.read(xrayServiceProvider).statusStream.listen(_onStatus);
  }

  void dispose() {
    _sub?.cancel();
    _watch?.cancel();
  }

  void _log(String level, String msg) => ref.read(logsProvider.notifier).add(level, msg);

  void _onStatus(VpnStatus s) {
    if (s == VpnStatus.connected) {
      _fails = 0;
      _watch ??= Timer.periodic(const Duration(seconds: 25), (_) => _tick());
    } else if (s == VpnStatus.disconnected) {
      _watch?.cancel();
      _watch = null;
      if (_wantConnected && !_reconnecting) {
        _log('Warn', 'tunnel stopped (not from the app button)');
      }
    }
  }

  /// Watchdog: a tiny request through the tunnel every 25 s; two failures → reconnect.
  Future<void> _tick() async {
    final xray = ref.read(xrayServiceProvider);
    if (_reconnecting || !_wantConnected || xray.status != VpnStatus.connected) return;
    if (!ref.read(settingsProvider).autoReconnect) return;
    final cfg = ref.read(activeConfigProvider);
    if (cfg == null) return;
    final ms = await xray.ping(cfg);
    if (ms >= 0) {
      _fails = 0;
      return;
    }
    _fails++;
    _log('Warn', 'connection check failed ($_fails/2)');
    if (_fails >= 2) {
      _fails = 0;
      _scheduleReconnect('no traffic through the tunnel');
    }
  }

  void _scheduleReconnect(String reason) {
    final now = DateTime.now();
    _attempts.removeWhere((t) => now.difference(t) > const Duration(minutes: 10));
    if (_attempts.length >= 5) {
      _log('Error', 'auto-reconnect: too many attempts, stopping');
      _wantConnected = false;
      return;
    }
    _attempts.add(now);
    Future<void>.delayed(const Duration(seconds: 1), () => _reconnect(reason));
  }

  Future<void> _reconnect(String reason) async {
    if (_reconnecting || !_wantConnected) return;
    _reconnecting = true;
    var retry = false;
    try {
      _log('Warn', 'auto-reconnect: $reason');
      final xray = ref.read(xrayServiceProvider);
      if (xray.status != VpnStatus.disconnected) await xray.stop();
      await Future<void>.delayed(const Duration(milliseconds: 1500));
      await _start();
    } catch (e) {
      _log('Error', 'auto-reconnect failed: $e');
      retry = true;
    } finally {
      _reconnecting = false;
    }
    if (retry && _wantConnected) _scheduleReconnect('retry');
  }

  Future<void> toggle() async {
    final xray = ref.read(xrayServiceProvider);
    if (xray.status == VpnStatus.connected) {
      _wantConnected = false;
      _watch?.cancel();
      _watch = null;
      await xray.stop();
      ref.read(connectedSinceProvider.notifier).state = null;
      return;
    }
    await _start();
  }

  Future<void> _start() async {
    final xray = ref.read(xrayServiceProvider);
    final cfg = ref.read(activeConfigProvider);
    if (cfg == null) throw XrayException('Select a config first');
    final settings = ref.read(settingsProvider);
    try {
      await xray.start(cfg, settings);
    } catch (e) {
      if (!settings.autoSwitch || e.toString().contains('permission')) rethrow;
      // Auto-switch: try up to 3 other configs, best known ping first.
      final others = ref.read(configsProvider).where((c) => c.id != cfg.id && (c.pingMs ?? 1) >= 0).toList()
        ..sort((a, b) => (a.pingMs ?? 1 << 30).compareTo(b.pingMs ?? 1 << 30));
      var ok = false;
      for (final c in others.take(3)) {
        try {
          _log('Warn', 'auto-switch: trying ${c.name}');
          await xray.start(c, settings);
          ref.read(activeConfigIdProvider.notifier).set(c.id);
          ok = true;
          break;
        } catch (_) {/* try next */}
      }
      if (!ok) rethrow;
    }
    _wantConnected = true;
    ref.read(connectedSinceProvider.notifier).state = DateTime.now();
  }
}

final connectionControllerProvider = Provider<ConnectionController>((ref) {
  final c = ConnectionController(ref);
  ref.onDispose(c.dispose);
  return c;
});


// ---------------- Groups ----------------
class ConfigGroup {
  final String key;
  final String name;
  final Subscription? sub;
  final List<ProxyConfig> configs;
  const ConfigGroup({required this.key, required this.name, this.sub, required this.configs});
}

final configGroupsProvider = Provider<List<ConfigGroup>>((ref) {
  final configs = ref.watch(configsProvider);
  final subs = ref.watch(subscriptionsProvider);
  final sort = ref.watch(settingsProvider.select((s) => s.sort));

  int pingKey(ProxyConfig c) {
    final p = c.pingMs;
    if (p == null) return 1 << 30;
    if (p < 0) return 1 << 29;
    return p;
  }

  List<ProxyConfig> sorted(List<ProxyConfig> l) {
    final c = [...l];
    switch (sort) {
      case SortMode.added:
        break;
      case SortMode.name:
        c.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
        break;
      case SortMode.ping:
        c.sort((a, b) => pingKey(a).compareTo(pingKey(b)));
        break;
      case SortMode.protocol:
        c.sort((a, b) => a.protocol.index.compareTo(b.protocol.index));
        break;
    }
    return c;
  }

  final subIds = subs.map((s) => s.id).toSet();
  final manual = configs.where((c) => c.subscriptionId == null || !subIds.contains(c.subscriptionId)).toList();
  return [
    if (manual.isNotEmpty) ConfigGroup(key: 'manual', name: 'My configs', configs: sorted(manual)),
    for (final s in subs)
      ConfigGroup(
        key: s.id,
        name: s.name,
        sub: s,
        configs: sorted(configs.where((c) => c.subscriptionId == s.id).toList()),
      ),
  ];
});
