import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../models/connection_state.dart';
import '../theme.dart';
import 'anim.dart';

/// Neumorphic connect dial: a raised outer ring, a recessed track and a glowing
/// core whose colour follows the state (grey, orange, green).
class ConnectButton extends StatefulWidget {
  final VpnStatus status;
  final double size;
  final VoidCallback? onTap;
  const ConnectButton({super.key, required this.status, required this.size, this.onTap});

  @override
  State<ConnectButton> createState() => _ConnectButtonState();
}

class _ConnectButtonState extends State<ConnectButton> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2400))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  static const _orange = Color(0xFFF59A3C);

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = cs.brightness == Brightness.dark;
    final on = widget.status == VpnStatus.connected;
    final busy = widget.status == VpnStatus.connecting || widget.status == VpnStatus.disconnecting;
    final size = widget.size;
    final core = size * 0.44;
    final glow = on ? AppTheme.connected : (busy ? _orange : Colors.transparent);
    final hi = dark ? Colors.white.withValues(alpha: 0.05) : Colors.white;
    final lo = Colors.black.withValues(alpha: dark ? 0.55 : 0.16);
    final face = cs.surfaceContainer;

    return Pressable(
      scale: 0.96,
      autofocus: true,
      circle: true,
      onTap: busy ? null : widget.onTap,
      child: SizedBox(
        width: size,
        height: size,
        child: Stack(
          alignment: Alignment.center,
          clipBehavior: Clip.none,
          children: [
            // raised outer ring
            Container(
              width: size,
              height: size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color.lerp(face, Colors.white, dark ? 0.06 : 0.5)!, Color.lerp(face, Colors.black, dark ? 0.35 : 0.08)!],
                ),
                boxShadow: [
                  BoxShadow(color: lo, blurRadius: size * 0.10, offset: Offset(size * 0.04, size * 0.04)),
                  BoxShadow(color: hi, blurRadius: size * 0.08, offset: Offset(-size * 0.03, -size * 0.03)),
                ],
              ),
            ),
            // recessed track
            Container(
              width: size * 0.84,
              height: size * 0.84,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color.lerp(face, Colors.black, dark ? 0.45 : 0.10)!, Color.lerp(face, Colors.white, dark ? 0.04 : 0.4)!],
                ),
              ),
            ),
            // moving dots while busy / connected
            if (on || busy)
              AnimatedBuilder(
                animation: _c,
                builder: (context, _) => CustomPaint(
                  size: Size.square(size * 0.84),
                  painter: _DotsPainter(color: glow, t: _c.value, spin: busy),
                ),
              ),
            // inner face
            Container(
              width: size * 0.64,
              height: size * 0.64,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color.lerp(face, Colors.white, dark ? 0.05 : 0.5)!, Color.lerp(face, Colors.black, dark ? 0.3 : 0.06)!],
                ),
                boxShadow: [BoxShadow(color: lo.withValues(alpha: 0.5), blurRadius: size * 0.05, offset: Offset(0, size * 0.02))],
              ),
            ),
            // glowing core
            TweenAnimationBuilder<Color?>(
              tween: ColorTween(end: glow),
              duration: const Duration(milliseconds: 600),
              builder: (context, color, _) {
                final g = color ?? glow;
                final lit = on || busy;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 500),
                  width: core,
                  height: core,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: lit
                        ? RadialGradient(colors: [Color.lerp(g, Colors.white, 0.25)!, g])
                        : LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [Color.lerp(face, Colors.white, dark ? 0.04 : 0.6)!, Color.lerp(face, Colors.black, dark ? 0.35 : 0.08)!],
                          ),
                    boxShadow: lit ? [BoxShadow(color: g.withValues(alpha: 0.6), blurRadius: size * 0.16, spreadRadius: 1)] : const [],
                  ),
                  child: Center(
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 350),
                      transitionBuilder: (child, anim) =>
                          FadeTransition(opacity: anim, child: ScaleTransition(scale: anim, child: child)),
                      child: busy
                          ? SizedBox(
                              key: const ValueKey('busy'),
                              width: core * 0.4,
                              height: core * 0.4,
                              child: const CircularProgressIndicator(strokeWidth: 3, color: AppTheme.onAccent),
                            )
                          : Icon(
                              on ? Icons.verified_user_rounded : Icons.power_settings_new_rounded,
                              key: ValueKey(on),
                              size: core * 0.5,
                              color: on ? AppTheme.onAccent : cs.primary.withValues(alpha: 0.9),
                            ),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _DotsPainter extends CustomPainter {
  final Color color;
  final double t;
  final bool spin;
  _DotsPainter({required this.color, required this.t, required this.spin});

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 8;
    const n = 48;
    for (var i = 0; i < n; i++) {
      final a = i / n * 2 * math.pi - math.pi / 2;
      double alpha;
      if (spin) {
        final d = ((i / n) - t) % 1.0;
        alpha = d < 0.35 ? (1 - d / 0.35) : 0.12;
      } else {
        alpha = 0.55 + 0.35 * math.sin(t * 2 * math.pi + i * 0.4);
      }
      final p = Paint()..color = color.withValues(alpha: alpha.clamp(0.08, 1.0));
      canvas.drawCircle(c + Offset(math.cos(a), math.sin(a)) * r, 1.8, p);
    }
  }

  @override
  bool shouldRepaint(_DotsPainter o) => o.t != t || o.color != color || o.spin != spin;
}
