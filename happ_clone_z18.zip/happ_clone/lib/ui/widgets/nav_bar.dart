import '../theme.dart';
import 'package:flutter/material.dart';

import 'anim.dart';
import 'glass.dart';

class AppNavBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;
  const AppNavBar({super.key, required this.index, required this.onChanged});

  static const _items = [
    (Icons.home_rounded, 'Home'),
    (Icons.dns_rounded, 'Configs'),
    (Icons.receipt_long_rounded, 'Logs'),
    (Icons.settings_rounded, 'Settings'),
  ];

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      color: cs.surface,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
          child: Row(
            children: [
              for (var i = 0; i < _items.length; i++)
                Expanded(
                  child: _NavItem(
                    icon: _items[i].$1,
                    label: _items[i].$2,
                    selected: i == index,
                    onTap: () => onChanged(i),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _NavItem({required this.icon, required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final fg = selected ? cs.primary : cs.onSurfaceVariant;
    final ic = selected ? cs.primary : cs.onSurfaceVariant;
    return Pressable(
      scale: 0.9,
      onTap: onTap,
      child: Center(
        heightFactor: 1,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: cs.primary.withValues(alpha: selected ? 0.12 : 0),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AnimatedScale(
                scale: selected ? 1.1 : 1.0,
                duration: const Duration(milliseconds: 350),
                curve: Curves.easeOutBack,
                child: Icon(icon, size: 24, color: ic),
              ),
              const SizedBox(height: 2),
              AnimatedDefaultTextStyle(
                duration: const Duration(milliseconds: 300),
                style: TextStyle(fontSize: 12, fontWeight: selected ? FontWeight.w600 : FontWeight.w500, color: fg),
                child: Text(label),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Side navigation for Android TV (D-pad friendly).
class AppNavRail extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;
  const AppNavRail({super.key, required this.index, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      color: cs.surface,
      child: SizedBox(
        width: 112,
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (var i = 0; i < AppNavBar._items.length; i++)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
                  child: _NavItem(
                    icon: AppNavBar._items[i].$1,
                    label: AppNavBar._items[i].$2,
                    selected: i == index,
                    onTap: () => onChanged(i),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
