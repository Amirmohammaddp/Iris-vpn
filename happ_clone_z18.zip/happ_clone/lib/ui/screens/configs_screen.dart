import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers/providers.dart';
import '../add_actions.dart';
import '../widgets/anim.dart';
import '../widgets/glass.dart';
import '../widgets/groups_list.dart';

class ConfigsScreen extends ConsumerWidget {
  const ConfigsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cs = Theme.of(context).colorScheme;
    final groups = ref.watch(configGroupsProvider);
    final tv = ref.watch(isTvProvider);
    return SafeArea(
      bottom: false,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 16, 8),
            child: Row(
              children: [
                Text('Configs', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w600, color: cs.onSurface)),
                const Spacer(),
                AsyncGlassButton(icon: Icons.speed_rounded, onPressed: () => ref.read(configsProvider.notifier).pingAll()),
                const SizedBox(width: 8),
                AsyncGlassButton(
                  icon: Icons.sync_rounded,
                  onPressed: () async {
                    final m = ScaffoldMessenger.of(context);
                    final errs = await ref.read(subscriptionsProvider.notifier).refreshAll();
                    if (errs.isNotEmpty) m.showSnackBar(SnackBar(content: Text(errs.join('\n'))));
                  },
                ),
                const SizedBox(width: 8),
                Pressable(
                  circle: true,
                  onTap: () => AddActions.showMenu(context, ref, tv),
                  child: const GlassIcon(Icons.add_rounded, size: 36, iconSize: 22),
                ),
              ],
            ),
          ),
          Expanded(
            child: groups.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.cloud_off_rounded, size: 46, color: cs.onSurfaceVariant),
                        const SizedBox(height: 10),
                        const Text('No configs yet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 4),
                        Text('Tap + to add one', style: TextStyle(color: cs.onSurfaceVariant)),
                      ],
                    ),
                  )
                : ListView(padding: const EdgeInsets.only(top: 4, bottom: 30), children: [GroupsList(groups: groups)]),
          ),
        ],
      ),
    );
  }
}
