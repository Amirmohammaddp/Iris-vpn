import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/connection_state.dart';
import '../../models/proxy_config.dart';
import '../../providers/providers.dart';
import '../add_actions.dart';
import '../theme.dart';
import '../widgets/anim.dart';
import '../widgets/config_tile.dart';
import '../widgets/connect_button.dart';
import '../widgets/glass.dart';
import '../widgets/groups_list.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  Future<void> _toggle(BuildContext context, WidgetRef ref) async {
    try {
      await ref.read(connectionControllerProvider).toggle();
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final zen = ref.watch(settingsProvider.select((s) => s.zenMode));
    final status = ref.watch(vpnStatusProvider).valueOrNull ?? VpnStatus.disconnected;
    final groups = ref.watch(configGroupsProvider);
    final active = ref.watch(activeConfigProvider);
    final tv = ref.watch(isTvProvider);

    return SafeArea(
      bottom: false,
      child: Column(
        children: [
          _Header(
            onAdd: () => AddActions.showMenu(context, ref, tv),
          ),
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 450),
              switchInCurve: Curves.easeOutCubic,
              child: zen
                  ? KeyedSubtree(
                      key: const ValueKey('zen'),
                      child: _Zen(status: status, active: active, onToggle: () => _toggle(context, ref)),
                    )
                  : KeyedSubtree(
                      key: const ValueKey('full'),
                      child: ListView(
                        padding: const EdgeInsets.only(top: 18, bottom: 30),
                        children: [
                          FadeSlideIn(
                            child: _ConnectCard(
                              status: status,
                              active: active,
                              groups: groups,
                              onToggle: () => _toggle(context, ref),
                            ),
                          ),
                          const SizedBox(height: 22),
                          FadeSlideIn(
                            index: 1,
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(22, 0, 16, 10),
                              child: Row(
                                children: [
                                  Text('GROUPS',
                                      style: TextStyle(
                                          fontSize: 12,
                                          letterSpacing: 3,
                                          color: Theme.of(context).colorScheme.onSurfaceVariant)),
                                  const Spacer(),
                                  if (groups.isNotEmpty)
                                    GlassPill(
                                      icon: Icons.speed_rounded,
                                      label: 'Ping all',
                                      busyLabel: 'Testing…',
                                      onPressed: () => ref.read(configsProvider.notifier).pingAll(),
                                    ),
                                ],
                              ),
                            ),
                          ),
                          if (groups.isEmpty)
                            const _Empty()
                          else
                            GroupsList(groups: groups),
                        ],
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------

class _Header extends StatelessWidget {
  final VoidCallback onAdd;
  const _Header({required this.onAdd});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: SizedBox(
        height: 48,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Text('Iris',
                style: TextStyle(
                    fontFamily: 'Solene',
                    fontSize: 30,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 5,
                    color: cs.onSurface.withValues(alpha: 0.88))),
            Align(
              alignment: Alignment.centerRight,
              child: Pressable(circle: true, onTap: onAdd, child: const GlassIcon(Icons.add_rounded, size: 42, iconSize: 24)),
            ),
          ],
        ),
      ),
    );
  }
}

class _ConnectCard extends ConsumerWidget {
  final VpnStatus status;
  final ProxyConfig? active;
  final List<ConfigGroup> groups;
  final VoidCallback onToggle;
  const _ConnectCard({required this.status, required this.active, required this.groups, required this.onToggle});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cs = Theme.of(context).colorScheme;
    final dark = cs.brightness == Brightness.dark;
    final on = status == VpnStatus.connected;
    final busy = status == VpnStatus.connecting || status == VpnStatus.disconnecting;
    const orange = Color(0xFFF59A3C);
    final accent = on ? AppTheme.connected : (busy ? orange : cs.onSurfaceVariant);
    final label = switch (status) {
      VpnStatus.connected => 'CONNECTED',
      VpnStatus.connecting => 'CONNECTING...',
      VpnStatus.disconnecting => 'DISCONNECTING...',
      _ => 'NOT CONNECTED',
    };
    final a = active;
    final group = a == null ? null : groups.where((g) => g.configs.any((c) => c.id == a.id)).firstOrNull;
    final sub = group?.sub;
    final ping = a?.pingMs;
    final pingLabel = ping == null ? 'Test ping' : (ping < 0 ? 'timeout' : '$ping ms');
    final w = MediaQuery.of(context).size.width;
    final dial = (w * 0.74).clamp(220.0, 320.0);
    final sentence = a == null ? 'Tap + to add a config' : (on ? 'You are connected to ${a.name}' : 'Ready to connect to ${a.name}');

    return Column(
      children: [
        ConnectButton(status: status, size: dial, onTap: onToggle),
        const SizedBox(height: 22),
        Text(label, style: TextStyle(color: accent, fontSize: 15, letterSpacing: 2.5, fontWeight: FontWeight.w600)),
        const SizedBox(height: 4),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Text(sentence,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
        ),
        const SizedBox(height: 18),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              color: Color.lerp(cs.surface, Colors.white, dark ? 0.04 : 0.6),
              border: Border.all(color: (dark ? Colors.white : Colors.black).withValues(alpha: 0.07)),
              boxShadow: [
                BoxShadow(color: Colors.black.withValues(alpha: dark ? 0.45 : 0.10), blurRadius: 22, offset: const Offset(0, 10)),
              ],
            ),
            child: Column(
              children: [
                // glowing top edge (as in the reference)
                Container(
                  height: 2,
                  margin: const EdgeInsets.symmetric(horizontal: 40),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(2),
                    gradient: LinearGradient(colors: [accent.withValues(alpha: 0), accent, accent.withValues(alpha: 0)]),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 14, 18, 16),
                  child: a == null
                      ? Text('No config selected', style: TextStyle(fontSize: 15, color: cs.onSurfaceVariant))
                      : Column(
                          children: [
                            Row(
                              children: [
                                Text(a.flag, style: const TextStyle(fontSize: 22)),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(a.name,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w600, color: cs.onSurface)),
                                      Text('${a.protocol.label} - ${a.address}:${a.port}',
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          textDirection: TextDirection.ltr,
                                          style: TextStyle(fontSize: 11.5, color: cs.onSurfaceVariant)),
                                    ],
                                  ),
                                ),
                                if (on) const _Elapsed(),
                              ],
                            ),
                            const SizedBox(height: 14),
                            Row(
                              children: [
                                Expanded(
                                  child: GlassPill(
                                    icon: Icons.speed_rounded,
                                    label: pingLabel,
                                    busyLabel: 'Testing...',
                                    color: ping == null ? null : pingColor(ping),
                                    onPressed: () => ref.read(configsProvider.notifier).pingOne(a.id),
                                  ),
                                ),
                                if (sub != null) ...[
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: GlassPill(
                                      icon: Icons.sync_rounded,
                                      label: 'Update',
                                      busyLabel: 'Updating...',
                                      onPressed: () async {
                                        final messenger = ScaffoldMessenger.of(context);
                                        try {
                                          final c = await ref.read(subscriptionsProvider.notifier).refreshOne(sub.id);
                                          messenger.showSnackBar(SnackBar(content: Text('Updated: $c configs')));
                                        } catch (e) {
                                          messenger.showSnackBar(SnackBar(content: Text('$e')));
                                        }
                                      },
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ],
                        ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

/// Elapsed time since connecting.
class _Elapsed extends ConsumerStatefulWidget {
  const _Elapsed();
  @override
  ConsumerState<_Elapsed> createState() => _ElapsedState();
}

class _ElapsedState extends ConsumerState<_Elapsed> {
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final since = ref.watch(connectedSinceProvider);
    if (since == null) return const SizedBox.shrink();
    final d = DateTime.now().difference(since);
    String two(int v) => v.toString().padLeft(2, '0');
    final txt = '${two(d.inHours)}:${two(d.inMinutes % 60)}:${two(d.inSeconds % 60)}';
    return Text(txt,
        style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: Theme.of(context).colorScheme.onSurfaceVariant));
  }
}

// ---------------------------------------------------------------------------

class _Empty extends StatelessWidget {
  const _Empty();
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
      child: Glass(
        radius: 26,
        padding: const EdgeInsets.all(22),
        child: Column(
          children: [
            const GlassIcon(Icons.add_rounded, size: 54, iconSize: 30),
            const SizedBox(height: 12),
            Text('No configs yet', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: cs.onSurface)),
            const SizedBox(height: 4),
            Text('Tap + at the top to add a config or a subscription.',
                textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)),
          ],
        ),
      ),
    );
  }
}

/// Zen mode: just a big round button in the lower third, plus a tiny ping button.
class _Zen extends ConsumerWidget {
  final VpnStatus status;
  final ProxyConfig? active;
  final VoidCallback onToggle;
  const _Zen({required this.status, required this.active, required this.onToggle});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final a = active;
    final ping = a?.pingMs;
    final label = ping == null ? 'Test ping' : (ping < 0 ? 'timeout' : '$ping ms');
    return Stack(
      children: [
        Align(
          alignment: const Alignment(0, 0.3),
          child: ConnectButton(status: status, size: 210, onTap: onToggle),
        ),
        if (a != null)
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 18),
              child: GlassPill(
                icon: Icons.speed_rounded,
                label: label,
                busyLabel: 'Testing…',
                color: ping == null ? null : pingColor(ping),
                onPressed: () => ref.read(configsProvider.notifier).pingOne(a.id),
              ),
            ),
          ),
      ],
    );
  }
}
