import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../models/connection_state.dart';
import '../theme.dart';
import 'anim.dart';

/// A wall-style rocker switch drawn in layers (cast shadow, bevelled faces, crease,
/// rim light, engraved I / O marks and a coloured light spilling from the pressed end).
///
/// ON  : the bottom half protrudes and a faint yellow light spills under it.
/// OFF : the top half protrudes and the light is off.
class ConnectSwitch extends StatelessWidget {
  final VpnStatus status;
  final VoidCallback onToggle;
  final double width; // width of the plate itself
  final double height; // height of the plate itself
  const ConnectSwitch({
    super.key,
    required this.status,
    required this.onToggle,
    this.width = 84,
    this.height = 200,
  });

  @override
  Widget build(BuildContext context) {
    final on = status == VpnStatus.connected;
    final busy = status == VpnStatus.connecting || status == VpnStatus.disconnecting;
    final target = busy ? 0.5 : (on ? 1.0 : 0.0);
    final m = width * 0.5; // room for shadow and light
    return Pressable(
      scale: 0.985,
      autofocus: true,
      focusRadius: width / 2,
      onTap: busy ? null : onToggle,
      child: TweenAnimationBuilder<double>(
        tween: Tween(end: target),
        duration: const Duration(milliseconds: 420),
        curve: Curves.easeOutBack,
        builder: (context, t, _) => CustomPaint(
          size: Size(width + m * 2, height + m * 2),
          painter: _RockerPainter(t: t, margin: m, glow: AppTheme.yellow, busy: busy),
        ),
      ),
    );
  }
}

class _RockerPainter extends CustomPainter {
  final double t; // 0 off .. 1 on (may overshoot slightly)
  final double margin;
  final Color glow;
  final bool busy;
  _RockerPainter({required this.t, required this.margin, required this.glow, required this.busy});

  static Color _l(Color a, Color b, double x) => Color.lerp(a, b, x.clamp(0.0, 1.0))!;

  @override
  void paint(Canvas canvas, Size size) {
    final tc = t.clamp(0.0, 1.0);
    final w = size.width - margin * 2;
    final h = size.height - margin * 2;
    final r = w / 2;
    final plate = Rect.fromLTWH(margin, margin, w, h);
    final rrect = RRect.fromRectAndRadius(plate, Radius.circular(r));
    final crease = plate.top + h * (0.60 - 0.16 * t);

    Paint blur(Color c, double sigma) => Paint()
      ..color = c
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, sigma);

    // soft lighter veil around the key
    canvas.drawCircle(
      plate.center,
      h * 0.9,
      Paint()
        ..shader = RadialGradient(colors: [Colors.white.withValues(alpha: 0.045), Colors.white.withValues(alpha: 0)])
            .createShader(Rect.fromCircle(center: plate.center, radius: h * 0.9)),
    );

    // cast shadow (light comes from the top left)
    canvas.drawRRect(rrect.shift(Offset(w * 0.12, h * 0.07)), blur(Colors.black.withValues(alpha: 0.9), 9));

    // faint light spilling from the pressed (bottom) end
    if (tc > 0.01) {
      final under = RRect.fromRectAndRadius(
        Rect.fromLTRB(plate.left - 3, crease + 6, plate.right + 3, plate.bottom + 6),
        Radius.circular(r),
      );
      canvas.drawRRect(under, blur(glow.withValues(alpha: 0.26 * tc), 8));
      canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromLTWH(plate.left - 8, plate.bottom - 26, w + 16, 46), const Radius.circular(23)),
        blur(glow.withValues(alpha: 0.16 * tc), 15),
      );
    }

    canvas.save();
    canvas.clipRRect(rrect);

    // upper face
    final topRect = Rect.fromLTRB(plate.left, plate.top, plate.right, crease);
    canvas.drawRect(
      topRect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            _l(const Color(0xFF3A3A40), const Color(0xFF232327), tc),
            _l(const Color(0xFF2B2B30), const Color(0xFF212125), tc),
            _l(const Color(0xFF1C1C20), const Color(0xFF1D1D21), tc),
          ],
          stops: const [0, 0.35, 1],
        ).createShader(topRect),
    );
    // lower face
    final botRect = Rect.fromLTRB(plate.left, crease, plate.right, plate.bottom);
    canvas.drawRect(
      botRect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            _l(const Color(0xFF1D1D21), const Color(0xFF26262B), tc),
            _l(const Color(0xFF1F1F23), const Color(0xFF33333A), tc),
            _l(const Color(0xFF232327), const Color(0xFF46464E), tc),
          ],
          stops: const [0, 0.5, 1],
        ).createShader(botRect),
    );

    // shadow the protruding face throws on the receded one
    final a1 = 0.45 * tc;
    if (a1 > 0.01) {
      final rct = Rect.fromLTRB(plate.left, crease - 26, plate.right, crease);
      canvas.drawRect(
        rct,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.black.withValues(alpha: 0), Colors.black.withValues(alpha: a1)],
          ).createShader(rct),
      );
    }
    final a2 = 0.45 * (1 - tc);
    if (a2 > 0.01) {
      final rct = Rect.fromLTRB(plate.left, crease, plate.right, crease + 26);
      canvas.drawRect(
        rct,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.black.withValues(alpha: a2), Colors.black.withValues(alpha: 0)],
          ).createShader(rct),
      );
    }

    // thickness lip on the protruding end
    const lip = 7.0;
    final lipBot = Rect.fromLTRB(plate.left, plate.bottom - lip, plate.right, plate.bottom);
    canvas.drawRect(
      lipBot,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.white.withValues(alpha: 0.20 * tc), Colors.white.withValues(alpha: 0.04 * tc)],
        ).createShader(lipBot),
    );
    final lipTop = Rect.fromLTRB(plate.left, plate.top, plate.right, plate.top + lip);
    canvas.drawRect(
      lipTop,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.white.withValues(alpha: 0.22 * (1 - tc)), Colors.white.withValues(alpha: 0.03 * (1 - tc))],
        ).createShader(lipTop),
    );

    // crease
    canvas.drawRect(Rect.fromLTWH(plate.left, crease - 0.6, w, 1.3), Paint()..color = Colors.black.withValues(alpha: 0.9));
    canvas.drawRect(Rect.fromLTWH(plate.left, crease + 0.7, w, 1), Paint()..color = Colors.white.withValues(alpha: 0.10));

    // side light: lit on the left, darker on the right
    canvas.drawRect(
      plate,
      Paint()
        ..shader = LinearGradient(
          colors: [
            Colors.white.withValues(alpha: 0.07),
            Colors.white.withValues(alpha: 0),
            Colors.black.withValues(alpha: 0),
            Colors.black.withValues(alpha: 0.30),
          ],
          stops: const [0, 0.18, 0.82, 1],
        ).createShader(plate),
    );
    canvas.restore();

    // rim light
    canvas.drawRRect(
      rrect.deflate(0.6),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withValues(alpha: 0.35),
            Colors.white.withValues(alpha: 0.06),
            Colors.white.withValues(alpha: 0.18),
          ],
          stops: const [0, 0.5, 1],
        ).createShader(plate),
    );

    // engraved marks: "I" (top) and "O" (bottom)
    final cx = plate.center.dx;
    final iPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 2.4
      ..color = _l(const Color(0xFFBEBEC6).withValues(alpha: 0.8), const Color(0xFF96969E).withValues(alpha: 0.55), tc);
    canvas.drawLine(Offset(cx, plate.top + h * 0.14), Offset(cx, plate.top + h * 0.14 + w * 0.2), iPaint);
    final oc = Offset(cx, plate.top + h * 0.86);
    final oPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.4
      ..color = _l(const Color(0xFF78787E).withValues(alpha: 0.55), const Color(0xFFEBEBF0).withValues(alpha: 0.9), tc);
    if (tc > 0.05) {
      canvas.drawCircle(
        oc,
        w * 0.11,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3
          ..color = glow.withValues(alpha: 0.7 * tc)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3),
      );
    }
    canvas.drawCircle(oc, w * 0.11, oPaint);
    if (busy) {
      canvas.drawCircle(
        plate.center,
        w * 0.08,
        Paint()..color = Colors.white.withValues(alpha: 0.35),
      );
    }
  }

  @override
  bool shouldRepaint(_RockerPainter o) => o.t != t || o.margin != margin || o.glow != glow || o.busy != busy;
}

/// Small round "iris" button under the switch: shows ping, taps to refresh.
class IrisButton extends StatefulWidget {
  final bool lit;
  final bool busy;
  final VoidCallback? onTap;
  final double size;
  const IrisButton({super.key, required this.lit, required this.busy, this.onTap, this.size = 46});

  @override
  State<IrisButton> createState() => _IrisButtonState();
}

class _IrisButtonState extends State<IrisButton> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 3));

  @override
  void didUpdateWidget(IrisButton old) {
    super.didUpdateWidget(old);
    if (widget.busy && !_c.isAnimating) _c.repeat();
    if (!widget.busy && _c.isAnimating) _c.stop();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Pressable(
      circle: true,
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) => CustomPaint(
          size: Size.square(widget.size + 16),
          painter: _IrisPainter(lit: widget.lit, busy: widget.busy, spin: _c.value, glow: AppTheme.yellow),
        ),
      ),
    );
  }
}

class _IrisPainter extends CustomPainter {
  final bool lit;
  final bool busy;
  final double spin;
  final Color glow;
  _IrisPainter({required this.lit, required this.busy, required this.spin, required this.glow});

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 8;
    canvas.drawCircle(c + const Offset(3, 4), r, Paint()..color = Colors.black.withValues(alpha: 0.8)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3));
    final disc = Rect.fromCircle(center: c, radius: r);
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF3B3B41), Color(0xFF16161A)],
        ).createShader(disc),
    );
    canvas.drawCircle(c, r, Paint()..style = PaintingStyle.stroke..strokeWidth = 1..color = Colors.white.withValues(alpha: 0.16));
    canvas.drawCircle(c, r - 5, Paint()..color = const Color(0xFF0B0B0D));
    final lightOn = lit || busy;
    final col = lightOn ? glow : const Color(0xFF6B6B73);
    if (lightOn) {
      canvas.drawCircle(c, r - 8, Paint()..color = glow.withValues(alpha: 0.35)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3));
    }
    final p = Paint()
      ..color = col
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < 24; i++) {
      final a = i / 24 * 2 * math.pi + (busy ? spin * 2 * math.pi : 0);
      var f = 1.0;
      if (busy) {
        final d = ((i / 24) - spin) % 1.0;
        f = d < 0.4 ? 1 - d / 0.4 * 0.7 : 0.3;
      }
      final r2 = lightOn ? 10.5 : 9.0;
      p.color = col.withValues(alpha: f);
      canvas.drawLine(c + Offset(math.cos(a), math.sin(a)) * 5, c + Offset(math.cos(a), math.sin(a)) * r2, p);
    }
  }

  @override
  bool shouldRepaint(_IrisPainter o) => o.lit != lit || o.busy != busy || o.spin != spin;
}
