import 'package:flutter/material.dart';

class AppTheme {
  static const purple = Color(0xFF7C4DFF);
  static const blue = Color(0xFF2979FF);
  static const gradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [purple, blue],
  );
  static const connected = Color(0xFF2ED8A3);
  static const connecting = Color(0xFFFFB454);
  static const danger = Color(0xFFFF5C7A);

  static ThemeData dark() => _build(Brightness.dark);
  static ThemeData light() => _build(Brightness.light);

  static ThemeData _build(Brightness b) {
    final dark = b == Brightness.dark;
    final base = ColorScheme.fromSeed(seedColor: const Color(0xFF4F8CFF), brightness: b);
    final scheme = base.copyWith(
      primary: dark ? const Color(0xFF8AB4F8) : const Color(0xFF2B6BE0),
      surface: dark ? const Color(0xFF10131A) : const Color(0xFFF3F5FA),
      surfaceContainer: dark ? const Color(0xFF171A21) : const Color(0xFFEBEEF5),
      surfaceContainerHigh: dark ? const Color(0xFF1B1F27) : Colors.white,
      surfaceContainerHighest: dark ? const Color(0xFF262B36) : const Color(0xFFE3E7F0),
      secondaryContainer: dark ? const Color(0xFF5A3A0A) : const Color(0xFFFFE0B2),
      onSecondaryContainer: dark ? const Color(0xFFFFD9A0) : const Color(0xFF5A3A0A),
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: scheme.surface,
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(color: scheme.primary, fontSize: 22, fontWeight: FontWeight.w800),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      inputDecorationTheme: InputDecorationThemeData(
        filled: true,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}
