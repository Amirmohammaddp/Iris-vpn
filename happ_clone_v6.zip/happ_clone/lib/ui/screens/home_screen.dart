import 'dart:async';
import 'dart:ui' show lerpDouble;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/connection_state.dart';
import '../../models/proxy_config.dart';
import '../../providers/providers.dart';
import '../theme.dart';
import '../widgets/anim.dart';
import '../widgets/config_tile.dart';
import '../widgets/connect_button.dart';
import '../widgets/groups_list.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});
  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final Animation<double> _t;
  bool _listOpen = false;

  @override
  void initState() {
    super.initState();
    final now = ref.read(vpnStatusProvider).valueOrNull;
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
      value: now == VpnStatus.connected ? 1 : 0,
    );
    _t = CurvedAnimation(parent: _c, curve: Curves.easeInOutCubic);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    try {
      await ref.read(connectionControllerProvider).toggle();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<AsyncValue<VpnStatus>>(vpnStatusProvider, (prev, next) {
      if (next.valueOrNull == VpnStatus.connected) {
        _c.forward();
      } else {
        _c.reverse();
      }
    });
    final zen = ref.watch(settingsProvider.select((s) => s.zenMode));
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 450),
      switchInCurve: Curves.easeOutCubic,
      child: zen
          ? KeyedSubtree(key: const ValueKey('zen'), child: _zen())
          : KeyedSubtree(key: const ValueKey('full'), child: _full(context)),
    );
  }

  // ---------- Zen mode: only a round button in the lower third ----------
  Widget _zen() {
    final status = ref.watch(vpnStatusProvider).valueOrNull ?? VpnStatus.disconnected;
    return Align(
      alignment: const Alignment(0, 0.42),
      child: ConnectButton(status: status, size: 210, onTap: _toggle),
    );
  }

  // ---------- Full home ----------
  Widget _full(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final status = ref.watch(vpnStatusProvider).valueOrNull ?? VpnStatus.disconnected;
    final traffic = ref.watch(trafficProvider).valueOrNull ?? TrafficStats.zero;
    final active = ref.watch(activeConfigProvider);
    final groups = ref.watch(configGroupsProvider);

    final ag = active == null
        ? null
        : groups.where((g) => g.configs.any((c) => c.id == active.id)).firstOrNull;
    final others = groups.where((g) => g.key != ag?.key).toList();
    final w = MediaQuery.sizeOf(context).width;

    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.only(bottom: 170),
        children: [
          AnimatedBuilder(
            animation: _t,
            builder: (context, _) {
              final t = _t.value;
              final stageH = lerpDouble(300, 148, t)!;
              final size = lerpDouble(188, 88, t)!;
              final left = lerpDouble((w - 188) / 2, 30, t)!;
              final top = lerpDouble(40, 104, t)!;
              return Stack(
                clipBehavior: Clip.none,
                children: [
                  Column(
                    children: [
                      SizedBox(height: stageH),
                      _InfoCard(
                        t: t,
                        active: active,
                        group: ag,
                        traffic: traffic,
                        status: status,
                        listOpen: _listOpen,
                        onToggleList: () => setState(() => _listOpen = !_listOpen),
                        tiles: ag == null ? const <Widget>[] : configTiles(ref, context, ag.configs, active?.id),
                      ),
                    ],
                  ),
                  Positioned(
                    left: lerpDouble(0, 30 + 88 + 16, t)!,
                    right: 0,
                    top: lerpDouble(252, 158, t)!,
                    child: IgnorePointer(
                      child: Align(
                        heightFactor: 1,
                        alignment: Alignment.lerp(Alignment.center, Alignment.centerLeft, t)!,
                        child: _StatusText(status: status),
                      ),
                    ),
                  ),
                  Positioned(
                    left: left,
                    top: top,
                    child: ConnectButton(status: status, size: size, onTap: _toggle),
                  ),
                ],
              );
            },
          ),
          if (others.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(26, 22, 16, 6),
              child: Text(
                ag == null ? 'GROUPS' : 'OTHER GROUPS',
                style: TextStyle(
                    fontSize: 12, letterSpacing: 1.4, fontWeight: FontWeight.w700, color: cs.onSurfaceVariant),
              ),
            ),
            GroupsList(groups: others),
          ],
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------

class _StatusText extends StatelessWidget {
  final VpnStatus status;
  const _StatusText({required this.status});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final (label, color) = switch (status) {
      VpnStatus.connected => ('CONNECTED', AppTheme.connected),
      VpnStatus.connecting => ('CONNECTING…', AppTheme.connecting),
      VpnStatus.disconnecting => ('DISCONNECTING…', AppTheme.connecting),
      _ => ('NOT CONNECTED', cs.onSurfaceVariant),
    };
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          child: Text(
            label,
            key: ValueKey(label),
            style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 15, letterSpacing: 1.2),
          ),
        ),
        AnimatedSize(
          duration: const Duration(milliseconds: 300),
          child: status == VpnStatus.connected ? const _Timer() : const SizedBox(width: 1),
        ),
      ],
    );
  }
}

class _Timer extends ConsumerStatefulWidget {
  const _Timer();
  @override
  ConsumerState<_Timer> createState() => _TimerState();
}

class _TimerState extends ConsumerState<_Timer> {
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final since = ref.watch(connectedSinceProvider);
    final d = since == null ? Duration.zero : DateTime.now().difference(since);
    String two(int n) => n.toString().padLeft(2, '0');
    return Text(
      '${two(d.inHours)}:${two(d.inMinutes % 60)}:${two(d.inSeconds % 60)}',
      textDirection: TextDirection.ltr,
      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w300, fontFeatures: [FontFeature.tabularFigures()]),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final double t;
  final ProxyConfig? active;
  final ConfigGroup? group;
  final TrafficStats traffic;
  final VpnStatus status;
  final bool listOpen;
  final VoidCallback onToggleList;
  final List<Widget> tiles;

  const _InfoCard({
    required this.t,
    required this.active,
    required this.group,
    required this.traffic,
    required this.status,
    required this.listOpen,
    required this.onToggleList,
    required this.tiles,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final on = status == VpnStatus.connected;
    final a = active;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: EdgeInsets.fromLTRB(20, lerpDouble(22, 60, t)!, 20, 12),
      decoration: BoxDecoration(
        color: cs.surfaceContainerHigh,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: cs.outlineVariant.withValues(alpha: 0.35)),
      ),
      child: a == null ? _empty(context) : _content(context, a, on),
    );
  }

  Widget _empty(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Column(
        children: [
          Icon(Icons.cloud_off_rounded, size: 40, color: cs.onSurfaceVariant),
          const SizedBox(height: 10),
          const Text('No config selected', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text('Tap “Add your config” below to get started',
              textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)),
        ],
      ),
    );
  }

  Widget _content(BuildContext context, ProxyConfig a, bool on) {
    final cs = Theme.of(context).colorScheme;
    final p = a.params;
    final details = <(String, String?)>[
      ('Protocol', a.protocol.label),
      ('Transport', (p['type'] ?? 'tcp').toUpperCase()),
      ('Security', (p['security'] ?? (a.protocol == ProxyProtocol.trojan ? 'tls' : 'none')).toUpperCase()),
      ('SNI', p['sni']),
      ('Host', p['host']),
      ('Path', p['path'] ?? p['serviceName']),
      ('Flow', p['flow']),
      ('Fingerprint', p['fp']),
      ('Method', p['method']),
    ].where((e) => e.$2 != null && e.$2!.isNotEmpty).toList();

    final ping = a.pingMs;
    final n = group?.configs.length ?? 0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text('ACTIVE CONFIGURATION',
                style: TextStyle(fontSize: 11.5, letterSpacing: 1.3, fontWeight: FontWeight.w700, color: cs.primary)),
            const Spacer(),
            if (ping != null)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                decoration: BoxDecoration(
                  color: pingColor(ping).withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(ping < 0 ? 'timeout' : '$ping ms',
                    style: TextStyle(color: pingColor(ping), fontWeight: FontWeight.w700, fontSize: 12)),
              ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Text(a.flag, style: const TextStyle(fontSize: 30)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(a.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 2),
                  Text('${a.address}:${a.port}',
                      textDirection: TextDirection.ltr,
                      style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13)),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        LayoutBuilder(builder: (context, box) {
          final cell = (box.maxWidth - 12) / 2;
          return Wrap(
            spacing: 12,
            runSpacing: 10,
            children: [
              for (final d in details)
                SizedBox(
                  width: cell,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(d.$1, style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
                      Text(d.$2!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textDirection: TextDirection.ltr,
                          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
                    ],
                  ),
                ),
            ],
          );
        }),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Divider(height: 1, color: cs.outlineVariant.withValues(alpha: 0.5)),
        ),
        Row(
          children: [
            Expanded(
              child: _Stat(
                label: 'Uplink',
                icon: Icons.arrow_upward_rounded,
                speed: formatBytes(traffic.upBps, perSecond: true),
                total: formatBytes(traffic.totalUp),
                color: on ? AppTheme.connected : cs.onSurfaceVariant,
              ),
            ),
            Expanded(
              child: _Stat(
                label: 'Downlink',
                icon: Icons.arrow_downward_rounded,
                speed: formatBytes(traffic.downBps, perSecond: true),
                total: formatBytes(traffic.totalDown),
                color: on ? cs.primary : cs.onSurfaceVariant,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Pressable(
          scale: 0.97,
          onTap: onToggleList,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: cs.surfaceContainerHighest.withValues(alpha: 0.7),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Row(
              children: [
                Icon(Icons.layers_rounded, size: 20, color: cs.primary),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    '${listOpen ? 'Hide' : 'Show'} configs in ${group?.name ?? 'group'} ($n)',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                AnimatedRotation(
                  turns: listOpen ? 0.5 : 0,
                  duration: const Duration(milliseconds: 320),
                  curve: Curves.easeInOutCubic,
                  child: const Icon(Icons.expand_more_rounded),
                ),
              ],
            ),
          ),
        ),
        AnimatedSize(
          duration: const Duration(milliseconds: 380),
          curve: Curves.easeInOutCubic,
          alignment: Alignment.topCenter,
          child: listOpen
              ? Padding(padding: const EdgeInsets.only(top: 6), child: Column(children: tiles))
              : const SizedBox(width: double.infinity),
        ),
      ],
    );
  }
}

class _Stat extends StatelessWidget {
  final String label, speed, total;
  final IconData icon;
  final Color color;
  const _Stat({required this.label, required this.icon, required this.speed, required this.total, required this.color});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Column(
      children: [
        Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 14)),
        const SizedBox(height: 4),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Flexible(
              child: Text(speed,
                  textDirection: TextDirection.ltr,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 16)),
            ),
            const SizedBox(width: 4),
            Icon(icon, size: 18, color: color),
          ],
        ),
        Text('Total $total', style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
      ],
    );
  }
}
