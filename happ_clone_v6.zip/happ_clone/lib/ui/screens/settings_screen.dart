import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../constants.dart';
import '../../models/app_settings.dart';
import '../../providers/providers.dart';
import '../../services/links.dart';
import '../widgets/anim.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cs = Theme.of(context).colorScheme;
    final st = ref.watch(settingsProvider);
    final n = ref.read(settingsProvider.notifier);

    Widget card(int index, String title, IconData icon, List<Widget> children) => FadeSlideIn(
          index: index,
          child: Container(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 14),
            child: Material(
              color: cs.surfaceContainerHigh,
              borderRadius: BorderRadius.circular(26),
              clipBehavior: Clip.antiAlias,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Icon(icon, color: cs.primary, size: 22),
                      const SizedBox(width: 10),
                      Text(title, style: TextStyle(color: cs.primary, fontWeight: FontWeight.w800, fontSize: 15)),
                    ]),
                    const SizedBox(height: 12),
                    ...children,
                  ],
                ),
              ),
            ),
          ),
        );

    Widget label(String t) => Padding(
          padding: const EdgeInsets.only(top: 6, bottom: 8),
          child: Text(t, style: TextStyle(fontSize: 12.5, color: cs.onSurfaceVariant, fontWeight: FontWeight.w600)),
        );

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.only(top: 6, bottom: 40),
        children: [
          card(0, 'Appearance', Icons.palette_rounded, [
            label('Color palette'),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<AppThemeMode>(
                segments: const [
                  ButtonSegment(value: AppThemeMode.dark, label: Text('Night'), icon: Icon(Icons.dark_mode_rounded)),
                  ButtonSegment(value: AppThemeMode.light, label: Text('Day'), icon: Icon(Icons.light_mode_rounded)),
                ],
                selected: {st.theme},
                onSelectionChanged: (v) => n.update((x) => x.copyWith(theme: v.first)),
              ),
            ),
            label('Sort configs by'),
            Wrap(spacing: 8, runSpacing: 4, children: [
              for (final (m, t) in const [
                (SortMode.added, 'Added order'),
                (SortMode.name, 'Name'),
                (SortMode.ping, 'Ping'),
                (SortMode.protocol, 'Protocol'),
              ])
                ChoiceChip(
                  label: Text(t),
                  selected: st.sort == m,
                  onSelected: (_) => n.update((x) => x.copyWith(sort: m)),
                ),
            ]),
            const SizedBox(height: 4),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: const Icon(Icons.spa_rounded),
              title: const Text('Zen mode'),
              subtitle: const Text('Home shows only one round connect button'),
              value: st.zenMode,
              onChanged: (v) => n.update((x) => x.copyWith(zenMode: v)),
            ),
          ]),
          card(1, 'Connection', Icons.vpn_lock_rounded, [
            label('Connection mode'),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<ConnectionMode>(
                segments: const [
                  ButtonSegment(value: ConnectionMode.vpn, label: Text('VPN (TUN)'), icon: Icon(Icons.vpn_lock_rounded)),
                  ButtonSegment(value: ConnectionMode.proxy, label: Text('Proxy'), icon: Icon(Icons.lan_rounded)),
                ],
                selected: {st.mode},
                onSelectionChanged: (v) => n.update((x) => x.copyWith(mode: v.first)),
              ),
            ),
            label('Routing'),
            Wrap(spacing: 8, runSpacing: 4, children: [
              for (final (r, t) in const [
                (RoutingMode.global, 'Global'),
                (RoutingMode.ruleBased, 'Smart (IR direct)'),
                (RoutingMode.direct, 'Direct'),
              ])
                ChoiceChip(
                  label: Text(t),
                  selected: st.routing == r,
                  onSelected: (_) => n.update((x) => x.copyWith(routing: r)),
                ),
            ]),
            label('DNS'),
            TextFormField(
              initialValue: st.useDoh ? st.dohUrl : st.dns,
              key: ValueKey(st.useDoh),
              textDirection: TextDirection.ltr,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.dns_rounded),
                labelText: st.useDoh ? 'DoH URL' : 'DNS server',
              ),
              onChanged: (v) => n.update((x) => st.useDoh ? x.copyWith(dohUrl: v) : x.copyWith(dns: v)),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Use DNS over HTTPS'),
              value: st.useDoh,
              onChanged: (v) => n.update((x) => x.copyWith(useDoh: v)),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: const Icon(Icons.shield_rounded),
              title: const Text('Kill switch'),
              subtitle: const Text('Block traffic when VPN drops'),
              value: st.killSwitch,
              onChanged: (v) => n.update((x) => x.copyWith(killSwitch: v)),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: const Icon(Icons.bolt_rounded),
              title: const Text('Auto connect'),
              value: st.autoConnect,
              onChanged: (v) => n.update((x) => x.copyWith(autoConnect: v)),
            ),
            label('Split tunneling (excluded apps)'),
            TextFormField(
              initialValue: st.excludedApps.join(', '),
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(
                hintText: 'Package names, comma-separated',
                prefixIcon: Icon(Icons.call_split_rounded),
              ),
              onChanged: (v) => n.update((x) => x.copyWith(
                  excludedApps: v.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList())),
            ),
            const SizedBox(height: 6),
          ]),
          card(2, 'Support', Icons.support_agent_rounded, [
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.telegram),
              title: const Text('Contact us'),
              subtitle: const Text('@$kTelegramId'),
              trailing: IconButton(
                tooltip: 'Copy ID',
                icon: const Icon(Icons.copy_rounded, size: 20),
                onPressed: () async {
                  await Clipboard.setData(const ClipboardData(text: '@$kTelegramId'));
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Telegram ID copied')));
                  }
                },
              ),
              onTap: () => openTelegram(context),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.shopping_cart_rounded),
              title: const Text('Buy subscription'),
              subtitle: const Text('Opens Telegram chat'),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => openTelegram(context),
            ),
          ]),
        ],
      ),
    );
  }
}
