import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers/providers.dart';
import '../widgets/anim.dart';
import '../widgets/groups_list.dart';

class ConfigsScreen extends ConsumerStatefulWidget {
  const ConfigsScreen({super.key});
  @override
  ConsumerState<ConfigsScreen> createState() => _ConfigsScreenState();
}

class _ConfigsScreenState extends ConsumerState<ConfigsScreen> {
  bool _busy = false;

  void _toast(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _run(Future<void> Function() f) async {
    setState(() => _busy = true);
    try {
      await f();
    } catch (e) {
      _toast('$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final groups = ref.watch(configGroupsProvider);
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: const Text('Configs'),
        actions: [
          IconButton(
            tooltip: 'Test ping for all',
            icon: const Icon(Icons.speed_rounded),
            onPressed: _busy ? null : () => _run(ref.read(configsProvider.notifier).pingAll),
          ),
          IconButton(
            tooltip: 'Update subscriptions',
            icon: const Icon(Icons.sync_rounded),
            onPressed: _busy
                ? null
                : () => _run(() async {
                      final errs = await ref.read(subscriptionsProvider.notifier).refreshAll();
                      if (errs.isNotEmpty) _toast(errs.join('\n'));
                    }),
          ),
        ],
      ),
      body: Column(
        children: [
          AnimatedSize(
            duration: const Duration(milliseconds: 250),
            child: _busy ? const LinearProgressIndicator() : const SizedBox(width: double.infinity),
          ),
          Expanded(
            child: groups.isEmpty
                ? Center(
                    child: FadeSlideIn(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.cloud_off_rounded, size: 48, color: cs.onSurfaceVariant),
                          const SizedBox(height: 10),
                          const Text('No configs yet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                          const SizedBox(height: 4),
                          Text('Tap “Add your config” below', style: TextStyle(color: cs.onSurfaceVariant)),
                        ],
                      ),
                    ),
                  )
                : ListView(
                    padding: const EdgeInsets.only(top: 6, bottom: 170),
                    children: [GroupsList(groups: groups)],
                  ),
          ),
        ],
      ),
    );
  }
}
