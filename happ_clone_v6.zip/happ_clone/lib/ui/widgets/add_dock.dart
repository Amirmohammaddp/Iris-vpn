import 'package:flutter/material.dart';

import 'anim.dart';
import 'glass.dart';

enum AddKind { qr, clipboard, subscription, manual }

/// Large glass button at the bottom: "Add your config". Tapping it morphs
/// into a panel with the four add options.
class AddDock extends StatelessWidget {
  final bool open;
  final VoidCallback onToggle;
  final ValueChanged<AddKind> onPick;
  const AddDock({super.key, required this.open, required this.onToggle, required this.onPick});

  static const _options = [
    (AddKind.qr, Icons.qr_code_scanner_rounded, 'Add with QR code'),
    (AddKind.clipboard, Icons.content_paste_rounded, 'Add from clipboard'),
    (AddKind.subscription, Icons.rss_feed_rounded, 'Add subscription link'),
    (AddKind.manual, Icons.edit_note_rounded, 'Add manually'),
  ];

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Glass(
      radius: 30,
      child: AnimatedSize(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOutCubic,
        alignment: Alignment.bottomCenter,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (open)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
                child: Column(
                  children: [
                    for (var i = 0; i < _options.length; i++)
                      FadeSlideIn(
                        index: i,
                        child: _Option(
                          icon: _options[i].$2,
                          label: _options[i].$3,
                          onTap: () => onPick(_options[i].$1),
                        ),
                      ),
                  ],
                ),
              ),
            Pressable(
              scale: 0.97,
              onTap: onToggle,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AnimatedRotation(
                      turns: open ? 0.125 : 0,
                      duration: const Duration(milliseconds: 400),
                      curve: Curves.easeInOutBack,
                      child: Icon(Icons.add_rounded, size: 30, color: cs.primary),
                    ),
                    const SizedBox(width: 10),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 250),
                      child: Text(
                        open ? 'Close' : 'Add your config',
                        key: ValueKey(open),
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: cs.onSurface),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Option extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _Option({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Pressable(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: cs.primary.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(shape: BoxShape.circle, color: cs.primary.withValues(alpha: 0.22)),
              child: Icon(icon, color: cs.primary, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(label, style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w600, color: cs.onSurface)),
            ),
            Icon(Icons.chevron_right_rounded, color: cs.onSurfaceVariant),
          ],
        ),
      ),
    );
  }
}
