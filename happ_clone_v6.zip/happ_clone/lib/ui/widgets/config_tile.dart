import 'package:flutter/material.dart';

import '../../models/proxy_config.dart';
import '../theme.dart';

Color pingColor(int ms) =>
    ms < 0 ? AppTheme.danger : (ms < 200 ? AppTheme.connected : (ms < 500 ? AppTheme.connecting : AppTheme.danger));

/// Compact row for one config inside a group.
class ConfigTile extends StatelessWidget {
  final ProxyConfig config;
  final bool selected;
  final VoidCallback? onTap;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  const ConfigTile({
    super.key,
    required this.config,
    this.selected = false,
    this.onTap,
    this.onEdit,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final ping = config.pingMs;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
      margin: const EdgeInsets.symmetric(vertical: 4),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: selected ? cs.primary.withValues(alpha: 0.16) : cs.surfaceContainerHighest.withValues(alpha: 0.55),
        border: Border.all(color: selected ? cs.primary : Colors.transparent, width: 1.2),
      ),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 4, 10),
            child: Row(
              children: [
                Text(config.flag, style: const TextStyle(fontSize: 24)),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(config.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                      const SizedBox(height: 2),
                      Text('${config.protocol.label} • ${config.address}:${config.port}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textDirection: TextDirection.ltr,
                          style: TextStyle(fontSize: 11.5, color: cs.onSurfaceVariant)),
                    ],
                  ),
                ),
                if (ping != null)
                  Padding(
                    padding: const EdgeInsets.only(left: 6),
                    child: Text(
                      ping < 0 ? 'timeout' : '$ping ms',
                      style: TextStyle(color: pingColor(ping), fontWeight: FontWeight.w700, fontSize: 12),
                    ),
                  ),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 250),
                  transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c),
                  child: selected
                      ? Padding(
                          key: const ValueKey('on'),
                          padding: const EdgeInsets.only(left: 6),
                          child: Icon(Icons.check_circle_rounded, color: cs.primary, size: 20),
                        )
                      : const SizedBox(key: ValueKey('off'), width: 6),
                ),
                if (onEdit != null || onDelete != null)
                  PopupMenuButton<int>(
                    icon: Icon(Icons.more_vert_rounded, size: 20, color: cs.onSurfaceVariant),
                    onSelected: (v) => v == 0 ? onEdit?.call() : onDelete?.call(),
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 0, child: Text('Edit')),
                      PopupMenuItem(value: 1, child: Text('Delete')),
                    ],
                  )
                else
                  const SizedBox(width: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
