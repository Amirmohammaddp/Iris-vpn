import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/providers.dart';
import 'screens/config_edit_screen.dart';
import 'screens/qr_scan_screen.dart';

/// The four ways to add configs. All text is English.
class AddActions {
  static void toast(BuildContext c, String m) =>
      ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

  static bool _isUrl(String t) => !t.contains('\n') && (t.startsWith('http://') || t.startsWith('https://'));

  static Future<void> _addText(BuildContext c, WidgetRef ref, String text) async {
    final t = text.trim();
    if (t.isEmpty) {
      toast(c, 'Nothing to add');
      return;
    }
    if (_isUrl(t)) {
      await _addSub(c, ref, t);
      return;
    }
    try {
      final n = ref.read(configsProvider.notifier).addFromText(t);
      toast(c, n == 1 ? '1 config added' : '$n configs added');
    } catch (e) {
      toast(c, '$e');
    }
  }

  static Future<void> _addSub(BuildContext c, WidgetRef ref, String url) async {
    toast(c, 'Fetching subscription…');
    try {
      final n = await ref.read(subscriptionsProvider.notifier).add(url.trim());
      if (c.mounted) toast(c, n == 1 ? '1 config added' : '$n configs added');
    } catch (e) {
      if (c.mounted) toast(c, '$e');
    }
  }

  static Future<void> clipboard(BuildContext c, WidgetRef ref) async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    if (!c.mounted) return;
    final t = d?.text?.trim() ?? '';
    if (t.isEmpty) {
      toast(c, 'Clipboard is empty');
      return;
    }
    await _addText(c, ref, t);
  }

  static Future<void> qr(BuildContext c, WidgetRef ref) async {
    final t = await Navigator.push<String>(c, MaterialPageRoute<String>(builder: (_) => const QrScanScreen()));
    if (t == null || !c.mounted) return;
    await _addText(c, ref, t);
  }

  static Future<void> subscription(BuildContext c, WidgetRef ref) async {
    final ctrl = TextEditingController();
    final url = await showDialog<String>(
      context: c,
      builder: (ctx) => AlertDialog(
        title: const Text('Subscription link'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          textDirection: TextDirection.ltr,
          keyboardType: TextInputType.url,
          decoration: const InputDecoration(hintText: 'https://…'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: const Text('Add')),
        ],
      ),
    );
    if (url == null || url.trim().isEmpty || !c.mounted) return;
    await _addSub(c, ref, url);
  }

  static void manual(BuildContext c) {
    Navigator.push(c, MaterialPageRoute<void>(builder: (_) => const ConfigEditScreen()));
  }
}
