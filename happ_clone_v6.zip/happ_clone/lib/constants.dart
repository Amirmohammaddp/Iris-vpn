const kTelegramId = 'Mramirmohammadp';
const kTelegramUrl = 'https://t.me/$kTelegramId';
