enum ConnectionMode { vpn, proxy }

enum RoutingMode { global, ruleBased, direct }

enum SortMode { added, name, ping, protocol }

enum AppThemeMode { dark, light }

enum AutoUpdate {
  off('Off', null),
  onOpen('When app opens', Duration.zero),
  h1('Every 1 hour', Duration(hours: 1)),
  h6('Every 6 hours', Duration(hours: 6)),
  h12('Every 12 hours', Duration(hours: 12)),
  h24('Every 24 hours', Duration(hours: 24));

  final String label;
  final Duration? interval;
  const AutoUpdate(this.label, this.interval);
}

enum AppLanguage {
  fa('fa'),
  en('en');

  final String code;
  const AppLanguage(this.code);
}

class AppSettings {
  final ConnectionMode mode;
  final RoutingMode routing;
  final String dns;
  final bool useDoh;
  final String dohUrl;
  final bool killSwitch;
  final bool autoConnect;
  final List<String> excludedApps; // split tunneling (package names)
  final AppLanguage language;
  final SortMode sort;
  final AppThemeMode theme;
  final bool zenMode;
  final bool fragment;
  final bool autoSwitch;
  final bool pingOnStart;
  final bool notifications;
  final bool autoReconnect;
  final bool stability;
  final bool blockQuic;
  final AutoUpdate autoUpdate;
  final int socksPort;
  final int httpPort;
  final bool mux;
  final int muxConcurrency;
  final bool customDns;
  final String remoteDns;
  final String localDns;
  final bool geoRouting;
  final String fingerprint;
  final String alpn;
  final bool allowInsecure;
  final bool fakeDns;
  final bool ipv6;

  const AppSettings({
    this.mode = ConnectionMode.vpn,
    this.routing = RoutingMode.global,
    this.dns = '1.1.1.1',
    this.useDoh = false,
    this.dohUrl = 'https://cloudflare-dns.com/dns-query',
    this.killSwitch = false,
    this.autoConnect = false,
    this.excludedApps = const [],
    this.language = AppLanguage.en,
    this.sort = SortMode.added,
    this.theme = AppThemeMode.dark,
    this.zenMode = false,
    this.fragment = false,
    this.autoSwitch = true,
    this.pingOnStart = false,
    this.notifications = true,
    this.autoReconnect = true,
    this.stability = false,
    this.blockQuic = false,
    this.autoUpdate = AutoUpdate.off,
    this.socksPort = 10808,
    this.httpPort = 10809,
    this.mux = false,
    this.muxConcurrency = 8,
    this.customDns = false,
    this.remoteDns = 'https://1.1.1.1/dns-query',
    this.localDns = '223.5.5.5',
    this.geoRouting = false,
    this.fingerprint = '',
    this.alpn = '',
    this.allowInsecure = false,
    this.fakeDns = false,
    this.ipv6 = false,
  });

  AppSettings copyWith({
    ConnectionMode? mode,
    RoutingMode? routing,
    String? dns,
    bool? useDoh,
    String? dohUrl,
    bool? killSwitch,
    bool? autoConnect,
    List<String>? excludedApps,
    AppLanguage? language,
    SortMode? sort,
    AppThemeMode? theme,
    bool? zenMode,
    bool? fragment,
    bool? autoSwitch,
    bool? pingOnStart,
    bool? notifications,
    bool? autoReconnect,
    bool? stability,
    bool? blockQuic,
    AutoUpdate? autoUpdate,
    bool? mux,
    int? muxConcurrency,
    bool? customDns,
    String? remoteDns,
    String? localDns,
    bool? geoRouting,
    String? fingerprint,
    String? alpn,
    bool? allowInsecure,
    bool? fakeDns,
    bool? ipv6,
  }) =>
      AppSettings(
        mode: mode ?? this.mode,
        routing: routing ?? this.routing,
        dns: dns ?? this.dns,
        useDoh: useDoh ?? this.useDoh,
        dohUrl: dohUrl ?? this.dohUrl,
        killSwitch: killSwitch ?? this.killSwitch,
        autoConnect: autoConnect ?? this.autoConnect,
        excludedApps: excludedApps ?? this.excludedApps,
        language: language ?? this.language,
        sort: sort ?? this.sort,
        theme: theme ?? this.theme,
        zenMode: zenMode ?? this.zenMode,
        fragment: fragment ?? this.fragment,
        autoSwitch: autoSwitch ?? this.autoSwitch,
        pingOnStart: pingOnStart ?? this.pingOnStart,
        notifications: notifications ?? this.notifications,
        autoReconnect: autoReconnect ?? this.autoReconnect,
        stability: stability ?? this.stability,
        blockQuic: blockQuic ?? this.blockQuic,
        autoUpdate: autoUpdate ?? this.autoUpdate,
        socksPort: socksPort,
        httpPort: httpPort,
        mux: mux ?? this.mux,
        muxConcurrency: muxConcurrency ?? this.muxConcurrency,
        customDns: customDns ?? this.customDns,
        remoteDns: remoteDns ?? this.remoteDns,
        localDns: localDns ?? this.localDns,
        geoRouting: geoRouting ?? this.geoRouting,
        fingerprint: fingerprint ?? this.fingerprint,
        alpn: alpn ?? this.alpn,
        allowInsecure: allowInsecure ?? this.allowInsecure,
        fakeDns: fakeDns ?? this.fakeDns,
        ipv6: ipv6 ?? this.ipv6,
      );

  Map<String, dynamic> toJson() => {
        'mode': mode.name,
        'routingV2': routing.name,
        'dns': dns,
        'useDoh': useDoh,
        'dohUrl': dohUrl,
        'killSwitch': killSwitch,
        'autoConnect': autoConnect,
        'excludedApps': excludedApps,
        'language': language.name,
        'sort': sort.name,
        'theme': theme.name,
        'zenMode': zenMode,
        'fragment': fragment,
        'autoSwitch': autoSwitch,
        'pingOnStart': pingOnStart,
        'notifications': notifications,
        'autoReconnect': autoReconnect,
        'stabilityV2': stability,
        'blockQuicV2': blockQuic,
        'autoUpdate': autoUpdate.name,
        'mux': mux,
        'muxConcurrency': muxConcurrency,
        'customDns': customDns,
        'remoteDns': remoteDns,
        'localDns': localDns,
        'geoRouting': geoRouting,
        'fingerprint': fingerprint,
        'alpn': alpn,
        'allowInsecure': allowInsecure,
        'fakeDns': fakeDns,
        'ipv6': ipv6,
      };

  factory AppSettings.fromJson(Map<String, dynamic> j) {
    const d = AppSettings();
    T pick<T extends Enum>(List<T> values, Object? v, T fallback) =>
        values.firstWhere((e) => e.name == v, orElse: () => fallback);
    return AppSettings(
      mode: pick(ConnectionMode.values, j['mode'], d.mode),
      routing: pick(RoutingMode.values, j['routingV2'], d.routing),
      dns: j['dns'] as String? ?? d.dns,
      useDoh: j['useDoh'] as bool? ?? d.useDoh,
      dohUrl: j['dohUrl'] as String? ?? d.dohUrl,
      killSwitch: j['killSwitch'] as bool? ?? d.killSwitch,
      autoConnect: j['autoConnect'] as bool? ?? d.autoConnect,
      excludedApps: (j['excludedApps'] as List?)?.cast<String>() ?? d.excludedApps,
      language: pick(AppLanguage.values, j['language'], d.language),
      sort: pick(SortMode.values, j['sort'], d.sort),
      theme: pick(AppThemeMode.values, j['theme'], d.theme),
      zenMode: j['zenMode'] as bool? ?? d.zenMode,
      fragment: j['fragment'] as bool? ?? d.fragment,
      autoSwitch: j['autoSwitch'] as bool? ?? d.autoSwitch,
      pingOnStart: j['pingOnStart'] as bool? ?? d.pingOnStart,
      notifications: j['notifications'] as bool? ?? d.notifications,
      autoReconnect: j['autoReconnect'] as bool? ?? d.autoReconnect,
      stability: j['stabilityV2'] as bool? ?? d.stability,
      blockQuic: j['blockQuicV2'] as bool? ?? d.blockQuic,
      autoUpdate: pick(AutoUpdate.values, j['autoUpdate'], d.autoUpdate),
      mux: j['mux'] as bool? ?? d.mux,
      muxConcurrency: (j['muxConcurrency'] as num?)?.toInt() ?? d.muxConcurrency,
      customDns: j['customDns'] as bool? ?? d.customDns,
      remoteDns: j['remoteDns'] as String? ?? d.remoteDns,
      localDns: j['localDns'] as String? ?? d.localDns,
      geoRouting: j['geoRouting'] as bool? ?? d.geoRouting,
      fingerprint: j['fingerprint'] as String? ?? d.fingerprint,
      alpn: j['alpn'] as String? ?? d.alpn,
      allowInsecure: j['allowInsecure'] as bool? ?? d.allowInsecure,
      fakeDns: j['fakeDns'] as bool? ?? d.fakeDns,
      ipv6: j['ipv6'] as bool? ?? d.ipv6,
    );
  }
}
