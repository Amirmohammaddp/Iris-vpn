import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../models/connection_state.dart';
import '../theme.dart';
import 'anim.dart';

/// A wall-style rocker switch drawn in layers (cast shadow, bevelled faces, crease,
/// rim light, engraved I / O marks and a coloured light spilling from the pressed end).
///
/// ON  : the bottom half protrudes and a faint yellow light spills under it.
/// OFF : the top half protrudes and the light is off.
class ConnectSwitch extends StatelessWidget {
  final VpnStatus status;
  final VoidCallback onToggle;
  final double width; // width of the plate itself
  final double height; // height of the plate itself
  const ConnectSwitch({
    super.key,
    required this.status,
    required this.onToggle,
    this.width = 84,
    this.height = 200,
  });

  @override
  Widget build(BuildContext context) {
    final on = status == VpnStatus.connected;
    final busy = status == VpnStatus.connecting || status == VpnStatus.disconnecting;
    final target = busy ? 0.5 : (on ? 1.0 : 0.0);
    final m = width * 0.5; // room for shadow and light
    return Pressable(
      scale: 0.985,
      autofocus: true,
      focusRadius: width / 2,
      onTap: busy ? null : onToggle,
      child: TweenAnimationBuilder<double>(
        tween: Tween(end: target),
        duration: const Duration(milliseconds: 420),
        curve: Curves.easeOutBack,
        builder: (context, t, _) => CustomPaint(
          size: Size(width + m * 2, height + m * 2),
          painter: _RockerPainter(t: t, margin: m, glow: AppTheme.yellow, busy: busy),
        ),
      ),
    );
  }
}

class _RockerPainter extends CustomPainter {
  final double t; // 0 off .. 1 on (may overshoot slightly)
  final double margin;
  final Color glow;
  final bool busy;
  _RockerPainter({required this.t, required this.margin, required this.glow, required this.busy});

  static Color _l(Color a, Color b, double x) => Color.lerp(a, b, x.clamp(0.0, 1.0))!;

  @override
  void paint(Canvas canvas, Size size) {
    final m = margin;
    final plate = Rect.fromLTWH(m, m, size.width - m * 2, size.height - m * 2);
    final w = plate.width, h = plate.height;
    final r = Radius.circular(w * 0.5);
    final rr = RRect.fromRectAndRadius(plate, r);
    final tt = t.clamp(0.0, 1.0);

    // Light spilling out from under the pressed (bottom) end.
    if (tt > 0.02) {
      final a = tt;
      final spill = RRect.fromRectAndRadius(
        Rect.fromLTWH(plate.left + w * 0.02, plate.bottom - h * 0.22, w * 0.96, h * 0.30),
        Radius.circular(w * 0.5),
      );
      canvas.drawRRect(spill, Paint()..color = glow.withValues(alpha: 0.55 * a)..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 0.22));
      canvas.drawRRect(
        spill.shift(Offset(0, h * 0.02)),
        Paint()..color = glow.withValues(alpha: 0.30 * a)..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 0.07),
      );
    }

    // Hard cast shadow to the right (the plate stands proud of the wall).
    canvas.drawRRect(
      rr.shift(Offset(w * 0.12, h * 0.012)),
      Paint()..color = const Color(0xFF000000).withValues(alpha: 0.85)..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 0.07),
    );

    // Two faces split by the crease; the pressed half sits lower.
    final crease = plate.top + h * (0.66 - 0.32 * tt);
    const litTop = Color(0xFF34343A), litBot = Color(0xFF2A2A30);
    const dimTop = Color(0xFF17171B), dimBot = Color(0xFF1D1D22);
    final topA = _l(litTop, dimTop, tt), topB = _l(litBot, dimBot, tt);
    final botA = _l(dimTop, litTop, tt), botB = _l(dimBot, litBot, tt);

    canvas.save();
    canvas.clipRRect(rr);
    canvas.drawRect(
      Rect.fromLTRB(plate.left, plate.top, plate.right, crease),
      Paint()..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [topA, topB])
          .createShader(Rect.fromLTRB(plate.left, plate.top, plate.right, crease)),
    );
    canvas.drawRect(
      Rect.fromLTRB(plate.left, crease, plate.right, plate.bottom),
      Paint()..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [botA, botB])
          .createShader(Rect.fromLTRB(plate.left, crease, plate.right, plate.bottom)),
    );
    // Shadow the protruding half casts onto the receded one, next to the crease.
    final shadowOnTop = tt > 0.5; // bottom half proud -> shades the top face
    final sh = h * 0.10;
    final shRect = shadowOnTop ? Rect.fromLTRB(plate.left, crease - sh, plate.right, crease) : Rect.fromLTRB(plate.left, crease, plate.right, crease + sh);
    canvas.drawRect(
      shRect,
      Paint()..shader = LinearGradient(
        begin: shadowOnTop ? Alignment.topCenter : Alignment.bottomCenter,
        end: shadowOnTop ? Alignment.bottomCenter : Alignment.topCenter,
        colors: [const Color(0x00000000), const Color(0xCC000000)],
      ).createShader(shRect),
    );
    // Crease line + the lit edge of the proud half.
    canvas.drawLine(Offset(plate.left, crease), Offset(plate.right, crease), Paint()..color = const Color(0xFF000000)..strokeWidth = 1.6);
    canvas.drawLine(
      Offset(plate.left, crease + (shadowOnTop ? -1.2 : 1.2)),
      Offset(plate.right, crease + (shadowOnTop ? -1.2 : 1.2)),
      Paint()..color = const Color(0x22FFFFFF)..strokeWidth = 1,
    );
    // Thick lip at the pressed end (bottom when on, top when off).
    final lip = h * 0.018;
    canvas.drawRect(
      Rect.fromLTRB(plate.left, plate.bottom - lip, plate.right, plate.bottom),
      Paint()..color = Color.lerp(const Color(0x00FFFFFF), glow.withValues(alpha: 0.85), tt)!,
    );
    canvas.drawRect(
      Rect.fromLTRB(plate.left, plate.top, plate.right, plate.top + lip),
      Paint()..color = const Color(0xFFFFFFFF).withValues(alpha: 0.10 * (1 - tt)),
    );
    canvas.restore();

    // Thin bevel outline.
    canvas.drawRRect(
      rr.deflate(0.6),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [const Color(0x66FFFFFF), const Color(0x11FFFFFF), const Color(0x44FFFFFF)],
        ).createShader(plate),
    );

    // Engraved marks.
    final cx = plate.center.dx;
    final iY = plate.top + h * 0.12;
    final oY = plate.bottom - h * 0.12;
    final iCol = Color.lerp(const Color(0xFFB4B4BC), const Color(0xFF55555B), tt)!;
    canvas.drawLine(
      Offset(cx, iY - h * 0.035),
      Offset(cx, iY + h * 0.035),
      Paint()..color = iCol..strokeWidth = w * 0.045..strokeCap = StrokeCap.round,
    );
    final oCol = Color.lerp(const Color(0xFF55555B), const Color(0xFFF2F2F4), tt)!;
    if (tt > 0.3) {
      canvas.drawCircle(Offset(cx, oY), w * 0.17, Paint()..color = glow.withValues(alpha: 0.55 * tt)..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 0.07));
    }
    canvas.drawCircle(Offset(cx, oY), w * 0.12, Paint()..style = PaintingStyle.stroke..strokeWidth = w * 0.045..color = oCol);
  }

  @override
  bool shouldRepaint(_RockerPainter o) => o.t != t || o.margin != margin || o.glow != glow || o.busy != busy;
}

/// Small round "iris" button under the switch: shows ping, taps to refresh.
class IrisButton extends StatefulWidget {
  final bool lit;
  final bool busy;
  final VoidCallback? onTap;
  final double size;
  const IrisButton({super.key, required this.lit, required this.busy, this.onTap, this.size = 46});

  @override
  State<IrisButton> createState() => _IrisButtonState();
}

class _IrisButtonState extends State<IrisButton> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 3));

  @override
  void didUpdateWidget(IrisButton old) {
    super.didUpdateWidget(old);
    if (widget.busy && !_c.isAnimating) _c.repeat();
    if (!widget.busy && _c.isAnimating) _c.stop();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Pressable(
      circle: true,
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) => CustomPaint(
          size: Size.square(widget.size + 16),
          painter: _IrisPainter(lit: widget.lit, busy: widget.busy, spin: _c.value, glow: AppTheme.yellow),
        ),
      ),
    );
  }
}

class _IrisPainter extends CustomPainter {
  final bool lit;
  final bool busy;
  final double spin;
  final Color glow;
  _IrisPainter({required this.lit, required this.busy, required this.spin, required this.glow});

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 8;
    canvas.drawCircle(c + const Offset(3, 4), r, Paint()..color = Colors.black.withValues(alpha: 0.8)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3));
    final disc = Rect.fromCircle(center: c, radius: r);
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF3B3B41), Color(0xFF16161A)],
        ).createShader(disc),
    );
    canvas.drawCircle(c, r, Paint()..style = PaintingStyle.stroke..strokeWidth = 1..color = Colors.white.withValues(alpha: 0.16));
    canvas.drawCircle(c, r - 5, Paint()..color = const Color(0xFF0B0B0D));
    final lightOn = lit || busy;
    final col = lightOn ? glow : const Color(0xFF6B6B73);
    if (lightOn) {
      canvas.drawCircle(c, r - 8, Paint()..color = glow.withValues(alpha: 0.35)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3));
    }
    final p = Paint()
      ..color = col
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < 24; i++) {
      final a = i / 24 * 2 * math.pi + (busy ? spin * 2 * math.pi : 0);
      var f = 1.0;
      if (busy) {
        final d = ((i / 24) - spin) % 1.0;
        f = d < 0.4 ? 1 - d / 0.4 * 0.7 : 0.3;
      }
      final r2 = lightOn ? 10.5 : 9.0;
      p.color = col.withValues(alpha: f);
      canvas.drawLine(c + Offset(math.cos(a), math.sin(a)) * 5, c + Offset(math.cos(a), math.sin(a)) * r2, p);
    }
  }

  @override
  bool shouldRepaint(_IrisPainter o) => o.lit != lit || o.busy != busy || o.spin != spin;
}
