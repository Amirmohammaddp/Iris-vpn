import 'package:flutter/material.dart';

import '../../models/connection_state.dart';
import '../theme.dart';
import 'anim.dart';

/// Round connect button. Color, glow and icon animate between states.
class ConnectButton extends StatefulWidget {
  final VpnStatus status;
  final double size;
  final VoidCallback? onTap;
  const ConnectButton({super.key, required this.status, required this.size, this.onTap});

  @override
  State<ConnectButton> createState() => _ConnectButtonState();
}

class _ConnectButtonState extends State<ConnectButton> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2200))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final on = widget.status == VpnStatus.connected;
    final busy = widget.status == VpnStatus.connecting || widget.status == VpnStatus.disconnecting;
    final active = on || busy;
    final target = on ? AppTheme.connected : (busy ? AppTheme.connecting : cs.surfaceContainerHighest);
    final size = widget.size;

    return Pressable(
      scale: 0.92,
      autofocus: true,
      circle: true,
      onTap: busy ? null : widget.onTap,
      child: SizedBox(
        width: size,
        height: size,
        child: TweenAnimationBuilder<Color?>(
          tween: ColorTween(end: target),
          duration: const Duration(milliseconds: 700),
          curve: Curves.easeInOut,
          builder: (context, color, _) {
            final c = color ?? target;
            return Stack(
              clipBehavior: Clip.none,
              alignment: Alignment.center,
              children: [
                for (final o in const [0.0, 0.5])
                  AnimatedOpacity(
                    opacity: active ? 1 : 0,
                    duration: const Duration(milliseconds: 500),
                    child: AnimatedBuilder(
                      animation: _c,
                      builder: (context, _) {
                        final t = (_c.value + o) % 1;
                        return Transform.scale(
                          scale: 1 + 0.55 * t,
                          child: Container(
                            width: size,
                            height: size,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: c.withValues(alpha: 0.12 * (1 - t)),
                              border: Border.all(color: c.withValues(alpha: 0.5 * (1 - t)), width: 2),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                Container(
                  width: size,
                  height: size,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [Color.lerp(c, Colors.white, active ? 0.22 : 0.06)!, c],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: active ? c.withValues(alpha: 0.55) : Colors.black.withValues(alpha: 0.28),
                        blurRadius: size * 0.22,
                        spreadRadius: active ? 2 : 0,
                        offset: active ? Offset.zero : const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Center(
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 350),
                      transitionBuilder: (child, anim) => FadeTransition(
                        opacity: anim,
                        child: ScaleTransition(scale: anim, child: child),
                      ),
                      child: busy
                          ? SizedBox(
                              key: const ValueKey('busy'),
                              width: size * 0.3,
                              height: size * 0.3,
                              child: const CircularProgressIndicator(strokeWidth: 3.5, color: AppTheme.onAccent),
                            )
                          : Icon(
                              Icons.power_settings_new_rounded,
                              key: const ValueKey('power'),
                              size: size * 0.42,
                              color: on ? AppTheme.onAccent : AppTheme.iconOf(cs),
                            ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
