import 'package:flutter/material.dart';

class AppTheme {
  // Palette: muddy dark green, very light green (accents), light yellow (icons)
  static const olive = Color(0xFF55672B);
  static const lime = Color(0xFFC6EE96);
  static const yellow = Color(0xFFF3E7A1);
  static const yellowDeep = Color(0xFFA88A00);

  static const connected = Color(0xFFA8E063);
  static const connecting = Color(0xFFF3E7A1);
  static const danger = Color(0xFFFF6B6B);
  static const onAccent = Color(0xFF1E2A0C);

  /// Icon colour (light yellow at night, deeper yellow by day).
  static Color iconOf(ColorScheme cs) => cs.brightness == Brightness.dark ? yellow : yellowDeep;
  static Color okOf(ColorScheme cs) => cs.brightness == Brightness.dark ? connected : const Color(0xFF4C7A10);
  static Color busyOf(ColorScheme cs) => cs.brightness == Brightness.dark ? connecting : yellowDeep;

  static ThemeData dark() => _build(Brightness.dark);
  static ThemeData light() => _build(Brightness.light);

  static ThemeData _build(Brightness b) {
    final dark = b == Brightness.dark;
    final base = ColorScheme.fromSeed(seedColor: olive, brightness: b);
    final scheme = base.copyWith(
      primary: dark ? lime : const Color(0xFF4F6B1E),
      onPrimary: dark ? onAccent : Colors.white,
      surface: dark ? const Color(0xFF1A1F12) : const Color(0xFFF4F8E6),
      onSurface: dark ? const Color(0xFFEAF0DC) : const Color(0xFF222A12),
      onSurfaceVariant: dark ? const Color(0xFFAAB594) : const Color(0xFF5E6B45),
      surfaceContainer: dark ? const Color(0xFF21281A) : const Color(0xFFEAF1D2),
      surfaceContainerHigh: dark ? const Color(0xFF29321F) : const Color(0xFFFBFDF0),
      surfaceContainerHighest: dark ? const Color(0xFF34402A) : const Color(0xFFDDE8BC),
      secondaryContainer: dark ? const Color(0xFF4A5A2A) : const Color(0xFFD7F0A8),
      onSecondaryContainer: dark ? const Color(0xFFDDF6B8) : const Color(0xFF2C3A0E),
    );
    final icon = iconOf(scheme);
    return ThemeData(
      useMaterial3: true,
      fontFamily: 'Kavoon',
      colorScheme: scheme,
      scaffoldBackgroundColor: scheme.surface,
      iconTheme: IconThemeData(color: icon),
      listTileTheme: ListTileThemeData(iconColor: icon),
      iconButtonTheme: IconButtonThemeData(style: IconButton.styleFrom(foregroundColor: icon)),
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: icon),
        actionsIconTheme: IconThemeData(color: icon),
        titleTextStyle: TextStyle(color: scheme.primary, fontSize: 22, fontWeight: FontWeight.w800),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      inputDecorationTheme: InputDecorationThemeData(
        filled: true,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}
