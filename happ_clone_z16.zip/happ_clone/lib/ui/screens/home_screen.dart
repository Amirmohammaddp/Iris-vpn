import 'dart:async';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/connection_state.dart';
import '../../models/proxy_config.dart';
import '../../providers/providers.dart';
import '../add_actions.dart';
import '../theme.dart';
import '../widgets/anim.dart';
import '../widgets/config_tile.dart';
import '../widgets/connect_button.dart';
import '../widgets/glass.dart';
import '../widgets/groups_list.dart';
import 'settings_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  Future<void> _toggle(BuildContext context, WidgetRef ref) async {
    try {
      await ref.read(connectionControllerProvider).toggle();
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final zen = ref.watch(settingsProvider.select((s) => s.zenMode));
    final status = ref.watch(vpnStatusProvider).valueOrNull ?? VpnStatus.disconnected;
    final groups = ref.watch(configGroupsProvider);
    final active = ref.watch(activeConfigProvider);
    final tv = ref.watch(isTvProvider);

    return SafeArea(
      bottom: false,
      child: Column(
        children: [
          _Header(
            onSettings: () => openSettings(context),
            onAdd: () => AddActions.showMenu(context, ref, tv),
          ),
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 450),
              switchInCurve: Curves.easeOutCubic,
              child: zen
                  ? KeyedSubtree(
                      key: const ValueKey('zen'),
                      child: _Zen(status: status, active: active, onToggle: () => _toggle(context, ref)),
                    )
                  : KeyedSubtree(
                      key: const ValueKey('full'),
                      child: ListView(
                        padding: const EdgeInsets.only(top: 8, bottom: 30),
                        children: [
                          FadeSlideIn(
                            child: _ConnectCard(
                              status: status,
                              active: active,
                              groups: groups,
                              onToggle: () => _toggle(context, ref),
                            ),
                          ),
                          const SizedBox(height: 22),
                          FadeSlideIn(
                            index: 1,
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(22, 0, 16, 10),
                              child: Row(
                                children: [
                                  Text('Groups',
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w800,
                                          letterSpacing: 1,
                                          color: Theme.of(context).colorScheme.primary)),
                                  const Spacer(),
                                  if (groups.isNotEmpty)
                                    GlassPill(
                                      icon: Icons.speed_rounded,
                                      label: 'Ping all',
                                      busyLabel: 'Testing…',
                                      onPressed: () => ref.read(configsProvider.notifier).pingAll(),
                                    ),
                                ],
                              ),
                            ),
                          ),
                          if (groups.isEmpty)
                            const _Empty()
                          else
                            GroupsList(groups: groups),
                        ],
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Header: luxury glass banner with the app name, settings (left) and add (right).

class _Header extends StatelessWidget {
  final VoidCallback onSettings;
  final VoidCallback onAdd;
  const _Header({required this.onSettings, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
      child: Glass(
        radius: 32,
        blur: 24,
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
        child: Row(
          children: [
            Pressable(circle: true, onTap: onSettings, child: const GlassIcon(Icons.settings_rounded, size: 46)),
            const Expanded(child: _Brand()),
            Pressable(circle: true, onTap: onAdd, child: const GlassIcon(Icons.add_rounded, size: 46, iconSize: 28)),
          ],
        ),
      ),
    );
  }
}

class _SlideGradient extends GradientTransform {
  final double p;
  const _SlideGradient(this.p);
  @override
  Matrix4? transform(Rect bounds, {TextDirection? textDirection}) =>
      Matrix4.translationValues(bounds.width * p, 0, 0);
}

/// "Iris" wordmark (Audiowide) with a slowly moving gold/green gradient.
class _Brand extends StatefulWidget {
  const _Brand();
  @override
  State<_Brand> createState() => _BrandState();
}

class _BrandState extends State<_Brand> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 5))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = cs.brightness == Brightness.dark;
    final a = dark ? AppTheme.lime : const Color(0xFF3F5A12);
    final b = dark ? AppTheme.yellow : const Color(0xFFB59500);
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ShaderMask(
            blendMode: BlendMode.srcIn,
            shaderCallback: (r) => LinearGradient(
              colors: [a, b, a],
              tileMode: TileMode.mirror,
              transform: _SlideGradient(_c.value * 2),
            ).createShader(r),
            child: const Text(
              'Iris',
              style: TextStyle(
                fontFamily: 'Audiowide',
                fontSize: 42,
                letterSpacing: 3,
                height: 1.05,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(height: 2),
          Container(
            width: 70,
            height: 2.5,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [a.withValues(alpha: 0), b, a.withValues(alpha: 0)]),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 5),
          Text('V2RAY  ·  SECURE TUNNEL',
              style: TextStyle(
                  fontFamily: 'Audiowide', fontSize: 8.5, letterSpacing: 3, color: cs.onSurfaceVariant)),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Connect card: the round button is always docked to the left edge of a glass frame.

class _ConnectCard extends ConsumerWidget {
  final VpnStatus status;
  final ProxyConfig? active;
  final List<ConfigGroup> groups;
  final VoidCallback onToggle;
  const _ConnectCard({required this.status, required this.active, required this.groups, required this.onToggle});

  static const _btn = 108.0;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cs = Theme.of(context).colorScheme;
    final dark = cs.brightness == Brightness.dark;
    final on = status == VpnStatus.connected;
    final busy = status == VpnStatus.connecting || status == VpnStatus.disconnecting;
    final glow = on ? AppTheme.connected : (busy ? AppTheme.connecting : cs.onSurface.withValues(alpha: 0.30));
    final stateColor = on ? AppTheme.okOf(cs) : (busy ? AppTheme.busyOf(cs) : cs.onSurfaceVariant);
    final label = switch (status) {
      VpnStatus.connected => 'CONNECTED',
      VpnStatus.connecting => 'CONNECTING…',
      VpnStatus.disconnecting => 'DISCONNECTING…',
      _ => 'NOT CONNECTED',
    };
    final a = active;
    final group = a == null ? null : groups.where((g) => g.configs.any((c) => c.id == a.id)).firstOrNull;
    final sub = group?.sub;
    final ping = a?.pingMs;
    final pingLabel = ping == null ? 'Test ping' : (ping < 0 ? 'timeout' : '$ping ms');

    return Stack(
      clipBehavior: Clip.none,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 16 + _btn / 2, right: 16),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 600),
            curve: Curves.easeInOut,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(32),
              boxShadow: [
                BoxShadow(color: glow.withValues(alpha: on ? 0.40 : (busy ? 0.30 : 0.10)), blurRadius: 36, spreadRadius: 1),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(32),
              child: BackdropFilter(
                filter: ImageFilterBlur.blur,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 600),
                  curve: Curves.easeInOut,
                  constraints: const BoxConstraints(minHeight: 158),
                  padding: const EdgeInsets.fromLTRB(_btn / 2 + 14, 16, 16, 16),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(32),
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        glow.withValues(alpha: on ? 0.26 : 0.14),
                        Colors.white.withValues(alpha: dark ? 0.06 : 0.55),
                      ],
                    ),
                    border: Border.all(color: glow.withValues(alpha: 0.75), width: 1.4),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 500),
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(shape: BoxShape.circle, color: stateColor),
                          ),
                          const SizedBox(width: 6),
                          Flexible(
                            child: Text(label,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    color: stateColor, fontWeight: FontWeight.w800, fontSize: 11.5, letterSpacing: 1.1)),
                          ),
                          const Spacer(),
                          if (on) const _Elapsed(),
                        ],
                      ),
                      const SizedBox(height: 8),
                      if (a == null) ...[
                        Text('No config selected',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: cs.onSurface)),
                        const SizedBox(height: 3),
                        Text('Tap + to add one', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
                      ] else ...[
                        Text('${a.flag}  ${a.name}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 16.5, fontWeight: FontWeight.w800, color: cs.onSurface)),
                        const SizedBox(height: 3),
                        Text('${a.protocol.label} • ${a.address}:${a.port}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            textDirection: TextDirection.ltr,
                            style: TextStyle(fontSize: 11.5, color: cs.onSurfaceVariant)),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: GlassPill(
                                icon: Icons.speed_rounded,
                                label: pingLabel,
                                busyLabel: 'Testing…',
                                color: ping == null ? null : pingColor(ping),
                                onPressed: () => ref.read(configsProvider.notifier).pingOne(a.id),
                              ),
                            ),
                            if (sub != null) ...[
                              const SizedBox(width: 8),
                              Expanded(
                                child: GlassPill(
                                  icon: Icons.sync_rounded,
                                  label: 'Update',
                                  busyLabel: 'Updating…',
                                  onPressed: () async {
                                    final messenger = ScaffoldMessenger.of(context);
                                    try {
                                      final c = await ref.read(subscriptionsProvider.notifier).refreshOne(sub.id);
                                      messenger.showSnackBar(SnackBar(content: Text('Updated: $c configs')));
                                    } catch (e) {
                                      messenger.showSnackBar(SnackBar(content: Text('$e')));
                                    }
                                  },
                                ),
                              ),
                            ],
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        Positioned(
          left: 16,
          top: 0,
          bottom: 0,
          child: Center(child: ConnectButton(status: status, size: _btn, onTap: onToggle)),
        ),
      ],
    );
  }
}

/// Blur filter holder (keeps the import list short).
class ImageFilterBlur {
  static final blur = ui.ImageFilter.blur(sigmaX: 22, sigmaY: 22);
}

/// Elapsed time since connecting.
class _Elapsed extends ConsumerStatefulWidget {
  const _Elapsed();
  @override
  ConsumerState<_Elapsed> createState() => _ElapsedState();
}

class _ElapsedState extends ConsumerState<_Elapsed> {
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final since = ref.watch(connectedSinceProvider);
    if (since == null) return const SizedBox.shrink();
    final d = DateTime.now().difference(since);
    String two(int v) => v.toString().padLeft(2, '0');
    final txt = '${two(d.inHours)}:${two(d.inMinutes % 60)}:${two(d.inSeconds % 60)}';
    return Text(txt,
        style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: Theme.of(context).colorScheme.onSurfaceVariant));
  }
}

// ---------------------------------------------------------------------------

class _Empty extends StatelessWidget {
  const _Empty();
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
      child: Glass(
        radius: 26,
        padding: const EdgeInsets.all(22),
        child: Column(
          children: [
            const GlassIcon(Icons.add_rounded, size: 54, iconSize: 30),
            const SizedBox(height: 12),
            Text('No configs yet', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: cs.onSurface)),
            const SizedBox(height: 4),
            Text('Tap + at the top to add a config or a subscription.',
                textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)),
          ],
        ),
      ),
    );
  }
}

/// Zen mode: just a big round button in the lower third, plus a tiny ping button.
class _Zen extends ConsumerWidget {
  final VpnStatus status;
  final ProxyConfig? active;
  final VoidCallback onToggle;
  const _Zen({required this.status, required this.active, required this.onToggle});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final a = active;
    final ping = a?.pingMs;
    final label = ping == null ? 'Test ping' : (ping < 0 ? 'timeout' : '$ping ms');
    return Stack(
      children: [
        Align(
          alignment: const Alignment(0, 0.3),
          child: ConnectButton(status: status, size: 210, onTap: onToggle),
        ),
        if (a != null)
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 18),
              child: GlassPill(
                icon: Icons.speed_rounded,
                label: label,
                busyLabel: 'Testing…',
                color: ping == null ? null : pingColor(ping),
                onPressed: () => ref.read(configsProvider.notifier).pingOne(a.id),
              ),
            ),
          ),
      ],
    );
  }
}
