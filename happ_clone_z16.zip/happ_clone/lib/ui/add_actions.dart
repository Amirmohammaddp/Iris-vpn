import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:qr_flutter/qr_flutter.dart';

import '../providers/providers.dart';
import '../services/phone_inbox.dart';
import 'screens/config_edit_screen.dart';
import 'widgets/add_sheet.dart';
import 'screens/qr_scan_screen.dart';

/// The four ways to add configs. All text is English.
class AddActions {
  static void toast(BuildContext c, String m) =>
      ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

  static bool _isUrl(String t) => !t.contains('\n') && (t.startsWith('http://') || t.startsWith('https://'));

  static Future<void> _addText(BuildContext c, WidgetRef ref, String text) async {
    final t = text.trim();
    if (t.isEmpty) {
      toast(c, 'Nothing to add');
      return;
    }
    if (_isUrl(t)) {
      await _addSub(c, ref, t);
      return;
    }
    try {
      final n = ref.read(configsProvider.notifier).addFromText(t);
      toast(c, n == 1 ? '1 config added' : '$n configs added');
    } catch (e) {
      toast(c, '$e');
    }
  }

  static Future<void> _addSub(BuildContext c, WidgetRef ref, String url) async {
    toast(c, 'Fetching subscription…');
    try {
      final n = await ref.read(subscriptionsProvider.notifier).add(url.trim());
      if (c.mounted) toast(c, n == 1 ? '1 config added' : '$n configs added');
    } catch (e) {
      if (c.mounted) toast(c, '$e');
    }
  }

  static Future<void> clipboard(BuildContext c, WidgetRef ref) async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    if (!c.mounted) return;
    final t = d?.text?.trim() ?? '';
    if (t.isEmpty) {
      toast(c, 'Clipboard is empty');
      return;
    }
    await _addText(c, ref, t);
  }

  static Future<void> qr(BuildContext c, WidgetRef ref) async {
    final t = await Navigator.push<String>(c, MaterialPageRoute<String>(builder: (_) => const QrScanScreen()));
    if (t == null || !c.mounted) return;
    await _addText(c, ref, t);
  }

  static Future<void> subscription(BuildContext c, WidgetRef ref) async {
    final ctrl = TextEditingController();
    final url = await showDialog<String>(
      context: c,
      builder: (ctx) => AlertDialog(
        title: const Text('Subscription link'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          textDirection: TextDirection.ltr,
          keyboardType: TextInputType.url,
          decoration: const InputDecoration(hintText: 'https://…'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: const Text('Add')),
        ],
      ),
    );
    if (url == null || url.trim().isEmpty || !c.mounted) return;
    await _addSub(c, ref, url);
  }

  static Future<String> _addQuiet(WidgetRef ref, String text) async {
    final t = text.trim();
    try {
      if (_isUrl(t)) {
        final n = await ref.read(subscriptionsProvider.notifier).add(t);
        return n == 1 ? '1 config added' : '$n configs added';
      }
      final n = ref.read(configsProvider.notifier).addFromText(t);
      return n == 1 ? '1 config added' : '$n configs added';
    } catch (e) {
      return '$e';
    }
  }

  /// TV: a phone on the same Wi-Fi sends the link through a tiny web page.
  static Future<void> phone(BuildContext c, WidgetRef ref) async {
    final srv = PhoneInbox();
    final last = ValueNotifier<String>('');
    String? url;
    try {
      url = await srv.start((text) async {
        final m = await _addQuiet(ref, text);
        last.value = m;
        return m;
      });
    } catch (e) {
      if (c.mounted) toast(c, 'Could not start: $e');
      return;
    }
    if (!c.mounted) {
      await srv.stop();
      return;
    }
    await showDialog<void>(
      context: c,
      builder: (ctx) => AlertDialog(
        title: const Text('Add from your phone'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (url != null) ...[
                Container(
                  color: Colors.white,
                  padding: const EdgeInsets.all(8),
                  child: QrImageView(data: url, size: 170, backgroundColor: Colors.white),
                ),
                const SizedBox(height: 10),
                SelectableText(url, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              ] else
                const Text('No network address found. Connect the TV to Wi-Fi.'),
              const SizedBox(height: 10),
              const Text('Open this address on your phone (same Wi-Fi), paste a config or subscription link and press send.',
                  textAlign: TextAlign.center),
              const SizedBox(height: 10),
              ValueListenableBuilder<String>(
                valueListenable: last,
                builder: (_, v, __) => v.isEmpty
                    ? const SizedBox.shrink()
                    : Text(v, style: const TextStyle(fontWeight: FontWeight.w800)),
              ),
            ],
          ),
        ),
        actions: [FilledButton(autofocus: true, onPressed: () => Navigator.pop(ctx), child: const Text('Done'))],
      ),
    );
    await srv.stop();
  }

  /// Opens the glass "add" sheet and runs the chosen action.
  static Future<void> showMenu(BuildContext c, WidgetRef ref, bool tv) async {
    final k = await showModalBottomSheet<AddKind>(
      context: c,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black54,
      isScrollControlled: true,
      builder: (_) => AddSheet(tv: tv),
    );
    if (k == null || !c.mounted) return;
    switch (k) {
      case AddKind.qr:
        await qr(c, ref);
        break;
      case AddKind.phone:
        await phone(c, ref);
        break;
      case AddKind.clipboard:
        await clipboard(c, ref);
        break;
      case AddKind.subscription:
        await subscription(c, ref);
        break;
      case AddKind.manual:
        manual(c);
        break;
    }
  }

  static void manual(BuildContext c) {
    Navigator.push(c, MaterialPageRoute<void>(builder: (_) => const ConfigEditScreen()));
  }
}
