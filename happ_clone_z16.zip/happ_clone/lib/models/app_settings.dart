enum ConnectionMode { vpn, proxy }

enum RoutingMode { global, ruleBased, direct }

enum SortMode { added, name, ping, protocol }

enum AppThemeMode { dark, light }

enum AutoUpdate {
  off('Off', null),
  onOpen('When app opens', Duration.zero),
  h1('Every 1 hour', Duration(hours: 1)),
  h6('Every 6 hours', Duration(hours: 6)),
  h12('Every 12 hours', Duration(hours: 12)),
  h24('Every 24 hours', Duration(hours: 24));

  final String label;
  final Duration? interval;
  const AutoUpdate(this.label, this.interval);
}

enum AppLanguage {
  fa('fa'),
  en('en');

  final String code;
  const AppLanguage(this.code);
}

class AppSettings {
  final ConnectionMode mode;
  final RoutingMode routing;
  final String dns;
  final bool useDoh;
  final String dohUrl;
  final bool killSwitch;
  final bool autoConnect;
  final List<String> excludedApps; // split tunneling (package names)
  final AppLanguage language;
  final SortMode sort;
  final AppThemeMode theme;
  final bool zenMode;
  final bool fragment;
  final bool autoSwitch;
  final bool pingOnStart;
  final bool notifications;
  final bool autoReconnect;
  final bool stability;
  final bool blockQuic;
  final AutoUpdate autoUpdate;
  final int socksPort;
  final int httpPort;

  const AppSettings({
    this.mode = ConnectionMode.vpn,
    this.routing = RoutingMode.ruleBased,
    this.dns = '1.1.1.1',
    this.useDoh = false,
    this.dohUrl = 'https://cloudflare-dns.com/dns-query',
    this.killSwitch = false,
    this.autoConnect = false,
    this.excludedApps = const [],
    this.language = AppLanguage.en,
    this.sort = SortMode.added,
    this.theme = AppThemeMode.dark,
    this.zenMode = false,
    this.fragment = false,
    this.autoSwitch = true,
    this.pingOnStart = false,
    this.notifications = true,
    this.autoReconnect = true,
    this.stability = true,
    this.blockQuic = true,
    this.autoUpdate = AutoUpdate.off,
    this.socksPort = 10808,
    this.httpPort = 10809,
  });

  AppSettings copyWith({
    ConnectionMode? mode,
    RoutingMode? routing,
    String? dns,
    bool? useDoh,
    String? dohUrl,
    bool? killSwitch,
    bool? autoConnect,
    List<String>? excludedApps,
    AppLanguage? language,
    SortMode? sort,
    AppThemeMode? theme,
    bool? zenMode,
    bool? fragment,
    bool? autoSwitch,
    bool? pingOnStart,
    bool? notifications,
    bool? autoReconnect,
    bool? stability,
    bool? blockQuic,
    AutoUpdate? autoUpdate,
  }) =>
      AppSettings(
        mode: mode ?? this.mode,
        routing: routing ?? this.routing,
        dns: dns ?? this.dns,
        useDoh: useDoh ?? this.useDoh,
        dohUrl: dohUrl ?? this.dohUrl,
        killSwitch: killSwitch ?? this.killSwitch,
        autoConnect: autoConnect ?? this.autoConnect,
        excludedApps: excludedApps ?? this.excludedApps,
        language: language ?? this.language,
        sort: sort ?? this.sort,
        theme: theme ?? this.theme,
        zenMode: zenMode ?? this.zenMode,
        fragment: fragment ?? this.fragment,
        autoSwitch: autoSwitch ?? this.autoSwitch,
        pingOnStart: pingOnStart ?? this.pingOnStart,
        notifications: notifications ?? this.notifications,
        autoReconnect: autoReconnect ?? this.autoReconnect,
        stability: stability ?? this.stability,
        blockQuic: blockQuic ?? this.blockQuic,
        autoUpdate: autoUpdate ?? this.autoUpdate,
        socksPort: socksPort,
        httpPort: httpPort,
      );

  Map<String, dynamic> toJson() => {
        'mode': mode.name,
        'routing': routing.name,
        'dns': dns,
        'useDoh': useDoh,
        'dohUrl': dohUrl,
        'killSwitch': killSwitch,
        'autoConnect': autoConnect,
        'excludedApps': excludedApps,
        'language': language.name,
        'sort': sort.name,
        'theme': theme.name,
        'zenMode': zenMode,
        'fragment': fragment,
        'autoSwitch': autoSwitch,
        'pingOnStart': pingOnStart,
        'notifications': notifications,
        'autoReconnect': autoReconnect,
        'stability': stability,
        'blockQuic': blockQuic,
        'autoUpdate': autoUpdate.name,
      };

  factory AppSettings.fromJson(Map<String, dynamic> j) {
    const d = AppSettings();
    T pick<T extends Enum>(List<T> values, Object? v, T fallback) =>
        values.firstWhere((e) => e.name == v, orElse: () => fallback);
    return AppSettings(
      mode: pick(ConnectionMode.values, j['mode'], d.mode),
      routing: pick(RoutingMode.values, j['routing'], d.routing),
      dns: j['dns'] as String? ?? d.dns,
      useDoh: j['useDoh'] as bool? ?? d.useDoh,
      dohUrl: j['dohUrl'] as String? ?? d.dohUrl,
      killSwitch: j['killSwitch'] as bool? ?? d.killSwitch,
      autoConnect: j['autoConnect'] as bool? ?? d.autoConnect,
      excludedApps: (j['excludedApps'] as List?)?.cast<String>() ?? d.excludedApps,
      language: pick(AppLanguage.values, j['language'], d.language),
      sort: pick(SortMode.values, j['sort'], d.sort),
      theme: pick(AppThemeMode.values, j['theme'], d.theme),
      zenMode: j['zenMode'] as bool? ?? d.zenMode,
      fragment: j['fragment'] as bool? ?? d.fragment,
      autoSwitch: j['autoSwitch'] as bool? ?? d.autoSwitch,
      pingOnStart: j['pingOnStart'] as bool? ?? d.pingOnStart,
      notifications: j['notifications'] as bool? ?? d.notifications,
      autoReconnect: j['autoReconnect'] as bool? ?? d.autoReconnect,
      stability: j['stability'] as bool? ?? d.stability,
      blockQuic: j['blockQuic'] as bool? ?? d.blockQuic,
      autoUpdate: pick(AutoUpdate.values, j['autoUpdate'], d.autoUpdate),
    );
  }
}
