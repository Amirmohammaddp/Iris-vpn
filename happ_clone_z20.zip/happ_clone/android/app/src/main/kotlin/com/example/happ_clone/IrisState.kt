package com.example.happ_clone

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.quicksettings.TileService

/** Connection state shared between the app, the quick-settings tile and the home-screen widget. */
object IrisState {
    private const val PREFS = "iris_state"

    fun save(ctx: Context, status: String, name: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("status", status).putString("name", name).apply()
        refresh(ctx)
    }

    fun status(ctx: Context): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("status", "disconnected") ?: "disconnected"

    fun name(ctx: Context): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("name", "") ?: ""

    fun isOn(ctx: Context): Boolean {
        val s = status(ctx)
        return s == "connected" || s == "connecting"
    }

    fun label(ctx: Context): String = when (status(ctx)) {
        "connected" -> "CONNECTED"
        "connecting" -> "CONNECTING…"
        "disconnecting" -> "DISCONNECTING…"
        else -> "NOT CONNECTED"
    }

    /** Opens the app with the action that flips the current state (connect <-> disconnect). */
    fun actionIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).apply {
            action = if (isOn(ctx)) MainActivity.ACTION_DISCONNECT else MainActivity.ACTION_CONNECT
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        return PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun refresh(ctx: Context) {
        try {
            IrisWidgetProvider.updateAll(ctx)
        } catch (_: Throwable) {
        }
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                TileService.requestListeningState(ctx, ComponentName(ctx, IrisTileService::class.java))
            } catch (_: Throwable) {
            }
        }
    }
}
