package com.example.happ_clone

import android.app.Activity
import android.app.UiModeManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.VpnService
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * - channel "happ/vpn": Android VpnService permission prompt for Dart.
 * - channel "iris/native": quick-settings tile / widget actions, status sync, TV detection.
 */
class MainActivity : FlutterActivity() {
    companion object {
        const val ACTION_CONNECT = "com.example.happ_clone.CONNECT"
        const val ACTION_DISCONNECT = "com.example.happ_clone.DISCONNECT"
    }

    private val requestCode = 0x5650
    private var pending: MethodChannel.Result? = null
    private var irisChannel: MethodChannel? = null
    private var pendingAction: String? = null

    private fun actionOf(i: Intent?): String? = when (i?.action) {
        ACTION_CONNECT -> "connect"
        ACTION_DISCONNECT -> "disconnect"
        else -> null
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        pendingAction = actionOf(intent)
        if (pendingAction != null) intent.action = Intent.ACTION_MAIN

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "happ/vpn").setMethodCallHandler { call, result ->
            when (call.method) {
                "prepare" -> {
                    val intent = VpnService.prepare(this)
                    if (intent == null) {
                        result.success(true)
                    } else {
                        pending = result
                        startActivityForResult(intent, requestCode)
                    }
                }
                else -> result.notImplemented()
            }
        }

        irisChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "iris/native").also { ch ->
            ch.setMethodCallHandler { call, result ->
                when (call.method) {
                    "getInitialAction" -> {
                        val a = pendingAction
                        pendingAction = null
                        result.success(a)
                    }
                    "setStatus" -> {
                        IrisState.save(
                            this,
                            call.argument<String>("status") ?: "disconnected",
                            call.argument<String>("name") ?: ""
                        )
                        result.success(null)
                    }
                    "isTv" -> {
                        val um = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
                        val tv = um.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
                            packageManager.hasSystemFeature("android.software.leanback")
                        result.success(tv)
                    }
                    else -> result.notImplemented()
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val a = actionOf(intent)
        if (a != null) {
            intent.action = Intent.ACTION_MAIN
            irisChannel?.invokeMethod("onAction", a)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == requestCode) {
            pending?.success(res == Activity.RESULT_OK)
            pending = null
        }
    }
}
