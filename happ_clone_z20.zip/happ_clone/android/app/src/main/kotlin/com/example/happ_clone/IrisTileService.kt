package com.example.happ_clone

import android.annotation.TargetApi
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick-settings tile: tap to connect / disconnect. */
@TargetApi(24)
class IrisTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
    }

    override fun onClick() {
        super.onClick()
        if (isLocked) {
            unlockAndRun { launch() }
        } else {
            launch()
        }
    }

    private fun launch() {
        val i = Intent(this, MainActivity::class.java).apply {
            action = if (IrisState.isOn(this@IrisTileService)) MainActivity.ACTION_DISCONNECT else MainActivity.ACTION_CONNECT
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(this, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            startActivityAndCollapse(pi)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }

    private fun refreshTile() {
        val t = qsTile ?: return
        t.state = if (IrisState.isOn(this)) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Irisv2ray"
        if (Build.VERSION.SDK_INT >= 29) {
            t.subtitle = IrisState.label(this)
        }
        t.updateTile()
    }
}
