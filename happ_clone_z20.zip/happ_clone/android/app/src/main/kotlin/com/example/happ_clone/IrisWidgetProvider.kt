package com.example.happ_clone

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews

/** Home-screen widget with a connect / disconnect button. */
class IrisWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(context))
    }

    companion object {
        fun build(ctx: Context): RemoteViews {
            val on = IrisState.isOn(ctx)
            val v = RemoteViews(ctx.packageName, R.layout.widget_iris)
            v.setTextViewText(R.id.w_status, IrisState.label(ctx))
            val name = IrisState.name(ctx)
            v.setTextViewText(R.id.w_name, if (name.isEmpty()) "Tap to connect" else name)
            v.setInt(R.id.w_btn, "setBackgroundResource", if (on) R.drawable.widget_btn_on else R.drawable.widget_btn_off)
            v.setInt(R.id.w_icon, "setColorFilter", if (on) 0xFF1E2A0C.toInt() else 0xFFF3E7A1.toInt())
            v.setOnClickPendingIntent(R.id.w_root, IrisState.actionIntent(ctx))
            return v
        }

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, IrisWidgetProvider::class.java))
            for (id in ids) mgr.updateAppWidget(id, build(ctx))
        }
    }
}
