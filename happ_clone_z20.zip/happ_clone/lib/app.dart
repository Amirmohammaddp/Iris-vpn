import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'l10n/strings.dart';
import 'models/app_settings.dart';
import 'models/connection_state.dart';
import 'services/native_bridge.dart';
import 'services/notice_service.dart';
import 'providers/providers.dart';
import 'ui/screens/configs_screen.dart';
import 'ui/screens/home_screen.dart';
import 'ui/screens/logs_screen.dart';
import 'ui/screens/settings_screen.dart';
import 'ui/screens/speed_screen.dart';
import 'ui/widgets/anim.dart';
import 'ui/theme.dart';
import 'ui/widgets/glass.dart';
import 'ui/widgets/nav_bar.dart';

class HappApp extends ConsumerWidget {
  const HappApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = ref.watch(settingsProvider.select((s) => s.theme));
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'IRIS VPN',
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: theme == AppThemeMode.dark ? ThemeMode.dark : ThemeMode.light,
      themeAnimationDuration: const Duration(milliseconds: 500),
      themeAnimationCurve: Curves.easeInOut,
      locale: const Locale('en'),
      supportedLocales: const [Locale('en'), Locale('fa')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const RootShell(),
    );
  }
}

class RootShell extends ConsumerStatefulWidget {
  const RootShell({super.key});
  @override
  ConsumerState<RootShell> createState() => _RootShellState();
}

class _RootShellState extends ConsumerState<RootShell> {
  int _index = 0;
  static const _pages = <Widget>[HomeScreen(), ConfigsScreen(), SpeedScreen(), LogsScreen(), SettingsScreen(embedded: true)];
  Offset? _fab; // floating connect button position (draggable)
  Timer? _auto;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _startup());
    NativeBridge.onAction = _onNativeAction;
    _auto = Timer.periodic(const Duration(minutes: 5), (_) {
      _updateSubs(startup: false);
      _checkNews();
    });
  }

  @override
  void dispose() {
    NativeBridge.onAction = null;
    _auto?.cancel();
    super.dispose();
  }

  /// Keeps the quick-settings tile and the widget in sync.
  void _pushStatus() {
    final st = ref.read(xrayServiceProvider).status;
    NativeBridge.setStatus(st.name, ref.read(activeConfigProvider)?.name ?? '');
  }

  /// Tile / widget tapped: connect or disconnect, then go back to where the user was.
  Future<void> _onNativeAction(String action) async {
    try {
      final ctl = ref.read(connectionControllerProvider);
      final xray = ref.read(xrayServiceProvider);
      if (action == 'connect') {
        if (xray.status != VpnStatus.connected) await ctl.toggle();
      } else if (action == 'disconnect') {
        await ctl.disconnect();
      }
    } catch (e) {
      ref.read(logsProvider.notifier).add('Error', 'quick action failed: $e');
    }
    await Future<void>.delayed(const Duration(milliseconds: 600));
    _pushStatus();
    await Future<void>.delayed(const Duration(milliseconds: 200));
    SystemNavigator.pop();
  }

  Future<void> _checkNews() async {
    try {
      final n = await NoticeService.check(notify: true);
      if (n > 0) ref.read(logsProvider.notifier).add('Info', '$n new announcement(s)');
    } catch (_) {}
  }

  Future<void> _startup() async {
    ref.read(connectionControllerProvider); // starts the connection watchdog
    final first = await NativeBridge.initialAction();
    if (first != null) {
      _onNativeAction(first);
    } else {
      _pushStatus();
    }
    NoticeService.setEnabled(ref.read(settingsProvider).notifications);
    _checkNews();
    await _updateSubs(startup: true);
    if (!mounted) return;
    if (ref.read(settingsProvider).pingOnStart && ref.read(configsProvider).isNotEmpty) {
      ref.read(logsProvider.notifier).add('Info', 'ping on start');
      await ref.read(configsProvider.notifier).pingAll();
    }
  }

  Future<void> _updateSubs({required bool startup}) async {
    final mode = ref.read(settingsProvider).autoUpdate;
    final interval = mode.interval;
    if (interval == null) return;
    if (!startup && interval == Duration.zero) return;
    final now = DateTime.now();
    for (final s in [...ref.read(subscriptionsProvider)]) {
      final last = s.lastUpdated;
      final stale = last == null || now.difference(last) >= interval;
      if (!stale) continue;
      try {
        await ref.read(subscriptionsProvider.notifier).refreshOne(s.id);
      } catch (e) {
        ref.read(logsProvider.notifier).add('Warn', 'auto-update ${s.name} failed: $e');
      }
    }
  }

  void _goTo(int i) => setState(() => _index = i);

  /// TV: pages are kept to a phone-like column in the middle of the wide screen.
  Widget _tvBox(Widget child) => LayoutBuilder(
        builder: (ctx, c) {
          final w = c.maxWidth < 640 ? c.maxWidth : 640.0;
          return Center(
            child: SizedBox(
              width: w,
              height: c.maxHeight,
              child: MediaQuery(
                data: MediaQuery.of(ctx).copyWith(size: Size(w, c.maxHeight)),
                child: child,
              ),
            ),
          );
        },
      );

  Widget _withRail(bool tv, Widget body) => tv
      ? Row(children: [AppNavRail(index: _index, onChanged: _goTo), Expanded(child: body)])
      : body;

  /// Draggable round connect / disconnect button shown on every page except Home.
  Widget _fabLayer() {
    final status = ref.watch(vpnStatusProvider).valueOrNull ?? VpnStatus.disconnected;
    final on = status == VpnStatus.connected;
    final busy = status == VpnStatus.connecting || status == VpnStatus.disconnecting;
    const size = 58.0;
    return LayoutBuilder(builder: (context, c) {
      final maxX = c.maxWidth - size - 10;
      final maxY = c.maxHeight - size - 10;
      final pos = _fab ?? Offset(maxX, maxY - 76);
      final cur = Offset(pos.dx.clamp(10.0, maxX), pos.dy.clamp(10.0, maxY));
      return Stack(
        children: [
          AnimatedPositioned(
            duration: const Duration(milliseconds: 160),
            curve: Curves.easeOut,
            left: cur.dx,
            top: cur.dy,
            child: GestureDetector(
              onPanUpdate: (d) => setState(() => _fab = Offset(cur.dx + d.delta.dx, cur.dy + d.delta.dy)),
              onPanEnd: (_) => setState(() {
                final mid = c.maxWidth / 2;
                _fab = Offset(cur.dx + size / 2 < mid ? 10.0 : maxX, cur.dy);
              }),
              child: Pressable(
                circle: true,
                onTap: busy
                    ? null
                    : () async {
                        try {
                          await ref.read(connectionControllerProvider).toggle();
                        } catch (e) {
                          if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
                        }
                      },
                child: SizedBox(
                  width: size,
                  height: size,
                  child: Glass(
                    radius: size / 2,
                    depth: 5,
                    inset: on,
                    child: Center(
                      child: busy
                          ? SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.yellow),
                            )
                          : Icon(Icons.power_settings_new_rounded,
                              size: 26,
                              color: on ? AppTheme.yellow : Theme.of(context).colorScheme.onSurfaceVariant),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    ref.listen(logsProvider, (_, __) {}); // keep the log collector alive from app start
    ref.listen<AsyncValue<VpnStatus>>(vpnStatusProvider, (_, __) => _pushStatus());
    ref.listen(activeConfigProvider, (_, __) => _pushStatus());
    final tv = ref.watch(isTvProvider);
    return PopScope(
      canPop: _index == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        setState(() => _index = 0);
      },
      child: Scaffold(
        body: _withRail(
          tv,
          AuroraBackground(
            child: Stack(children: [
              Positioned.fill(child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 320),
              transitionBuilder: (child, anim) => FadeTransition(
                opacity: anim,
                child: SlideTransition(
                  position: Tween<Offset>(begin: const Offset(0, 0.03), end: Offset.zero).animate(anim),
                  child: child,
                ),
              ),
              child: KeyedSubtree(key: ValueKey(_index), child: tv ? _tvBox(_pages[_index]) : _pages[_index]),
              )),
              if (_index != 0) Positioned.fill(child: tv ? _tvBox(_fabLayer()) : _fabLayer()),
            ]),
          ),
        ),
        bottomNavigationBar: tv ? null : AppNavBar(index: _index, onChanged: _goTo),
      ),
    );
  }
}

/// UI is English-only.
final stringsProvider = Provider<AppStrings>((ref) => AppStrings.of(AppLanguage.en));
