import 'dart:async';
import 'dart:convert';
import 'dart:io';

/// Tiny local web server: lets a phone on the same Wi-Fi send a link / config to the TV
/// (typing with a TV remote is painful). Only runs while the "Add from phone" dialog is open.
class PhoneInbox {
  static const port = 8765;
  HttpServer? _server;

  /// Starts the server; returns the address to open on the phone (or null if no network).
  Future<String?> start(Future<String> Function(String text) onText) async {
    _server = await HttpServer.bind(InternetAddress.anyIPv4, port, shared: true);
    _server!.listen((req) async {
      try {
        if (req.method == 'POST' && req.uri.path == '/add') {
          final body = await utf8.decoder.bind(req).join();
          final text = Uri.splitQueryString(body)['text'] ?? '';
          final msg = text.trim().isEmpty ? 'Nothing to add' : await onText(text);
          req.response
            ..headers.contentType = ContentType.html
            ..write(_page(msg));
        } else {
          req.response
            ..headers.contentType = ContentType.html
            ..write(_page(''));
        }
      } catch (_) {
        // ignore malformed requests
      } finally {
        await req.response.close();
      }
    });
    try {
      for (final i in await NetworkInterface.list(type: InternetAddressType.IPv4)) {
        for (final a in i.addresses) {
          if (!a.isLoopback) return 'http://${a.address}:$port';
        }
      }
    } catch (_) {}
    return null;
  }

  Future<void> stop() async {
    await _server?.close(force: true);
    _server = null;
  }

  static String _esc(String s) =>
      s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

  static String _page(String msg) => '''<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Irisv2ray</title>
<style>
body{margin:0;padding:24px;background:#1a1f12;color:#eaf0dc;font-family:sans-serif}
h1{letter-spacing:6px;color:#c6ee96;margin:0 0 6px}
p{color:#aab594}
textarea{width:100%;height:170px;box-sizing:border-box;border-radius:14px;border:0;padding:12px;background:#29321f;color:#eaf0dc;font-size:15px}
button{margin-top:12px;width:100%;padding:14px;border:0;border-radius:14px;background:#c6ee96;color:#1e2a0c;font-size:17px;font-weight:700}
.m{margin-top:14px;padding:12px;border-radius:12px;background:#34402a;color:#f3e7a1}
</style></head><body>
<h1>IRIS</h1>
<p>Paste a config link or a subscription link and send it to the TV.</p>
<form method="post" action="/add"><textarea name="text" placeholder="vless://…  or  https://…" dir="ltr"></textarea>
<button type="submit">Send to TV</button></form>
${msg.isEmpty ? '' : '<div class="m">${_esc(msg)}</div>'}
</body></html>''';
}
