import 'package:flutter/services.dart';

/// Bridge to the Android side: quick-settings tile / widget actions,
/// status sync (for the tile and widget) and TV detection.
class NativeBridge {
  static const _ch = MethodChannel('iris/native');
  static void Function(String action)? onAction;
  static bool _bound = false;

  static void bind() {
    if (_bound) return;
    _bound = true;
    _ch.setMethodCallHandler((call) async {
      if (call.method == 'onAction') {
        final a = call.arguments;
        if (a is String) onAction?.call(a);
      }
      return null;
    });
  }

  static Future<String?> initialAction() async {
    try {
      return await _ch.invokeMethod<String>('getInitialAction');
    } catch (_) {
      return null;
    }
  }

  static Future<void> setStatus(String status, String name) async {
    try {
      await _ch.invokeMethod<void>('setStatus', {'status': status, 'name': name});
    } catch (_) {}
  }

  static Future<bool> isTv() async {
    try {
      return await _ch.invokeMethod<bool>('isTv') ?? false;
    } catch (_) {
      return false;
    }
  }
}
