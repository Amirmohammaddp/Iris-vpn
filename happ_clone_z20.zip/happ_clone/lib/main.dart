import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';
import 'providers/providers.dart';
import 'services/native_bridge.dart';
import 'services/notice_service.dart';
import 'services/storage_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  NativeBridge.bind();
  final isTv = await NativeBridge.isTv();
  final storage = await StorageService.init();
  try {
    await NoticeService.initMain();
  } catch (_) {}
  runApp(
    ProviderScope(
      overrides: [
        storageServiceProvider.overrideWithValue(storage),
        isTvProvider.overrideWithValue(isTv),
      ],
      child: const HappApp(),
    ),
  );
}
