import 'package:flutter/material.dart';

class AppTheme {
  // Palette: dominant black, a restrained yellow for emphasis, greys for separation.
  static const olive = Color(0xFF8A7A2E);
  static const lime = Color(0xFFE6CF7A); // accent (soft yellow)
  static const yellow = Color(0xFFE6CF7A);
  static const yellowDeep = Color(0xFF8F7A12);

  static const connected = Color(0xFFE6CF7A);
  static const connecting = Color(0xFFB4B4BC);
  static const danger = Color(0xFFFF6B6B);
  static const onAccent = Color(0xFF1A1500);

  /// Icon colour (soft yellow at night, deeper yellow by day).
  static Color iconOf(ColorScheme cs) => cs.brightness == Brightness.dark ? yellow : yellowDeep;
  static Color okOf(ColorScheme cs) => cs.brightness == Brightness.dark ? connected : yellowDeep;
  static Color busyOf(ColorScheme cs) => cs.brightness == Brightness.dark ? connecting : const Color(0xFF6E6E76);

  static ThemeData dark() => _build(Brightness.dark);
  static ThemeData light() => _build(Brightness.light);

  static ThemeData _build(Brightness b) {
    final dark = b == Brightness.dark;
    final base = ColorScheme.fromSeed(seedColor: olive, brightness: b);
    final scheme = base.copyWith(
      primary: dark ? lime : const Color(0xFF7A6710),
      onPrimary: dark ? onAccent : Colors.white,
      surface: dark ? const Color(0xFF111113) : const Color(0xFFE3E5E9),
      onSurface: dark ? const Color(0xFFE6E6E8) : const Color(0xFF1F2024),
      onSurfaceVariant: dark ? const Color(0xFF8E8E96) : const Color(0xFF63646B),
      surfaceContainer: dark ? const Color(0xFF17171A) : const Color(0xFFE8EAEE),
      surfaceContainerHigh: dark ? const Color(0xFF1E1E22) : const Color(0xFFEDEFF3),
      surfaceContainerHighest: dark ? const Color(0xFF26262B) : const Color(0xFFD5D8DE),
      secondaryContainer: dark ? const Color(0xFF2A2A2F) : const Color(0xFFD5D8DE),
      onSecondaryContainer: dark ? const Color(0xFFE6CF7A) : const Color(0xFF4F430A),
    );
    final icon = iconOf(scheme);
    return ThemeData(
      useMaterial3: true,
      fontFamily: 'Ui',
      colorScheme: scheme,
      scaffoldBackgroundColor: scheme.surface,
      iconTheme: IconThemeData(color: icon),
      listTileTheme: ListTileThemeData(iconColor: icon),
      iconButtonTheme: IconButtonThemeData(style: IconButton.styleFrom(foregroundColor: icon)),
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: icon),
        actionsIconTheme: IconThemeData(color: icon),
        titleTextStyle: TextStyle(color: scheme.primary, fontSize: 22, fontWeight: FontWeight.w600),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      inputDecorationTheme: InputDecorationThemeData(
        filled: true,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}
