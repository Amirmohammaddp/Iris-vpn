import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/proxy_config.dart';
import '../../providers/providers.dart';
import '../add_actions.dart';
import '../theme.dart';
import '../widgets/anim.dart';
import '../widgets/config_tile.dart';
import '../widgets/glass.dart';
import '../widgets/groups_list.dart';
import 'config_edit_screen.dart';

class ConfigsScreen extends ConsumerWidget {
  const ConfigsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cs = Theme.of(context).colorScheme;
    final groups = ref.watch(configGroupsProvider);
    final tv = ref.watch(isTvProvider);
    final activeId = ref.watch(activeConfigProvider)?.id;
    final open = ref.watch(expandedGroupsProvider);

    return SafeArea(
      bottom: false,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(22, 16, 18, 10),
            child: Row(
              children: [
                Text('Configs', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600, color: cs.onSurface)),
                const Spacer(),
                AsyncGlassButton(icon: Icons.speed_rounded, onPressed: () => ref.read(configsProvider.notifier).pingAll()),
                const SizedBox(width: 12),
                AsyncGlassButton(
                  icon: Icons.sync_rounded,
                  onPressed: () async {
                    final m = ScaffoldMessenger.of(context);
                    final errs = await ref.read(subscriptionsProvider.notifier).refreshAll();
                    if (errs.isNotEmpty) m.showSnackBar(SnackBar(content: Text(errs.join('\n'))));
                  },
                ),
              ],
            ),
          ),
          Expanded(
            child: groups.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        GlassIcon(Icons.cloud_off_rounded, size: 64, color: cs.onSurfaceVariant),
                        const SizedBox(height: 16),
                        const Text('No configs yet', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 4),
                        Text('Use + or the QR button below', style: TextStyle(color: cs.onSurfaceVariant)),
                      ],
                    ),
                  )
                : ListView(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                    children: [
                      for (var i = 0; i < groups.length; i++)
                        FadeSlideIn(
                          key: ValueKey(groups[i].key),
                          index: i,
                          child: _GroupSection(group: groups[i], activeId: activeId, expanded: open.contains(groups[i].key)),
                        ),
                    ],
                  ),
          ),
          // bottom dock: add (+) and QR
          Padding(
            padding: const EdgeInsets.only(bottom: 14, top: 6),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Pressable(
                  circle: true,
                  onTap: () => tv ? AddActions.phone(context, ref) : AddActions.qr(context, ref),
                  child: GlassIcon(tv ? Icons.phone_android_rounded : Icons.qr_code_scanner_rounded, size: 56, iconSize: 26),
                ),
                const SizedBox(width: 26),
                Pressable(
                  circle: true,
                  onTap: () => AddActions.showMenu(context, ref, tv),
                  child: GlassIcon(Icons.add_rounded, size: 56, iconSize: 30, color: cs.primary),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _GroupSection extends ConsumerWidget {
  final ConfigGroup group;
  final String? activeId;
  final bool expanded;
  const _GroupSection({required this.group, required this.activeId, required this.expanded});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cs = Theme.of(context).colorScheme;
    final g = group;
    final n = g.configs.length;
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        children: [
          // group header row: description + actions; toggles the list
          Pressable(
            scale: 0.99,
            focusRadius: 22,
            onTap: () {
              final cur = ref.read(expandedGroupsProvider);
              ref.read(expandedGroupsProvider.notifier).state =
                  cur.contains(g.key) ? ({...cur}..remove(g.key)) : {...cur, g.key};
            },
            child: Glass(
              radius: 22,
              depth: 5,
              inset: expanded,
              padding: const EdgeInsets.fromLTRB(16, 8, 8, 8),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(g.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15, color: cs.onSurface)),
                        Text(n == 1 ? '1 config' : '$n configs', style: TextStyle(fontSize: 11.5, color: cs.onSurfaceVariant)),
                      ],
                    ),
                  ),
                  AsyncGlassButton(
                    size: 34,
                    icon: Icons.speed_rounded,
                    onPressed: () => ref.read(configsProvider.notifier).pingGroup([for (final c in g.configs) c.id]),
                  ),
                  if (g.sub != null) ...[
                    const SizedBox(width: 8),
                    AsyncGlassButton(
                      size: 34,
                      icon: Icons.sync_rounded,
                      onPressed: () async {
                        final m = ScaffoldMessenger.of(context);
                        try {
                          final c = await ref.read(subscriptionsProvider.notifier).refreshOne(g.sub!.id);
                          m.showSnackBar(SnackBar(content: Text('Updated: $c configs')));
                        } catch (e) {
                          m.showSnackBar(SnackBar(content: Text('$e')));
                        }
                      },
                    ),
                  ],
                  const SizedBox(width: 4),
                  AnimatedRotation(
                    turns: expanded ? 0.5 : 0,
                    duration: const Duration(milliseconds: 300),
                    child: Icon(Icons.expand_more_rounded, color: cs.onSurfaceVariant),
                  ),
                ],
              ),
            ),
          ),
          AnimatedSize(
            duration: const Duration(milliseconds: 380),
            curve: Curves.easeInOutCubic,
            alignment: Alignment.topCenter,
            child: !expanded
                ? const SizedBox(width: double.infinity)
                : Padding(
                    padding: const EdgeInsets.only(top: 14),
                    child: Column(
                      children: [
                        if (g.configs.isEmpty)
                          Padding(
                            padding: const EdgeInsets.all(12),
                            child: Text('No configs in this group', style: TextStyle(color: cs.onSurfaceVariant)),
                          )
                        else
                          LayoutBuilder(builder: (context, c) {
                            const gap = 14.0;
                            final w = (c.maxWidth - gap) / 2;
                            return Wrap(
                              spacing: gap,
                              runSpacing: gap,
                              children: [
                                for (final cfg in g.configs)
                                  SizedBox(width: w, height: 128, child: _ConfigCell(config: cfg, selected: cfg.id == activeId)),
                              ],
                            );
                          }),
                        if (g.sub != null)
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton.icon(
                              onPressed: () => ref.read(subscriptionsProvider.notifier).remove(g.sub!.id),
                              icon: const Icon(Icons.delete_outline_rounded, size: 18),
                              label: const Text('Delete group'),
                            ),
                          ),
                      ],
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

/// One config as a square neumorphic cell (two per row, all the same size).
class _ConfigCell extends ConsumerStatefulWidget {
  final ProxyConfig config;
  final bool selected;
  const _ConfigCell({required this.config, required this.selected});

  @override
  ConsumerState<_ConfigCell> createState() => _ConfigCellState();
}

class _ConfigCellState extends ConsumerState<_ConfigCell> {
  bool _busy = false;

  Future<void> _ping() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await ref.read(configsProvider.notifier).pingOne(widget.config.id);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final c = widget.config;
    final sel = widget.selected;
    final p = c.pingMs;
    final pingTxt = _busy ? '…' : (p == null ? 'ping' : (p < 0 ? 'timeout' : '$p ms'));
    final pingCol = (p == null || _busy) ? cs.onSurfaceVariant : pingColor(p);
    return Pressable(
      scale: 0.97,
      focusRadius: 24,
      onTap: () => selectConfig(ref, context, c),
      child: Glass(
        radius: 24,
        depth: 5,
        inset: sel,
        padding: const EdgeInsets.fromLTRB(12, 10, 4, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(c.flag, style: const TextStyle(fontSize: 22)),
                const SizedBox(width: 6),
                if (sel)
                  Container(
                    width: 7,
                    height: 7,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppTheme.yellow,
                        boxShadow: [BoxShadow(color: AppTheme.yellow.withValues(alpha: 0.6), blurRadius: 6)]),
                  ),
                const Spacer(),
                PopupMenuButton<int>(
                  padding: EdgeInsets.zero,
                  icon: Icon(Icons.more_horiz_rounded, size: 20, color: cs.onSurfaceVariant),
                  onSelected: (v) {
                    if (v == 0) {
                      Navigator.push(context, MaterialPageRoute<void>(builder: (_) => ConfigEditScreen(initial: c)));
                    } else {
                      ref.read(configsProvider.notifier).remove(c.id);
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 0, child: Text('Edit')),
                    PopupMenuItem(value: 1, child: Text('Delete')),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 4),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(right: 8),
                child: Text(c.name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 13.5, height: 1.2, fontWeight: FontWeight.w600, color: cs.onSurface)),
              ),
            ),
            Row(
              children: [
                Expanded(
                  child: Text(c.protocol.label,
                      maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
                ),
                Pressable(
                  focusRadius: 14,
                  onTap: _ping,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(8, 4, 10, 4),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.network_ping_rounded, size: 14, color: AppTheme.iconOf(cs)),
                        const SizedBox(width: 4),
                        Text(pingTxt, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: pingCol)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
