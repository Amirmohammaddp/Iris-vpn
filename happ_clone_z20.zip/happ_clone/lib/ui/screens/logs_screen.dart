import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app.dart';
import '../../providers/providers.dart';
import '../theme.dart';
import '../widgets/anim.dart';
import '../widgets/glass.dart';

class LogsScreen extends ConsumerWidget {
  const LogsScreen({super.key});

  Color _color(String l, ColorScheme cs) {
    if (l.contains('[Error]')) return cs.error;
    if (l.contains('[Warn]')) return AppTheme.iconOf(cs);
    if (l.contains('[Debug]')) return cs.onSurfaceVariant;
    return cs.onSurface;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(stringsProvider);
    final logs = ref.watch(logsProvider);
    final cs = Theme.of(context).colorScheme;
    return SafeArea(
      bottom: false,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(22, 16, 18, 12),
            child: Row(
              children: [
                Text(s.logs, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600, color: cs.onSurface)),
                const Spacer(),
                Pressable(
                  circle: true,
                  onTap: () async {
                    await Clipboard.setData(ClipboardData(text: logs.join('\n')));
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.copied)));
                    }
                  },
                  child: const GlassIcon(Icons.copy_rounded, size: 40),
                ),
                const SizedBox(width: 12),
                Pressable(
                  circle: true,
                  onTap: ref.read(logsProvider.notifier).clear,
                  child: const GlassIcon(Icons.delete_sweep_rounded, size: 40),
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
              child: Glass(
                radius: 26,
                inset: true,
                depth: 5,
                color: cs.brightness == Brightness.dark ? const Color(0xFF0A0A0B) : cs.surfaceContainer,
                child: logs.isEmpty
                    ? Center(child: Text(s.emptyLogs, style: TextStyle(color: cs.onSurfaceVariant)))
                    : Directionality(
                        textDirection: TextDirection.ltr,
                        child: ListView.builder(
                          reverse: true,
                          padding: const EdgeInsets.all(14),
                          itemCount: logs.length,
                          itemBuilder: (_, i) {
                            final l = logs[logs.length - 1 - i];
                            return SelectableText(l,
                                style: TextStyle(fontFamily: 'monospace', fontSize: 12, color: _color(l, cs)));
                          },
                        ),
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
