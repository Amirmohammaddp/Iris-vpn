import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/connection_state.dart';
import '../../providers/providers.dart';
import '../add_actions.dart';
import '../widgets/anim.dart';
import '../widgets/config_tile.dart';
import '../widgets/connect_switch.dart';
import '../widgets/glass.dart';

/// Home: only the rocker switch, a faint ping icon under it and a quiet "+" on top.
class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  Future<void> _toggle(BuildContext context, WidgetRef ref) async {
    try {
      await ref.read(connectionControllerProvider).toggle();
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cs = Theme.of(context).colorScheme;
    final status = ref.watch(vpnStatusProvider).valueOrNull ?? VpnStatus.disconnected;
    final active = ref.watch(activeConfigProvider);
    final tv = ref.watch(isTvProvider);
    final h = MediaQuery.of(context).size.height;
    final sw = (h * 0.33).clamp(220.0, 300.0);

    return SafeArea(
      bottom: false,
      child: Stack(
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Pressable(
                circle: true,
                onTap: () => AddActions.showMenu(context, ref, tv),
                child: GlassIcon(Icons.add_rounded, size: 40, iconSize: 22, color: cs.onSurfaceVariant),
              ),
            ),
          ),
          Align(
            alignment: const Alignment(0, -0.05),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                FadeSlideIn(
                  child: ConnectSwitch(
                    status: status,
                    onToggle: () => _toggle(context, ref),
                    width: sw * 0.48,
                    height: sw,
                  ),
                ),
                const SizedBox(height: 30),
                _PingIcon(
                  ping: active?.pingMs,
                  enabled: active != null,
                  onPing: () => ref.read(configsProvider.notifier).pingOne(active!.id),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Very quiet ping indicator; tap to refresh.
class _PingIcon extends StatefulWidget {
  final int? ping;
  final bool enabled;
  final Future<void> Function() onPing;
  const _PingIcon({required this.ping, required this.enabled, required this.onPing});

  @override
  State<_PingIcon> createState() => _PingIconState();
}

class _PingIconState extends State<_PingIcon> {
  bool _busy = false;

  Future<void> _run() async {
    if (_busy || !widget.enabled) return;
    setState(() => _busy = true);
    try {
      await widget.onPing();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final p = widget.ping;
    final txt = _busy ? '' : (p == null ? '' : (p < 0 ? 'timeout' : '$p ms'));
    final col = (p == null || p < 0) ? cs.onSurfaceVariant : pingColor(p);
    return Pressable(
      focusRadius: 20,
      onTap: widget.enabled ? _run : null,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
        child: Opacity(
          opacity: widget.enabled ? 0.75 : 0.3,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (_busy)
                SizedBox(width: 15, height: 15, child: CircularProgressIndicator(strokeWidth: 1.6, color: cs.onSurfaceVariant))
              else
                Icon(Icons.network_ping_rounded, size: 18, color: cs.onSurfaceVariant),
              if (txt.isNotEmpty) ...[
                const SizedBox(width: 8),
                Text(txt, style: TextStyle(fontSize: 12.5, letterSpacing: 0.5, color: col)),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
