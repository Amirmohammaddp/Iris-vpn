import 'package:flutter/material.dart';

import 'anim.dart';
import 'glass.dart';

enum AddKind { qr, phone, clipboard, subscription, manual }

/// Glass bottom sheet with the ways to add configs (opened by the "+" icon).
class AddSheet extends StatelessWidget {
  final bool tv;
  const AddSheet({super.key, this.tv = false});

  static const _options = [
    (AddKind.qr, Icons.qr_code_scanner_rounded, 'Add with QR code'),
    (AddKind.phone, Icons.phone_android_rounded, 'Add from your phone'),
    (AddKind.clipboard, Icons.content_paste_rounded, 'Add from clipboard'),
    (AddKind.subscription, Icons.rss_feed_rounded, 'Add subscription link'),
    (AddKind.manual, Icons.edit_note_rounded, 'Add manually'),
  ];

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final options = [
      for (final o in _options)
        if (tv ? o.$1 != AddKind.qr : o.$1 != AddKind.phone) o,
    ];
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Center(
          heightFactor: 1,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Glass(
              radius: 30,
              padding: const EdgeInsets.fromLTRB(14, 16, 14, 10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Add your config',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: cs.primary)),
                  const SizedBox(height: 10),
                  for (var i = 0; i < options.length; i++)
                    FadeSlideIn(
                      index: i,
                      child: _Option(
                        icon: options[i].$2,
                        label: options[i].$3,
                        onTap: () => Navigator.pop(context, options[i].$1),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Option extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _Option({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Pressable(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: cs.primary.withValues(alpha: 0.10),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            GlassIcon(icon, size: 40),
            const SizedBox(width: 14),
            Expanded(
              child: Text(label, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: cs.onSurface)),
            ),
            Icon(Icons.chevron_right_rounded, color: cs.onSurfaceVariant),
          ],
        ),
      ),
    );
  }
}
