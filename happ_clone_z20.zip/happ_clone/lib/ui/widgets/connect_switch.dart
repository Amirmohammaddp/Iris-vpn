import 'package:flutter/material.dart';

import '../../models/connection_state.dart';
import '../theme.dart';
import 'anim.dart';
import 'glass.dart';

/// Vertical rectangular rocker: knob at the top = off, at the bottom = on.
/// Tap it or drag it up / down.
class ConnectSwitch extends StatelessWidget {
  final VpnStatus status;
  final VoidCallback onToggle;
  final double width;
  final double height;
  const ConnectSwitch({
    super.key,
    required this.status,
    required this.onToggle,
    this.width = 128,
    this.height = 268,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = cs.brightness == Brightness.dark;
    final on = status == VpnStatus.connected;
    final busy = status == VpnStatus.connecting || status == VpnStatus.disconnecting;
    final lit = on || busy;
    final glow = AppTheme.yellow;
    final pad = 14.0;
    final channelW = width - pad * 2;
    final channelH = height - pad * 2;
    final knobH = channelH * 0.5 - 6;
    final knobW = channelW - 12;
    final align = busy ? Alignment.center : (on ? Alignment.bottomCenter : Alignment.topCenter);

    return Pressable(
      scale: 0.985,
      autofocus: true,
      focusRadius: 34,
      onTap: busy ? null : onToggle,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onVerticalDragEnd: (d) {
          if (busy) return;
          final v = d.primaryVelocity ?? 0;
          if (v > 120 && !on) onToggle();
          if (v < -120 && on) onToggle();
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 600),
          curve: Curves.easeInOut,
          width: width,
          height: height,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(34),
            // a very faint yellow halo when on
            boxShadow: [
              BoxShadow(color: glow.withValues(alpha: lit ? 0.09 : 0), blurRadius: 60, spreadRadius: 6),
            ],
          ),
          // lighter veil (pedestal) around the key
          child: Glass(
            radius: 34,
            depth: 9,
            color: Color.lerp(cs.surfaceContainer, Colors.white, dark ? 0.035 : 0.0),
            padding: EdgeInsets.all(pad),
            child: Glass(
              radius: 24,
              inset: true,
              depth: 4,
              color: dark ? const Color(0xFF0A0A0B) : cs.surfaceContainer,
              child: SizedBox(
                width: channelW,
                height: channelH,
                child: AnimatedAlign(
                  duration: const Duration(milliseconds: 520),
                  curve: Curves.easeInOutCubic,
                  alignment: align,
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: _Knob(w: knobW, h: knobH, on: on, busy: busy),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Knob extends StatelessWidget {
  final double w;
  final double h;
  final bool on;
  final bool busy;
  const _Knob({required this.w, required this.h, required this.on, required this.busy});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = cs.brightness == Brightness.dark;
    final accent = AppTheme.yellow;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 500),
      width: w,
      height: h,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: dark
              ? [const Color(0xFF2B2B30), const Color(0xFF1B1B1F)]
              : [const Color(0xFFF6F7F9), const Color(0xFFD9DCE2)],
        ),
        border: Border(
          top: BorderSide(color: (on ? accent : Colors.white).withValues(alpha: on ? 0.55 : (dark ? 0.12 : 0.9)), width: 1.2),
        ),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: dark ? 0.7 : 0.25), blurRadius: 14, offset: const Offset(0, 8)),
          if (on) BoxShadow(color: accent.withValues(alpha: 0.10), blurRadius: 22),
        ],
      ),
      child: Center(
        child: busy
            ? SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 2, color: accent))
            : CustomPaint(
                size: const Size(34, 34),
                painter: _PowerPainter(on ? accent : cs.onSurfaceVariant.withValues(alpha: 0.75), on),
              ),
      ),
    );
  }
}

/// Thin power symbol.
class _PowerPainter extends CustomPainter {
  final Color color;
  final bool glow;
  _PowerPainter(this.color, this.glow);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width * 0.40;
    final p = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round;
    if (glow) {
      final g = Paint()
        ..color = color.withValues(alpha: 0.5)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5
        ..strokeCap = StrokeCap.round
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);
      canvas.drawArc(Rect.fromCircle(center: c, radius: r), -1.0 * 3.14159 / 2 + 0.55, 2 * 3.14159 - 1.1, false, g);
      canvas.drawLine(Offset(c.dx, c.dy - r - 1), Offset(c.dx, c.dy - 1), g);
    }
    canvas.drawArc(Rect.fromCircle(center: c, radius: r), -3.14159 / 2 + 0.55, 2 * 3.14159 - 1.1, false, p);
    canvas.drawLine(Offset(c.dx, c.dy - r - 1), Offset(c.dx, c.dy - 1), p);
  }

  @override
  bool shouldRepaint(_PowerPainter o) => o.color != color || o.glow != glow;
}
