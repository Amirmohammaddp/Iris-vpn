import 'package:flutter/material.dart';

import 'anim.dart';
import 'glass.dart';

const _navItems = [
  (Icons.power_settings_new_rounded, 'Home'),
  (Icons.dns_rounded, 'Configs'),
  (Icons.speed_rounded, 'Speed'),
  (Icons.receipt_long_rounded, 'Logs'),
  (Icons.settings_rounded, 'Settings'),
];

class AppNavBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;
  const AppNavBar({super.key, required this.index, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      decoration: BoxDecoration(
        color: cs.surface,
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.5), blurRadius: 18, offset: const Offset(0, -4))],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(6, 8, 6, 8),
          child: Row(
            children: [
              for (var i = 0; i < _navItems.length; i++)
                Expanded(
                  child: _NavItem(
                    icon: _navItems[i].$1,
                    label: _navItems[i].$2,
                    selected: i == index,
                    onTap: () => onChanged(i),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _NavItem({required this.icon, required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Pressable(
      scale: 0.92,
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          GlassIcon(
            icon,
            size: 44,
            iconSize: 21,
            pressed: selected,
            color: selected ? cs.primary : cs.onSurfaceVariant,
          ),
          const SizedBox(height: 4),
          Text(label,
              style: TextStyle(
                  fontSize: 10.5,
                  letterSpacing: 0.3,
                  color: selected ? cs.primary : cs.onSurfaceVariant)),
        ],
      ),
    );
  }
}

/// Side navigation for Android TV (D-pad friendly).
class AppNavRail extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;
  const AppNavRail({super.key, required this.index, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      color: cs.surface,
      child: SizedBox(
        width: 112,
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (var i = 0; i < _navItems.length; i++)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
                  child: _NavItem(
                    icon: _navItems[i].$1,
                    label: _navItems[i].$2,
                    selected: i == index,
                    onTap: () => onChanged(i),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
