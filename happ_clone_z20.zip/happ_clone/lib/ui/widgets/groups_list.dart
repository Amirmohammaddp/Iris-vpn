import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/connection_state.dart';
import '../../models/proxy_config.dart';
import '../../providers/providers.dart';

/// Selects [c] as active; reconnects if the VPN is currently on.
Future<void> selectConfig(WidgetRef ref, BuildContext context, ProxyConfig c) async {
  final wasOn = ref.read(xrayServiceProvider).status == VpnStatus.connected;
  ref.read(activeConfigIdProvider.notifier).set(c.id);
  if (!wasOn) return;
  try {
    final ctl = ref.read(connectionControllerProvider);
    await ctl.toggle(); // stop
    await ctl.toggle(); // start with the new config
  } catch (e) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }
}
