import 'package:flutter/material.dart';

import 'anim.dart';
import 'glass.dart';

const _navItems = [
  (Icons.power_settings_new_rounded, 'Home'),
  (Icons.dns_rounded, 'Configs'),
  (Icons.speed_rounded, 'Speed'),
  (Icons.receipt_long_rounded, 'Logs'),
  (Icons.settings_rounded, 'Settings'),
];

class AppNavBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;
  const AppNavBar({super.key, required this.index, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    const ind = 46.0;
    return Container(
      decoration: BoxDecoration(
        color: cs.surface,
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.6), blurRadius: 18, offset: const Offset(0, -4))],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(6, 8, 6, 8),
          child: LayoutBuilder(builder: (context, c) {
            final w = c.maxWidth / _navItems.length;
            return SizedBox(
              height: 66,
              child: Stack(
                children: [
                  // the pressed "bubble" glides to the selected item
                  AnimatedPositioned(
                    duration: const Duration(milliseconds: 420),
                    curve: Curves.easeOutBack,
                    left: index * w + (w - ind) / 2,
                    top: 0,
                    child: const GlassIcon(Icons.circle, size: ind, pressed: true, color: Colors.transparent),
                  ),
                  Row(
                    children: [
                      for (var i = 0; i < _navItems.length; i++)
                        Expanded(
                          child: _NavItem(
                            icon: _navItems[i].$1,
                            label: _navItems[i].$2,
                            selected: i == index,
                            onTap: () => onChanged(i),
                            bubble: false,
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final bool bubble; // draw own bubble (rail) or rely on the sliding one (bar)
  const _NavItem({required this.icon, required this.label, required this.selected, required this.onTap, this.bubble = true});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final fg = selected ? cs.onSurface : cs.onSurfaceVariant;
    return Pressable(
      scale: 0.92,
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 46,
            height: 46,
            child: bubble
                ? GlassIcon(icon, size: 46, iconSize: 21, pressed: selected, color: fg)
                : Center(
                    child: AnimatedScale(
                      scale: selected ? 1.12 : 1.0,
                      duration: const Duration(milliseconds: 300),
                      child: Icon(icon, size: 22, color: fg),
                    ),
                  ),
          ),
          const SizedBox(height: 3),
          AnimatedDefaultTextStyle(
            duration: const Duration(milliseconds: 300),
            style: TextStyle(fontSize: 10.5, letterSpacing: 0.3, color: fg),
            child: Text(label),
          ),
        ],
      ),
    );
  }
}

/// Side navigation for Android TV (D-pad friendly).
class AppNavRail extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;
  const AppNavRail({super.key, required this.index, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      color: cs.surface,
      child: SizedBox(
        width: 112,
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (var i = 0; i < _navItems.length; i++)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
                  child: _NavItem(
                    icon: _navItems[i].$1,
                    label: _navItems[i].$2,
                    selected: i == index,
                    onTap: () => onChanged(i),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
