import 'package:flutter/material.dart';

import '../theme.dart';
import 'anim.dart';

/// Neumorphic shadows: a dark one bottom-right, a light one top-left.
List<BoxShadow> neuShadows(BuildContext context, {double depth = 6}) {
  final dark = Theme.of(context).brightness == Brightness.dark;
  return [
    BoxShadow(
      color: Colors.black.withValues(alpha: dark ? 0.75 : 0.20),
      blurRadius: depth * 2.2,
      offset: Offset(depth, depth),
    ),
    BoxShadow(
      color: (dark ? Colors.white : Colors.white).withValues(alpha: dark ? 0.06 : 0.95),
      blurRadius: depth * 2,
      offset: Offset(-depth * 0.8, -depth * 0.8),
    ),
  ];
}

/// Raised (convex) or inset (concave) neumorphic surface.
class Glass extends StatelessWidget {
  final Widget child;
  final double radius;
  final double blur; // kept for API compatibility
  final EdgeInsetsGeometry padding;
  final bool inset;
  final double depth;
  final Color? color;
  const Glass({
    super.key,
    required this.child,
    this.radius = 28,
    this.blur = 0,
    this.padding = EdgeInsets.zero,
    this.inset = false,
    this.depth = 6,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = cs.brightness == Brightness.dark;
    final r = BorderRadius.circular(radius);
    final base = color ?? cs.surfaceContainer;
    if (inset) {
      return Container(
        padding: padding,
        decoration: BoxDecoration(
          borderRadius: r,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color.lerp(base, Colors.black, dark ? 0.55 : 0.10)!,
              Color.lerp(base, Colors.white, dark ? 0.03 : 0.55)!,
            ],
          ),
          border: Border.all(color: (dark ? Colors.white : Colors.black).withValues(alpha: 0.04)),
        ),
        child: child,
      );
    }
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: r,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color.lerp(base, Colors.white, dark ? 0.035 : 0.45)!,
            Color.lerp(base, Colors.black, dark ? 0.25 : 0.04)!,
          ],
        ),
        boxShadow: neuShadows(context, depth: depth),
      ),
      child: child,
    );
  }
}

/// Round neumorphic icon button face (raised, or inset when [pressed]).
class GlassIcon extends StatelessWidget {
  final IconData icon;
  final double size;
  final double? iconSize;
  final Color? color;
  final bool pressed;
  const GlassIcon(this.icon, {super.key, this.size = 38, this.iconSize, this.color, this.pressed = false});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return SizedBox(
      width: size,
      height: size,
      child: Glass(
        radius: size / 2,
        inset: pressed,
        depth: size * 0.07,
        child: Center(child: Icon(icon, size: iconSize ?? size * 0.46, color: color ?? AppTheme.iconOf(cs))),
      ),
    );
  }
}

/// Icon button that shows a spinner while its async action runs.
class AsyncGlassButton extends StatefulWidget {
  final IconData icon;
  final Future<void> Function() onPressed;
  final double size;
  const AsyncGlassButton({super.key, required this.icon, required this.onPressed, this.size = 36});

  @override
  State<AsyncGlassButton> createState() => _AsyncGlassButtonState();
}

class _AsyncGlassButtonState extends State<AsyncGlassButton> {
  bool _busy = false;

  Future<void> _run() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await widget.onPressed();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Pressable(
      circle: true,
      onTap: _busy ? null : _run,
      child: _busy
          ? SizedBox(
              width: widget.size,
              height: widget.size,
              child: Glass(
                radius: widget.size / 2,
                inset: true,
                depth: widget.size * 0.07,
                child: Center(
                  child: SizedBox(
                    width: widget.size * 0.42,
                    height: widget.size * 0.42,
                    child: CircularProgressIndicator(strokeWidth: 2, color: cs.primary),
                  ),
                ),
              ),
            )
          : GlassIcon(widget.icon, size: widget.size),
    );
  }
}

/// Neumorphic pill with an icon and a label; shows a spinner and [busyLabel] while running.
class GlassPill extends StatefulWidget {
  final IconData icon;
  final String label;
  final String busyLabel;
  final Color? color;
  final Future<void> Function() onPressed;
  const GlassPill({
    super.key,
    required this.icon,
    required this.label,
    required this.onPressed,
    this.busyLabel = 'Working…',
    this.color,
  });

  @override
  State<GlassPill> createState() => _GlassPillState();
}

class _GlassPillState extends State<GlassPill> {
  bool _busy = false;

  Future<void> _run() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await widget.onPressed();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final fg = widget.color ?? cs.onSurface;
    return Pressable(
      focusRadius: 30,
      onTap: _busy ? null : _run,
      child: Glass(
        radius: 30,
        inset: _busy,
        depth: 3.5,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_busy)
              SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: cs.primary))
            else
              Icon(widget.icon, size: 16, color: AppTheme.iconOf(cs)),
            const SizedBox(width: 7),
            Flexible(
              child: Text(
                _busy ? widget.busyLabel : widget.label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: fg),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Flat app background (kept under its old name).
class AuroraBackground extends StatelessWidget {
  final Widget child;
  const AuroraBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Stack(
      children: [
        Positioned.fill(child: ColoredBox(color: cs.surface)),
        Positioned.fill(child: child),
      ],
    );
  }
}
