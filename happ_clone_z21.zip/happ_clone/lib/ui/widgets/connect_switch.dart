import 'package:flutter/material.dart';

import '../../models/connection_state.dart';
import '../theme.dart';
import 'anim.dart';
import 'glass.dart';

/// Household-style rocker switch (like a wall light switch).
/// ON  = the bottom half is pressed in, the top half is raised and faintly lit.
/// OFF = the top half is pressed in, the bottom half is raised.
class ConnectSwitch extends StatelessWidget {
  final VpnStatus status;
  final VoidCallback onToggle;
  final double width;
  final double height;
  const ConnectSwitch({
    super.key,
    required this.status,
    required this.onToggle,
    this.width = 104,
    this.height = 210,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = cs.brightness == Brightness.dark;
    final on = status == VpnStatus.connected;
    final busy = status == VpnStatus.connecting || status == VpnStatus.disconnecting;
    final target = busy ? 0.5 : (on ? 1.0 : 0.0);
    const glow = AppTheme.yellow;
    const pad = 12.0;

    return Pressable(
      scale: 0.99,
      autofocus: true,
      focusRadius: 30,
      onTap: busy ? null : onToggle,
      child: TweenAnimationBuilder<double>(
        tween: Tween(end: target),
        duration: const Duration(milliseconds: 380),
        curve: Curves.easeOutCubic,
        builder: (context, t, _) {
          final tilt = (t - 0.5) * 2 * 0.30; // +: top raised (on), -: bottom raised (off)
          return Container(
            width: width,
            height: height,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              boxShadow: [BoxShadow(color: glow.withValues(alpha: 0.07 * t), blurRadius: 60, spreadRadius: 4)],
            ),
            // lighter veil around the key
            child: Glass(
              radius: 30,
              depth: 8,
              color: Color.lerp(cs.surfaceContainer, Colors.white, dark ? 0.03 : 0.0),
              padding: const EdgeInsets.all(pad),
              child: Glass(
                radius: 22,
                inset: true,
                depth: 3,
                color: dark ? const Color(0xFF020203) : cs.surfaceContainer,
                padding: const EdgeInsets.all(5),
                child: Transform(
                  alignment: Alignment.center,
                  transform: Matrix4.identity()
                    ..setEntry(3, 2, 0.0022)
                    ..rotateX(tilt),
                  child: _Plate(t: t, on: on, busy: busy, dark: dark, cs: cs),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _Plate extends StatelessWidget {
  final double t; // 0 off .. 1 on
  final bool on;
  final bool busy;
  final bool dark;
  final ColorScheme cs;
  const _Plate({required this.t, required this.on, required this.busy, required this.dark, required this.cs});

  @override
  Widget build(BuildContext context) {
    final raisedTop = t; // how much the top half is raised
    final top = Color.lerp(
      dark ? const Color(0xFF151518) : const Color(0xFFDADDE3),
      dark ? const Color(0xFF2A2A2F) : const Color(0xFFF8F9FB),
      raisedTop,
    )!;
    final bottom = Color.lerp(
      dark ? const Color(0xFF2A2A2F) : const Color(0xFFF8F9FB),
      dark ? const Color(0xFF151518) : const Color(0xFFDADDE3),
      raisedTop,
    )!;
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [top, Color.lerp(top, bottom, 0.5)!, bottom],
          stops: const [0.0, 0.5, 1.0],
        ),
        border: Border.all(color: Colors.white.withValues(alpha: dark ? 0.06 : 0.7)),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: dark ? 0.8 : 0.25), blurRadius: 12, offset: Offset(0, 6 * (t - 0.5) * 2 + 4)),
          if (t > 0.5) BoxShadow(color: AppTheme.yellow.withValues(alpha: 0.10 * (t - 0.5) * 2), blurRadius: 22, offset: const Offset(0, -8)),
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          // groove between the two halves
          Positioned(
            left: 12,
            right: 12,
            top: 0,
            bottom: 0,
            child: Center(
              child: Container(
                height: 1.5,
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: dark ? 0.85 : 0.18),
                  boxShadow: [BoxShadow(color: Colors.white.withValues(alpha: dark ? 0.05 : 0.8), offset: const Offset(0, 1.2))],
                ),
              ),
            ),
          ),
          // faint lit edge on the raised top half when on
          Positioned(
            left: 18,
            right: 18,
            top: 0,
            child: Opacity(
              opacity: ((t - 0.5) * 2).clamp(0.0, 1.0),
              child: Container(
                height: 2,
                decoration: BoxDecoration(
                  color: AppTheme.yellow.withValues(alpha: 0.65),
                  borderRadius: BorderRadius.circular(2),
                  boxShadow: [BoxShadow(color: AppTheme.yellow.withValues(alpha: 0.55), blurRadius: 8)],
                ),
              ),
            ),
          ),
          // power symbol sits on the raised half
          Align(
            alignment: Alignment(0, t >= 0.5 ? -0.5 : 0.5),
            child: busy
                ? SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(strokeWidth: 1.8, color: cs.onSurfaceVariant),
                  )
                : CustomPaint(
                    size: const Size(30, 30),
                    painter: _PowerPainter(on ? AppTheme.yellow : cs.onSurfaceVariant, on),
                  ),
          ),
        ],
      ),
    );
  }
}

/// Thin power symbol.
class _PowerPainter extends CustomPainter {
  final Color color;
  final bool glow;
  _PowerPainter(this.color, this.glow);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width * 0.38;
    const a0 = -3.14159 / 2 + 0.55;
    const sw = 2 * 3.14159 - 1.1;
    final p = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;
    if (glow) {
      final g = Paint()
        ..color = color.withValues(alpha: 0.5)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4.5
        ..strokeCap = StrokeCap.round
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);
      canvas.drawArc(Rect.fromCircle(center: c, radius: r), a0, sw, false, g);
      canvas.drawLine(Offset(c.dx, c.dy - r - 1), Offset(c.dx, c.dy - 1), g);
    }
    canvas.drawArc(Rect.fromCircle(center: c, radius: r), a0, sw, false, p);
    canvas.drawLine(Offset(c.dx, c.dy - r - 1), Offset(c.dx, c.dy - 1), p);
  }

  @override
  bool shouldRepaint(_PowerPainter o) => o.color != color || o.glow != glow;
}
