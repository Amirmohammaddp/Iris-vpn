import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/connection_state.dart';
import '../../providers/providers.dart';
import '../theme.dart';
import '../widgets/anim.dart';
import '../widgets/glass.dart';

/// Speed test that runs *through the active tunnel*: it refuses to start unless the
/// VPN is connected and a probe really passes through it.
class SpeedScreen extends ConsumerStatefulWidget {
  const SpeedScreen({super.key});
  @override
  ConsumerState<SpeedScreen> createState() => _SpeedScreenState();
}

class _SpeedScreenState extends ConsumerState<SpeedScreen> {
  int _tab = 0; // 0 download, 1 upload
  bool _running = false;
  bool _cancel = false;
  double _value = 0;
  double _max = 20;
  double? _down;
  double? _up;
  String _note = '';

  static const _steps = [10.0, 20.0, 50.0, 100.0, 200.0, 500.0, 1000.0];

  @override
  void dispose() {
    _cancel = true;
    super.dispose();
  }

  void _setValue(double v) {
    if (!mounted) return;
    setState(() {
      _value = v;
      for (final s in _steps) {
        if (s >= v * 1.1) {
          if (s > _max) _max = s;
          break;
        }
      }
    });
  }

  Future<void> _start() async {
    if (_running) {
      _cancel = true;
      return;
    }
    final status = ref.read(xrayServiceProvider).status;
    final active = ref.read(activeConfigProvider);
    if (active == null) {
      setState(() => _note = 'Add and select a config first');
      return;
    }
    if (status != VpnStatus.connected) {
      setState(() => _note = 'Connect first: the test runs through the tunnel');
      return;
    }
    setState(() {
      _running = true;
      _cancel = false;
      _value = 0;
      _max = 20;
      _note = 'Checking the tunnel…';
    });
    final probe = await ref.read(xrayServiceProvider).ping(active);
    if (probe < 0) {
      if (mounted) {
        setState(() {
          _running = false;
          _note = 'The tunnel is connected but not passing traffic';
        });
      }
      return;
    }
    if (!mounted) return;
    setState(() => _note = _tab == 0 ? 'Downloading through the tunnel…' : 'Uploading through the tunnel…');
    double r;
    try {
      r = _tab == 0 ? await _download() : await _upload();
    } catch (e) {
      r = -1;
      ref.read(logsProvider.notifier).add('Warn', 'speed test error: $e');
      if (mounted) setState(() => _note = 'Test failed: ${'$e'.split('\n').first}');
    }
    if (!mounted) return;
    setState(() {
      _running = false;
      if (r > 0) {
        if (_tab == 0) {
          _down = r;
        } else {
          _up = r;
        }
        _value = r;
        _note = 'Done';
      } else {
        if (_cancel) { _note = 'Stopped'; } else if (!_note.startsWith('Test failed')) { _note = 'Test failed. Try again'; }
      }
    });
  }

  Future<double> _download() async {
    final client = ref.read(xrayServiceProvider).tunnelClient();
    try {
      final req = await client
          .getUrl(Uri.parse('https://speed.cloudflare.com/__down?bytes=100000000'))
          .timeout(const Duration(seconds: 10));
      final res = await req.close().timeout(const Duration(seconds: 10));
      final sw = Stopwatch()..start();
      var total = 0;
      var winBytes = 0;
      var winStart = 0;
      var sm = 0.0;
      await for (final chunk in res) {
        if (_cancel || !mounted) break;
        total += chunk.length;
        winBytes += chunk.length;
        final ms = sw.elapsedMilliseconds;
        if (ms - winStart >= 250) {
          final inst = winBytes * 8 / ((ms - winStart) / 1000) / 1e6;
          sm = sm == 0 ? inst : sm * 0.6 + inst * 0.4;
          _setValue(sm);
          winBytes = 0;
          winStart = ms;
        }
        if (ms > 9000) break;
      }
      final secs = sw.elapsedMilliseconds / 1000;
      return secs <= 0.5 ? -1 : total * 8 / secs / 1e6;
    } finally {
      client.close(force: true);
    }
  }

  Future<double> _upload() async {
    final client = ref.read(xrayServiceProvider).tunnelClient();
    try {
      final req = await client.postUrl(Uri.parse('https://speed.cloudflare.com/__up')).timeout(const Duration(seconds: 10));
      req.headers.contentType = ContentType.binary;
      req.contentLength = 200 * 1024 * 1024;
      final chunk = Uint8List(64 * 1024);
      final sw = Stopwatch()..start();
      var total = 0;
      var winBytes = 0;
      var winStart = 0;
      var sm = 0.0;
      while (sw.elapsedMilliseconds < 8000 && !_cancel && mounted) {
        req.add(chunk);
        await req.flush();
        total += chunk.length;
        winBytes += chunk.length;
        final ms = sw.elapsedMilliseconds;
        if (ms - winStart >= 250) {
          final inst = winBytes * 8 / ((ms - winStart) / 1000) / 1e6;
          sm = sm == 0 ? inst : sm * 0.6 + inst * 0.4;
          _setValue(sm);
          winBytes = 0;
          winStart = ms;
        }
      }
      final secs = sw.elapsedMilliseconds / 1000;
      req.abort();
      return secs <= 0.5 ? -1 : total * 8 / secs / 1e6;
    } finally {
      client.close(force: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final status = ref.watch(vpnStatusProvider).valueOrNull ?? VpnStatus.disconnected;
    final active = ref.watch(activeConfigProvider);
    final on = status == VpnStatus.connected;

    return SafeArea(
      bottom: false,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(22, 16, 22, 14),
            child: Row(
              children: [
                Text('Speed test', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600, color: cs.onSurface)),
              ],
            ),
          ),
          // Download / Upload tabs
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 22),
            child: Glass(
              radius: 24,
              inset: true,
              depth: 4,
              padding: const EdgeInsets.all(5),
              child: Row(
                children: [
                  for (var i = 0; i < 2; i++)
                    Expanded(
                      child: Pressable(
                        focusRadius: 20,
                        onTap: _running ? null : () => setState(() => _tab = i),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          padding: const EdgeInsets.symmetric(vertical: 11),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: _tab == i ? cs.surfaceContainerHigh : Colors.transparent,
                            boxShadow: _tab == i ? neuShadows(context, depth: 3) : const [],
                          ),
                          child: Center(
                            child: Text(i == 0 ? 'Download' : 'Upload',
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    color: _tab == i ? cs.primary : cs.onSurfaceVariant)),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.south_rounded, size: 14, color: cs.primary),
              const SizedBox(width: 4),
              Text('${(_down ?? 0).toStringAsFixed(1)} Mbps', style: TextStyle(fontSize: 12.5, color: cs.primary)),
              const SizedBox(width: 26),
              Icon(Icons.north_rounded, size: 14, color: cs.primary),
              const SizedBox(width: 4),
              Text('${(_up ?? 0).toStringAsFixed(1)} Mbps', style: TextStyle(fontSize: 12.5, color: cs.primary)),
            ],
          ),
          Expanded(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                child: AspectRatio(
                  aspectRatio: 1,
                  child: TweenAnimationBuilder<double>(
                    tween: Tween(end: _value),
                    duration: const Duration(milliseconds: 350),
                    curve: Curves.easeOutCubic,
                    builder: (context, v, _) => CustomPaint(
                      painter: _GaugePainter(value: v, max: _max, cs: cs, context: context),
                      child: Align(
                        alignment: const Alignment(0, 0.62),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(v.toStringAsFixed(v < 100 ? 2 : 1),
                                style: TextStyle(fontSize: 30, fontWeight: FontWeight.w600, color: cs.onSurface)),
                            Text('Mbps', style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          if (_note.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 10),
              child: Text(_note, textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
            ),
          Pressable(
            circle: true,
            onTap: _start,
            child: SizedBox(
              width: 92,
              height: 92,
              child: Glass(
                radius: 46,
                depth: 7,
                inset: _running,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 16,
                      height: 3,
                      margin: const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: _running ? cs.onSurfaceVariant : AppTheme.yellow,
                        borderRadius: BorderRadius.circular(2),
                        boxShadow: _running ? const [] : [BoxShadow(color: AppTheme.yellow.withValues(alpha: 0.5), blurRadius: 6)],
                      ),
                    ),
                    Text(_running ? 'STOP' : 'START',
                        style: TextStyle(fontSize: 12, letterSpacing: 1.5, fontWeight: FontWeight.w600, color: cs.onSurface)),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          // which config the test runs on
          Padding(
            padding: const EdgeInsets.fromLTRB(22, 0, 22, 18),
            child: Glass(
              radius: 22,
              depth: 4,
              inset: true,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(
                children: [
                  Icon(Icons.alt_route_rounded, size: 20, color: on ? cs.primary : cs.onSurfaceVariant),
                  const SizedBox(width: 10),
                  Expanded(
                    child: active == null
                        ? Text('No config selected', style: TextStyle(fontSize: 13, color: cs.onSurfaceVariant))
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('${active.flag}  ${active.name}',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: cs.onSurface)),
                              Text(on ? 'Testing through this tunnel' : 'Not connected',
                                  style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
                            ],
                          ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _GaugePainter extends CustomPainter {
  final double value;
  final double max;
  final ColorScheme cs;
  final BuildContext context;
  _GaugePainter({required this.value, required this.max, required this.cs, required this.context});

  static const start = 3 * math.pi / 4; // bottom-left
  static const sweep = 3 * math.pi / 2; // 270 degrees

  @override
  void paint(Canvas canvas, Size size) {
    final dark = cs.brightness == Brightness.dark;
    final c = size.center(Offset.zero);
    final r = size.width * 0.34;
    final stroke = size.width * 0.075;
    final rect = Rect.fromCircle(center: c, radius: r);
    // raised disc behind the gauge
    final disc = Paint()
      ..shader = RadialGradient(colors: [
        Color.lerp(cs.surfaceContainer, Colors.white, dark ? 0.03 : 0.4)!,
        Color.lerp(cs.surfaceContainer, Colors.black, dark ? 0.3 : 0.05)!,
      ]).createShader(Rect.fromCircle(center: c, radius: r * 1.25));
    canvas.drawShadow(Path()..addOval(Rect.fromCircle(center: c, radius: r * 1.22)), Colors.black, 14, true);
    canvas.drawCircle(c, r * 1.22, disc);
    // track
    final track = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round
      ..color = dark ? const Color(0xFF0A0A0B) : const Color(0xFFCDD0D6);
    canvas.drawArc(rect, start, sweep, false, track);
    // progress
    final f = (value / max).clamp(0.0, 1.0);
    if (f > 0.002) {
      final glow = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = stroke
        ..strokeCap = StrokeCap.round
        ..color = AppTheme.yellow.withValues(alpha: 0.35)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
      canvas.drawArc(rect, start, sweep * f, false, glow);
      final prog = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = stroke * 0.8
        ..strokeCap = StrokeCap.round
        ..color = AppTheme.yellow;
      canvas.drawArc(rect, start, sweep * f, false, prog);
    }
    // ticks + labels
    const n = 6;
    for (var i = 0; i <= n; i++) {
      final a = start + sweep * i / n;
      final p1 = c + Offset(math.cos(a), math.sin(a)) * (r + stroke * 0.9);
      final p2 = c + Offset(math.cos(a), math.sin(a)) * (r + stroke * 1.35);
      canvas.drawLine(p1, p2, Paint()..color = cs.onSurfaceVariant.withValues(alpha: 0.6)..strokeWidth = 1.4);
      final lab = max * i / n;
      final tp = TextPainter(
        text: TextSpan(
            text: lab >= 100 ? lab.toStringAsFixed(0) : (lab % 1 == 0 ? lab.toStringAsFixed(0) : lab.toStringAsFixed(1)),
            style: TextStyle(fontSize: size.width * 0.038, color: cs.onSurfaceVariant, fontFamily: 'Ui')),
        textDirection: TextDirection.ltr,
      )..layout();
      final pos = c + Offset(math.cos(a), math.sin(a)) * (r + stroke * 2.4) - Offset(tp.width / 2, tp.height / 2);
      tp.paint(canvas, pos);
    }
    // needle
    final a = start + sweep * f;
    final tip = c + Offset(math.cos(a), math.sin(a)) * (r * 0.78);
    canvas.drawLine(c, tip, Paint()..color = AppTheme.yellow..strokeWidth = 2.4..strokeCap = StrokeCap.round);
    canvas.drawCircle(c, size.width * 0.04, Paint()..color = cs.surface);
    canvas.drawCircle(c, size.width * 0.04, Paint()..color = AppTheme.yellow..style = PaintingStyle.stroke..strokeWidth = 2);
    canvas.drawCircle(c, size.width * 0.018, Paint()..color = AppTheme.yellow);
  }

  @override
  bool shouldRepaint(_GaugePainter o) => o.value != value || o.max != max || o.cs != cs;
}
