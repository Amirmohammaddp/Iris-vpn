import '../theme.dart';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../constants.dart';
import '../../models/app_settings.dart';
import '../../providers/providers.dart';
import '../../services/links.dart';
import '../../services/notice_service.dart';
import '../widgets/anim.dart';
import '../widgets/glass.dart';
import 'inbox_screen.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  final bool embedded;
  const SettingsScreen({super.key, this.embedded = false});
  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  int _open = -1;

  static const _subs = {
    'Appearance': 'Theme, sorting, Zen mode',
    'Connection': 'Mode, DNS, routing, anti-filter',
    'Updates & ping': 'Auto-update, ping on start',
    'Speed & stability': 'Auto-reconnect, keep-alive, QUIC',
    'Notifications': 'Announcements and inbox',
    'Restricted network': 'Fragment, auto-switch',
    'Support': 'Contact us, buy subscription',
    'About': 'IRIS VPN, made by Iris',
  };

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final st = ref.watch(settingsProvider);
    final n = ref.read(settingsProvider.notifier);

    Widget card(int index, String title, IconData icon, List<Widget> children) {
      final open = _open == index;
      return FadeSlideIn(
        index: index,
        child: Container(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
          child: Glass(
            radius: 26,
            blur: 16,
            child: Column(
              children: [
                Pressable(
                  scale: 0.985,
                  focusRadius: 26,
                  onTap: () => setState(() => _open = open ? -1 : index),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      children: [
                        GlassIcon(icon, size: 44),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(title,
                                  style: TextStyle(color: cs.primary, fontWeight: FontWeight.w600, fontSize: 16)),
                              Text(_subs[title] ?? '', style: TextStyle(fontSize: 11.5, color: cs.onSurfaceVariant)),
                            ],
                          ),
                        ),
                        AnimatedRotation(
                          turns: open ? 0.5 : 0,
                          duration: const Duration(milliseconds: 320),
                          curve: Curves.easeInOutCubic,
                          child: Icon(Icons.expand_more_rounded, color: cs.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ),
                ),
                AnimatedSize(
                  duration: const Duration(milliseconds: 400),
                  curve: Curves.easeInOutCubic,
                  alignment: Alignment.topCenter,
                  child: open
                      ? Padding(
                          padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
                        )
                      : const SizedBox(width: double.infinity),
                ),
              ],
            ),
          ),
        ),
      );
    }

    Widget label(String t) => Padding(
          padding: const EdgeInsets.only(top: 6, bottom: 8),
          child: Text(t, style: TextStyle(fontSize: 12.5, color: cs.onSurfaceVariant, fontWeight: FontWeight.w600)),
        );

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: AuroraBackground(
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
                child: Glass(
                  radius: 30,
                  blur: 22,
                  padding: const EdgeInsets.all(10),
                  child: Row(
                    children: [
                      if (!widget.embedded) ...[
                        Pressable(
                          circle: true,
                          autofocus: true,
                          onTap: () => Navigator.maybePop(context),
                          child: const GlassIcon(Icons.arrow_back_rounded, size: 44),
                        ),
                        const SizedBox(width: 14),
                      ] else
                        const SizedBox(width: 8),
                      Text('Settings',
                          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600, color: cs.primary)),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.only(top: 2, bottom: 40),
                  children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 18),
            child: Glass(
              radius: 28,
              depth: 6,
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: Column(
                children: [
                  Image.asset('assets/images/iris_logo.png', width: 78, height: 78),
                  const SizedBox(height: 8),
                  Text('IRIS VPN',
                      style: TextStyle(fontFamily: 'Audiowide', fontSize: 20, letterSpacing: 5, color: cs.onSurface)),
                  const SizedBox(height: 10),
                  Text('Designed & built by', style: TextStyle(fontSize: 11, letterSpacing: 1.5, color: cs.onSurfaceVariant)),
                  const SizedBox(height: 2),
                  Text('Iris',
                      style: TextStyle(fontFamily: 'Solene', fontSize: 30, letterSpacing: 8, color: cs.onSurface.withValues(alpha: 0.85))),
                ],
              ),
            ),
          ),
          card(0, 'Appearance', Icons.palette_rounded, [
            label('Color palette'),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<AppThemeMode>(
                segments: const [
                  ButtonSegment(value: AppThemeMode.dark, label: Text('Night'), icon: Icon(Icons.dark_mode_rounded)),
                  ButtonSegment(value: AppThemeMode.light, label: Text('Day'), icon: Icon(Icons.light_mode_rounded)),
                ],
                selected: {st.theme},
                onSelectionChanged: (v) => n.update((x) => x.copyWith(theme: v.first)),
              ),
            ),
            label('Sort configs by'),
            Wrap(spacing: 8, runSpacing: 4, children: [
              for (final (m, t) in const [
                (SortMode.added, 'Time added'),
                (SortMode.name, 'Name (A–Z)'),
                (SortMode.ping, 'Ping'),
                (SortMode.protocol, 'Protocol'),
              ])
                ChoiceChip(
                  label: Text(t),
                  selected: st.sort == m,
                  onSelected: (_) => n.update((x) => x.copyWith(sort: m)),
                ),
            ]),
            const SizedBox(height: 4),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: GlassIcon(Icons.spa_rounded, size: 36),
              title: const Text('Zen mode'),
              subtitle: const Text('Home shows only one round connect button'),
              value: st.zenMode,
              onChanged: (v) => n.update((x) => x.copyWith(zenMode: v)),
            ),
          ]),
          card(1, 'Connection', Icons.vpn_lock_rounded, [
            label('Connection mode'),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<ConnectionMode>(
                segments: const [
                  ButtonSegment(value: ConnectionMode.vpn, label: Text('VPN (TUN)'), icon: Icon(Icons.vpn_lock_rounded)),
                  ButtonSegment(value: ConnectionMode.proxy, label: Text('Proxy'), icon: Icon(Icons.lan_rounded)),
                ],
                selected: {st.mode},
                onSelectionChanged: (v) => n.update((x) => x.copyWith(mode: v.first)),
              ),
            ),
            label('Routing'),
            Wrap(spacing: 8, runSpacing: 4, children: [
              for (final (r, t) in const [
                (RoutingMode.global, 'Global'),
                (RoutingMode.ruleBased, 'Smart (IR direct)'),
                (RoutingMode.direct, 'Direct'),
              ])
                ChoiceChip(
                  label: Text(t),
                  selected: st.routing == r,
                  onSelected: (_) => n.update((x) => x.copyWith(routing: r)),
                ),
            ]),
            label('DNS'),
            TextFormField(
              initialValue: st.useDoh ? st.dohUrl : st.dns,
              key: ValueKey(st.useDoh),
              textDirection: TextDirection.ltr,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.dns_rounded),
                labelText: st.useDoh ? 'DoH URL' : 'DNS server',
              ),
              onChanged: (v) => n.update((x) => st.useDoh ? x.copyWith(dohUrl: v) : x.copyWith(dns: v)),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Use DNS over HTTPS'),
              value: st.useDoh,
              onChanged: (v) => n.update((x) => x.copyWith(useDoh: v)),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: GlassIcon(Icons.shield_rounded, size: 36),
              title: const Text('Kill switch'),
              subtitle: const Text('Block traffic when VPN drops'),
              value: st.killSwitch,
              onChanged: (v) => n.update((x) => x.copyWith(killSwitch: v)),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: GlassIcon(Icons.bolt_rounded, size: 36),
              title: const Text('Auto connect'),
              value: st.autoConnect,
              onChanged: (v) => n.update((x) => x.copyWith(autoConnect: v)),
            ),
            label('Split tunneling (excluded apps)'),
            TextFormField(
              initialValue: st.excludedApps.join(', '),
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(
                hintText: 'Package names, comma-separated',
                prefixIcon: Icon(Icons.call_split_rounded),
              ),
              onChanged: (v) => n.update((x) => x.copyWith(
                  excludedApps: v.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList())),
            ),
            const SizedBox(height: 6),
          ]),
          card(2, 'Updates & ping', Icons.sync_rounded, [
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: GlassIcon(Icons.speed_rounded, size: 36),
              title: const Text('Test ping on app open'),
              subtitle: const Text('Pings all configs each time the app starts'),
              value: st.pingOnStart,
              onChanged: (v) => n.update((x) => x.copyWith(pingOnStart: v)),
            ),
            label('Auto-update subscriptions'),
            Wrap(spacing: 8, runSpacing: 4, children: [
              for (final u in AutoUpdate.values)
                ChoiceChip(
                  label: Text(u.label),
                  selected: st.autoUpdate == u,
                  onSelected: (_) => n.update((x) => x.copyWith(autoUpdate: u)),
                ),
            ]),
            const SizedBox(height: 4),
            Text('Timed updates run while the app is open or running in the background.',
                style: TextStyle(fontSize: 11.5, color: cs.onSurfaceVariant)),
            const SizedBox(height: 6),
          ]),
          card(3, 'Speed & stability', Icons.speed_rounded, [
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: GlassIcon(Icons.autorenew_rounded, size: 36),
              title: const Text('Auto-reconnect'),
              subtitle: const Text('Checks the tunnel every 25 s and reconnects (or switches config) if it stops working'),
              value: st.autoReconnect,
              onChanged: (v) => n.update((x) => x.copyWith(autoReconnect: v)),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: GlassIcon(Icons.anchor_rounded, size: 36),
              title: const Text('Stability boost'),
              subtitle: const Text('TCP keep-alive, longer idle timeout, and dials the server IP directly (no DNS dependency)'),
              value: st.stability,
              onChanged: (v) => n.update((x) => x.copyWith(stability: v)),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: GlassIcon(Icons.block_rounded, size: 36),
              title: const Text('Block QUIC (UDP 443)'),
              subtitle: const Text('Apps fall back to TCP, which is faster and steadier through proxies'),
              value: st.blockQuic,
              onChanged: (v) => n.update((x) => x.copyWith(blockQuic: v)),
            ),
            const SizedBox(height: 4),
            Text('Changes apply on the next connect. On Xiaomi/MIUI also enable Autostart and set Battery saver to “No restrictions” for this app.',
                style: TextStyle(fontSize: 11.5, color: cs.onSurfaceVariant)),
            const SizedBox(height: 6),
          ]),
          card(4, 'Notifications', Icons.notifications_rounded, [
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: GlassIcon(Icons.campaign_rounded, size: 36),
              title: const Text('Announcements & offers'),
              subtitle: const Text('Get news and discounts as notifications'),
              value: st.notifications,
              onChanged: (v) {
                n.update((x) => x.copyWith(notifications: v));
                NoticeService.setEnabled(v);
              },
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: GlassIcon(Icons.inbox_rounded, size: 36),
              title: const Text('Inbox'),
              subtitle: const Text('Past announcements'),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const InboxScreen())),
            ),
          ]),
          card(5, 'Restricted network', Icons.shield_moon_rounded, [
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: GlassIcon(Icons.content_cut_rounded, size: 36),
              title: const Text('Anti-filter mode'),
              subtitle: const Text('Fragments the TLS handshake to get past deep packet inspection'),
              value: st.fragment,
              onChanged: (v) => n.update((x) => x.copyWith(fragment: v)),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              secondary: GlassIcon(Icons.swap_horiz_rounded, size: 36),
              title: const Text('Auto-switch config'),
              subtitle: const Text('If a config fails, try the best 3 other configs automatically'),
              value: st.autoSwitch,
              onChanged: (v) => n.update((x) => x.copyWith(autoSwitch: v)),
            ),
          ]),
          card(6, 'Support', Icons.support_agent_rounded, [
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: GlassIcon(Icons.telegram, size: 36),
              title: const Text('Contact us'),
              subtitle: const Text('@$kTelegramId'),
              trailing: IconButton(
                tooltip: 'Copy ID',
                icon: const Icon(Icons.copy_rounded, size: 20),
                onPressed: () async {
                  await Clipboard.setData(const ClipboardData(text: '@$kTelegramId'));
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Telegram ID copied')));
                  }
                },
              ),
              onTap: () => openTelegram(context),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: GlassIcon(Icons.shopping_cart_rounded, size: 36),
              title: const Text('Buy subscription'),
              subtitle: const Text('Opens Telegram chat'),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => openTelegram(context),
            ),
          ]),
          card(7, 'About', Icons.info_outline_rounded, [
            const SizedBox(height: 4),
            Center(child: Image.asset('assets/images/iris_logo.png', width: 110, height: 110)),
            const SizedBox(height: 6),
            Center(
              child: Text('IRIS VPN',
                  style: TextStyle(fontFamily: 'Audiowide', fontSize: 22, letterSpacing: 4, color: cs.primary)),
            ),
            const SizedBox(height: 10),
            Center(
              child: Text('Designed & built by',
                  style: TextStyle(fontSize: 11.5, letterSpacing: 1, color: cs.onSurfaceVariant)),
            ),
            const SizedBox(height: 2),
            Center(
              child: Text('Iris',
                  style: TextStyle(fontFamily: 'Solene', fontSize: 30, letterSpacing: 6, color: cs.onSurface)),
            ),
            const SizedBox(height: 8),
          ]),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Opens settings with a circular reveal that grows from the gear icon.
Future<void> openSettings(BuildContext context) {
  final top = MediaQuery.of(context).padding.top;
  final origin = Offset(16 + 12 + 23, top + 10 + 12 + 23);
  return Navigator.of(context).push(
    PageRouteBuilder<void>(
      transitionDuration: const Duration(milliseconds: 650),
      reverseTransitionDuration: const Duration(milliseconds: 450),
      pageBuilder: (_, __, ___) => const SettingsScreen(),
      transitionsBuilder: (context, anim, sec, child) {
        final curved = CurvedAnimation(parent: anim, curve: Curves.easeInOutCubic, reverseCurve: Curves.easeInCubic);
        return AnimatedBuilder(
          animation: curved,
          builder: (context, _) => ClipPath(
            clipper: _RevealClipper(curved.value, origin),
            child: FadeTransition(
              opacity: CurvedAnimation(parent: anim, curve: const Interval(0.1, 0.7)),
              child: child,
            ),
          ),
        );
      },
    ),
  );
}

class _RevealClipper extends CustomClipper<Path> {
  final double t;
  final Offset origin;
  _RevealClipper(this.t, this.origin);

  @override
  Path getClip(Size size) {
    final dx = math.max(origin.dx, size.width - origin.dx);
    final dy = math.max(origin.dy, size.height - origin.dy);
    final maxR = math.sqrt(dx * dx + dy * dy);
    return Path()..addOval(Rect.fromCircle(center: origin, radius: maxR * t));
  }

  @override
  bool shouldReclip(_RevealClipper old) => old.t != t || old.origin != origin;
}
