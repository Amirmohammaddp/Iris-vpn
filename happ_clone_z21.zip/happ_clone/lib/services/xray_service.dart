import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/services.dart';
import 'package:flutter_vless/flutter_vless.dart' as v;

import '../models/app_settings.dart';
import '../models/connection_state.dart';
import '../models/proxy_config.dart';
import 'config_parser.dart';

class XrayException implements Exception {
  final String message;
  XrayException(this.message);
  @override
  String toString() => message;
}

/// Contract for the VPN engine. Replace [MockXrayService] with a
/// flutter_vless-backed implementation later.
abstract class XrayService {
  Stream<VpnStatus> get statusStream;
  Stream<TrafficStats> get trafficStream;
  Stream<String> get logStream;
  VpnStatus get status;

  Future<void> start(ProxyConfig config, AppSettings settings);
  Future<void> stop();
  Future<int> ping(ProxyConfig config);
  /// HttpClient whose traffic goes through the running tunnel (local HTTP inbound).
  HttpClient tunnelClient();
  void dispose();
}

/// Android VpnService permission bridge (see MainActivity.kt).
class VpnPermission {
  static const _ch = MethodChannel('happ/vpn');
  static Future<bool> request() async {
    try {
      return await _ch.invokeMethod<bool>('prepare') ?? false;
    } on MissingPluginException {
      return true; // non-Android / tests
    } on PlatformException catch (e) {
      throw XrayException('دسترسی VPN رد شد: ${e.message}');
    }
  }
}

class MockXrayService implements XrayService {
  final _status = StreamController<VpnStatus>.broadcast();
  final _traffic = StreamController<TrafficStats>.broadcast();
  final _logs = StreamController<String>.broadcast();
  final _rnd = Random();
  Timer? _timer;
  VpnStatus _current = VpnStatus.disconnected;
  TrafficStats _stats = TrafficStats.zero;

  @override
  Stream<VpnStatus> get statusStream => _status.stream;
  @override
  Stream<TrafficStats> get trafficStream => _traffic.stream;
  @override
  Stream<String> get logStream => _logs.stream;
  @override
  VpnStatus get status => _current;

  void _set(VpnStatus s) {
    _current = s;
    _status.add(s);
  }

  void _log(String level, String msg) {
    final t = DateTime.now().toIso8601String().substring(11, 23);
    _logs.add('$t [$level] $msg');
  }

  @override
  Future<void> start(ProxyConfig config, AppSettings settings) async {
    if (_current == VpnStatus.connected || _current == VpnStatus.connecting) return;
    _set(VpnStatus.connecting);
    try {
      if (settings.mode == ConnectionMode.vpn && !await VpnPermission.request()) {
        throw XrayException('کاربر دسترسی VPN را نداد');
      }
      final json = ConfigParser.toXrayJson(config, settings);
      _log('Info', 'Xray 1.8.x (mock) started');
      _log('Debug', 'config: ${jsonEncode(json).length} bytes, outbound=${config.protocol.name}');
      _log('Info', 'routing mode: ${settings.routing.name}');
      await Future<void>.delayed(const Duration(milliseconds: 1200));
      _set(VpnStatus.connected);
      _log('Info', 'connected to ${config.address}:${config.port}');
      _stats = TrafficStats.zero;
      _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick(config));
    } catch (e) {
      _log('Error', '$e');
      _set(VpnStatus.error);
      _set(VpnStatus.disconnected);
      rethrow;
    }
  }

  void _tick(ProxyConfig c) {
    final down = 20000 + _rnd.nextInt(900000);
    final up = 5000 + _rnd.nextInt(120000);
    _stats = TrafficStats(
      downBps: down,
      upBps: up,
      totalDown: _stats.totalDown + down,
      totalUp: _stats.totalUp + up,
    );
    _traffic.add(_stats);
    if (_rnd.nextInt(4) == 0) {
      const hosts = ['www.google.com', 'api.telegram.org', 'digikala.com', 'youtube.com'];
      final h = hosts[_rnd.nextInt(hosts.length)];
      final route = h.endsWith('.com') && h.startsWith('digi') ? 'direct' : 'proxy';
      _log('Info', 'tcp:$h:443 accepted [socks -> $route]');
    }
  }

  @override
  Future<void> stop() async {
    if (_current == VpnStatus.disconnected) return;
    _set(VpnStatus.disconnecting);
    _timer?.cancel();
    await Future<void>.delayed(const Duration(milliseconds: 400));
    _traffic.add(TrafficStats.zero);
    _log('Info', 'Xray stopped');
    _set(VpnStatus.disconnected);
  }

  @override
  Future<int> ping(ProxyConfig config) async {
    await Future<void>.delayed(Duration(milliseconds: 200 + _rnd.nextInt(800)));
    return _rnd.nextInt(10) == 0 ? -1 : 60 + _rnd.nextInt(400);
  }

  @override
  HttpClient tunnelClient() => HttpClient();

  @override
  void dispose() {
    _timer?.cancel();
    _status.close();
    _traffic.close();
    _logs.close();
  }
}


/// Real Xray engine backed by the `flutter_vless` plugin (Android VpnService + Xray core).
class FlutterVlessXrayService implements XrayService {
  final _status = StreamController<VpnStatus>.broadcast();
  final _traffic = StreamController<TrafficStats>.broadcast();
  final _logs = StreamController<String>.broadcast();
  late final v.FlutterVless _vless;
  VpnStatus _current = VpnStatus.disconnected;
  bool _initialized = false;
  String _lastState = '';
  String? _connectedId;
  Completer<void>? _waitConnected;

  FlutterVlessXrayService() {
    _vless = v.FlutterVless(onStatusChanged: _onStatus);
  }

  @override
  Stream<VpnStatus> get statusStream => _status.stream;
  @override
  Stream<TrafficStats> get trafficStream => _traffic.stream;
  @override
  Stream<String> get logStream => _logs.stream;
  @override
  VpnStatus get status => _current;

  void _log(String level, String msg) {
    final t = DateTime.now().toIso8601String().substring(11, 23);
    _logs.add('$t [$level] $msg');
  }

  void _set(VpnStatus s) {
    if (_current == s) return;
    _current = s;
    _status.add(s);
  }

  void _onStatus(v.VlessStatus st) {
    if (st.state != _lastState) {
      _lastState = st.state;
      _log('Debug', 'core state: ${st.state}');
    }
    switch (st.connectionState) {
      case v.VlessConnectionState.connected:
        _set(VpnStatus.connected);
        final w = _waitConnected;
        if (w != null && !w.isCompleted) w.complete();
      case v.VlessConnectionState.connecting:
        _set(VpnStatus.connecting);
      case v.VlessConnectionState.disconnecting:
        _set(VpnStatus.disconnecting);
      case v.VlessConnectionState.disconnected:
        _set(VpnStatus.disconnected);
        _connectedId = null;
        _traffic.add(TrafficStats.zero);
      case v.VlessConnectionState.unknown:
        _log('Warn', 'unknown state: ${st.state}');
        return;
    }
    if (st.connectionState == v.VlessConnectionState.connected) {
      _traffic.add(TrafficStats(
        downBps: st.downloadSpeed,
        upBps: st.uploadSpeed,
        totalDown: st.download,
        totalUp: st.upload,
      ));
    }
  }

  /// Builds the Xray JSON. Prefers the plugin's own generator (its native tunnel
  /// expects a specific SOCKS inbound); falls back to our own builder.
  Future<String> _buildConfig(ProxyConfig config, AppSettings settings) async {
    Map<String, dynamic> map;
    try {
      map = jsonDecode(v.FlutterVless.parse(config.rawLink).getFullConfiguration()) as Map<String, dynamic>;
    } catch (_) {
      map = ConfigParser.toXrayJson(config, settings);
    }
    final routing = _routing(settings.routing);
    if (routing != null) {
      map['routing'] = routing;
      _ensureDirect(map);
    }
    if (settings.fragment) _applyFragment(map);
    _log('Debug', 'options: routing=${settings.routing.name} stability=${settings.stability} quic-block=${settings.blockQuic} fragment=${settings.fragment}');
    if (settings.stability) {
      _trimSniffing(map);
      _applyStability(map);
      await _pinAddress(map);
    }
    if (settings.blockQuic) _blockQuic(map);
    _addTunnelInbound(map);
    return jsonEncode(map);
  }

  /// Rules send traffic to the 'direct' tag, so make sure such an outbound exists.
  void _ensureDirect(Map<String, dynamic> map) {
    final ob = map['outbounds'];
    if (ob is! List) return;
    if (ob.any((o) => o is Map && o['tag'] == 'direct')) return;
    ob.add({'tag': 'direct', 'protocol': 'freedom', 'settings': {}});
  }

  /// QUIC sniffing only confuses routing; TCP/TLS/HTTP is enough.
  void _trimSniffing(Map<String, dynamic> map) {
    final ins = map['inbounds'];
    if (ins is! List) return;
    for (final i in ins) {
      if (i is Map && i['sniffing'] is Map) {
        final sn = Map<String, dynamic>.from(i['sniffing'] as Map);
        sn['enabled'] = true;
        sn['destOverride'] = ['http', 'tls'];
        i['sniffing'] = sn;
      }
    }
  }

  /// Stability: TCP keep-alive (keeps carrier NAT mappings alive) and longer idle timeouts.
  void _applyStability(Map<String, dynamic> map) {
    final outs = map['outbounds'];
    if (outs is List && outs.isNotEmpty && outs.first is Map) {
      final first = outs.first as Map;
      final proto = first['protocol'];
      const skip = {'hysteria2', 'hysteria', 'wireguard', 'freedom', 'blackhole'};
      if (!skip.contains(proto)) {
        final ss = first['streamSettings'];
        final stream = ss is Map ? Map<String, dynamic>.from(ss) : <String, dynamic>{};
        final so = stream['sockopt'];
        final sock = so is Map ? Map<String, dynamic>.from(so) : <String, dynamic>{};
        sock['tcpKeepAliveIdle'] = 30;
        sock['tcpKeepAliveInterval'] = 15;
        sock['tcpNoDelay'] = true;
        stream['sockopt'] = sock;
        first['streamSettings'] = stream;
      }
    }
    final pol = map['policy'];
    final policy = pol is Map ? Map<String, dynamic>.from(pol) : <String, dynamic>{};
    final lv = policy['levels'];
    final levels = lv is Map ? Map<String, dynamic>.from(lv) : <String, dynamic>{};
    for (final k in const ['0', '8']) {
      final cur = levels[k];
      final m = cur is Map ? Map<String, dynamic>.from(cur) : <String, dynamic>{};
      m['handshake'] = 8;
      m['connIdle'] = 600;
      levels[k] = m;
    }
    policy['levels'] = levels;
    map['policy'] = policy;
  }

  /// Resolves the server's domain once (outside the tunnel) and dials the IP directly,
  /// so DNS problems cannot break reconnects. Only when SNI/Host is set explicitly.
  Future<void> _pinAddress(Map<String, dynamic> map) async {
    try {
      final outs = map['outbounds'];
      if (outs is! List || outs.isEmpty || outs.first is! Map) return;
      final first = outs.first as Map;
      const skip = {'hysteria2', 'hysteria', 'wireguard', 'freedom', 'blackhole'};
      if (skip.contains(first['protocol'])) return;
      final st = first['settings'];
      if (st is! Map) return;
      Map? target;
      final vnext = st['vnext'];
      final servers = st['servers'];
      if (vnext is List && vnext.isNotEmpty && vnext.first is Map) {
        target = vnext.first as Map;
      } else if (servers is List && servers.isNotEmpty && servers.first is Map) {
        target = servers.first as Map;
      }
      if (target == null) return;
      final host = target['address'];
      if (host is! String || host.isEmpty || InternetAddress.tryParse(host) != null) return;
      final ss = first['streamSettings'];
      if (ss is! Map) return;
      final sec = ss['security'];
      String? sni;
      if (sec == 'tls') {
        final t = ss['tlsSettings'];
        sni = t is Map ? t['serverName'] as String? : null;
      } else if (sec == 'reality') {
        final t = ss['realitySettings'];
        sni = t is Map ? t['serverName'] as String? : null;
      } else {
        final ws = ss['wsSettings'];
        if (ws is Map) {
          final h = ws['headers'];
          final hv = h is Map ? h['Host'] : null;
          sni = hv is String ? hv : ws['host'] as String?;
        }
      }
      if (sni == null || sni.isEmpty) return;
      final addrs =
          await InternetAddress.lookup(host, type: InternetAddressType.IPv4).timeout(const Duration(seconds: 4));
      if (addrs.isEmpty) return;
      target['address'] = addrs.first.address;
      _log('Info', 'server $host pinned to ${addrs.first.address}');
    } catch (_) {
      // keep the original address
    }
  }

  /// Blocks UDP/443 (QUIC) so apps fall back to TCP, which is much faster and more stable through proxies.
  void _blockQuic(Map<String, dynamic> map) {
    final ob = map['outbounds'];
    if (ob is! List) return;
    String? tag;
    for (final o in ob) {
      if (o is Map && o['protocol'] == 'blackhole') tag = o['tag'] as String?;
    }
    if (tag == null) {
      tag = 'block';
      ob.add({'tag': tag, 'protocol': 'blackhole'});
    }
    final r = map['routing'];
    final routing = r is Map ? Map<String, dynamic>.from(r) : <String, dynamic>{'domainStrategy': 'AsIs'};
    final rl = routing['rules'];
    final rules = rl is List ? List<dynamic>.from(rl) : <dynamic>[];
    rules.insert(0, {'type': 'field', 'network': 'udp', 'port': '443', 'outboundTag': tag});
    routing['rules'] = rules;
    map['routing'] = routing;
  }

  /// Anti-filter mode: splits the TLS hello of the proxy connection into small
  /// pieces (Xray freedom `fragment`), which helps against DPI-based filtering.
  void _applyFragment(Map<String, dynamic> map) {
    final outs = map['outbounds'];
    if (outs is! List || outs.isEmpty) return;
    if (outs.any((o) => o is Map && o['tag'] == 'fragment')) return;
    final first = outs.first;
    if (first is! Map) return;
    final proto = first['protocol'];
    if (proto == 'hysteria2' || proto == 'hysteria' || proto == 'wireguard') return;
    final ss = first['streamSettings'];
    final stream = ss is Map ? Map<String, dynamic>.from(ss) : <String, dynamic>{};
    final so = stream['sockopt'];
    final sock = so is Map ? Map<String, dynamic>.from(so) : <String, dynamic>{};
    sock['dialerProxy'] = 'fragment';
    stream['sockopt'] = sock;
    first['streamSettings'] = stream;
    outs.add({
      'tag': 'fragment',
      'protocol': 'freedom',
      'settings': {
        'domainStrategy': 'AsIs',
        'fragment': {'packets': 'tlshello', 'length': '100-200', 'interval': '10-20'},
      },
    });
  }

  Map<String, dynamic>? _routing(RoutingMode mode) {
    switch (mode) {
      case RoutingMode.global:
        return null;
      case RoutingMode.ruleBased:
        return {
          'domainStrategy': 'AsIs',
          'rules': [
            {'type': 'field', 'domain': ['domain:ir'], 'outboundTag': 'direct'},
            {'type': 'field', 'ip': ['geoip:ir', 'geoip:private'], 'outboundTag': 'direct'},
          ],
        };
      case RoutingMode.direct:
        return {
          'domainStrategy': 'AsIs',
          'rules': [
            {'type': 'field', 'network': 'tcp,udp', 'outboundTag': 'direct'},
          ],
        };
    }
  }

  Future<void> _init() async {
    if (_initialized) return;
    await _vless.initializeVless(
      notificationIconResourceType: 'mipmap',
      notificationIconResourceName: 'ic_launcher',
    );
    _initialized = true;
  }

  @override
  Future<void> start(ProxyConfig config, AppSettings settings) async {
    if (_current == VpnStatus.connected || _current == VpnStatus.connecting) return;
    _set(VpnStatus.connecting);
    try {
      await _init();
      final vpnMode = settings.mode == ConnectionMode.vpn;
      if (vpnMode && !await _vless.requestPermission()) {
        throw XrayException('VPN permission denied');
      }
      final json = await _buildConfig(config, settings);
      _log('Info', 'starting ${config.protocol.name} ${config.address}:${config.port} (${vpnMode ? 'vpn' : 'proxy'})');
      _waitConnected = Completer<void>();
      await _vless.startVless(
        remark: config.name,
        config: json,
        proxyOnly: !vpnMode,
        blockedApps: settings.excludedApps.isEmpty ? null : settings.excludedApps,
      );
      await _waitConnected!.future.timeout(Duration(seconds: settings.autoSwitch ? 20 : 40));
      _connectedId = config.id;
      _log('Info', 'connected to ${config.address}:${config.port}');
    } on TimeoutException {
      _log('Error', 'connect timeout');
      await stop();
      throw XrayException('اتصال برقرار نشد (timeout)');
    } catch (e) {
      _log('Error', '$e');
      _set(VpnStatus.error);
      _set(VpnStatus.disconnected);
      if (e is XrayException) rethrow;
      throw XrayException('$e');
    } finally {
      _waitConnected = null;
    }
  }

  @override
  Future<void> stop() async {
    try {
      await _init();
      await _vless.stopVless();
    } catch (e) {
      _log('Error', 'stop failed: $e');
    }
    _traffic.add(TrafficStats.zero);
    _log('Info', 'Xray stopped');
    _set(VpnStatus.disconnected);
  }

  /// Own ping implementation (independent of the plugin):
  /// connected config → real HTTP round-trip through the tunnel,
  /// otherwise → TCP connect time to the server.
  @override
  Future<int> ping(ProxyConfig config) async {
    if (_current == VpnStatus.connected && _connectedId == config.id) {
      return _httpPing();
    }
    if (config.protocol == ProxyProtocol.hysteria2) return -1; // UDP based
    return _tcpPing(config.address, config.port);
  }

  Future<int> _tcpPing(String host, int port) async {
    try {
      final addrs = await InternetAddress.lookup(host).timeout(const Duration(seconds: 4));
      if (addrs.isEmpty) return -1;
      final sw = Stopwatch()..start();
      final sock = await Socket.connect(addrs.first, port, timeout: const Duration(seconds: 5));
      sw.stop();
      sock.destroy();
      return sw.elapsedMilliseconds < 1 ? 1 : sw.elapsedMilliseconds;
    } catch (_) {
      return -1;
    }
  }

  Future<int> _httpPing() async {
    var best = -1;
    for (var i = 0; i < 2; i++) {
      final client = tunnelClient();
      try {
        final sw = Stopwatch()..start();
        final req = await client
            .getUrl(Uri.parse('http://cp.cloudflare.com/generate_204'))
            .timeout(const Duration(seconds: 8));
        final res = await req.close().timeout(const Duration(seconds: 8));
        await res.drain<void>();
        sw.stop();
        if (res.statusCode == 204 || res.statusCode == 200) {
          final ms = sw.elapsedMilliseconds < 1 ? 1 : sw.elapsedMilliseconds;
          if (best < 0 || ms < best) best = ms;
        }
      } catch (_) {
        // try again
      } finally {
        client.close(force: true);
      }
    }
    return best;
  }

  static const _tunnelPort = 20809;

  @override
  HttpClient tunnelClient() => HttpClient()
    ..findProxy = (_) => 'PROXY 127.0.0.1:$_tunnelPort'
    ..connectionTimeout = const Duration(seconds: 8);

  /// Adds a loopback-only HTTP inbound so the app can test the tunnel itself.
  void _addTunnelInbound(Map<String, dynamic> map) {
    final ins = map['inbounds'];
    final list = ins is List ? ins : <dynamic>[];
    if (!list.any((i) => i is Map && i['tag'] == 'in_tunnel_test')) {
      list.add({
        'tag': 'in_tunnel_test',
        'listen': '127.0.0.1',
        'port': _tunnelPort,
        'protocol': 'http',
        'settings': {},
      });
    }
    map['inbounds'] = list;
  }

  @override
  void dispose() {
    _status.close();
    _traffic.close();
    _logs.close();
  }
}
